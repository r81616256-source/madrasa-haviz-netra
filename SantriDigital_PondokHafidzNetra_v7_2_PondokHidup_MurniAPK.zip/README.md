# Madrasah Hafidz Netra v1.0.0

Persembahan **Suara Media Teknologi — Nur & Mas Yeni Setiawan** (21 November 2026).

Aplikasi penghafal Al-Qur'an dan sekolah BBQ/Tahfidz **Audio-First** khusus tunanetra yang dirancang untuk TalkBack dan Jieshuo, dengan arsitektur **Online-First + Auto-Fallback Offline** serta **3 Mesin Generator Otomatis**:

1. **Mesin Generator 1 (Di Dalam Aplikasi):** Generator soal sambung ayat pilihan audio, simulasi Juri MHQ + pancingan 1 kata, bedah tajwid lisan, dan radar ayat mirip (*mutasyabihat*).
2. **Mesin Generator 2 (GitHub Actions Mingguan):** Otomatis membuat materi baru dan file MP3 narator **Ardi (`id-ID-ArdiNeural`)** dengan Kamus Pelafalan Islami setiap hari Jumat pukul 05.00 WIB tanpa perlu API Key, lalu merilisnya ke tag `materi-latest`.
3. **Mesin Generator 3 (Emulator Madrasah / Wali Kelas Pintar):** Jadwal harian adaptif (Sabaq, Sabqi, Manzil), pengingat bel **Ting-Tung** otomatis, rapor mingguan, dan prosesi wisuda naik tingkat (Tingkat 0 s.d. Tingkat 5).

## Cara Unggah ke GitHub (Cukup 1 Kali)
1. Buat repositori baru **Public** bernama `madrasah-hafiz-netra` dan centang **Add a README file**.
2. Ekstrak file ZIP luar sekali di HP, lalu unggah `MadrasahHafizNetra_Source.zip` beserta dua file workflow di `.github/workflows/` (`build-apk.yml` dan `generator-materi.yml`).
3. GitHub Actions akan otomatis membuat **Release APK (`v1.0.0`)** dan **Release Audio & Materi (`materi-latest`)**.
