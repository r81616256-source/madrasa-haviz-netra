package com.suaramediateknologi.madrasahhafiznetra;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.util.Locale;

/**
 * Foreground Service Penjaga Waktu & Pemutar Audio Otomatis (v7.0 — ala Nurul Masjid Pro).
 * - Menjaga kesiapan jadwal bel kelas, Doa Pagi, Wirid Sore, pengingat PR, dan Majelis Malam Jumat.
 * - Memutar bel tertanam + MP3 Ustadz Ardi (atau TTS Indonesia) secara otomatis di latar belakang
 *   tanpa perlu santri menekan tombol terlebih dahulu.
 * - Hormat mode telepon: tidak pernah memotong panggilan telepon atau dering masuk.
 */
public class PondokBackgroundService extends Service {

    public static final String ACTION_START_TIMEKEEPER = "com.suaramediateknologi.madrasahhafiznetra.ACTION_START_TIMEKEEPER";
    public static final String ACTION_START_PLAYBACK = "com.suaramediateknologi.madrasahhafiznetra.ACTION_START_PLAYBACK";
    public static final String ACTION_TRIGGER_SCHEDULED_AUDIO = "com.suaramediateknologi.madrasahhafiznetra.ACTION_TRIGGER_SCHEDULED_AUDIO";
    public static final String ACTION_STOP_PLAYBACK = "com.suaramediateknologi.madrasahhafiznetra.ACTION_STOP_PLAYBACK";
    public static final String ACTION_STOP_ALL = "com.suaramediateknologi.madrasahhafiznetra.ACTION_STOP_ALL";
    public static final String BROADCAST_USER_STOPPED = "com.suaramediateknologi.madrasahhafiznetra.BROADCAST_USER_STOPPED";

    private static final String CHANNEL_ID = "pondok_timekeeper_v7";
    private static final int NOTIF_ID = 7701;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private MediaPlayer bellPlayer;
    private MediaPlayer voicePlayer;
    private TextToSpeech bgTts;
    private boolean ttsReady = false;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private PowerManager.WakeLock wakeLock;
    private String currentStatusText = "Penjaga Waktu Pondok Hafidz Netra aktif";
    private Runnable pendingSpeechAction;

    /**
     * Mengecek apakah perangkat sedang digunakan menelepon atau berdering.
     * Wajib dipatuhi agar audio otomatis tidak mengganggu panggilan telepon.
     */
    public static boolean isPhoneBusy(Context context) {
        if (context == null) return false;
        try {
            AudioManager am = (AudioManager) context.getApplicationContext().getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return false;
            int mode = am.getMode();
            return mode == AudioManager.MODE_IN_CALL
                    || mode == AudioManager.MODE_IN_COMMUNICATION
                    || mode == AudioManager.MODE_RINGTONE;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static void startTimekeeper(Context context) {
        if (context == null) return;
        try {
            SharedPreferences prefs = context.getApplicationContext()
                    .getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
            if (!prefs.getBoolean(AppConfig.KEY_REMINDER_ENABLED, true)
                    || !prefs.getBoolean(AppConfig.KEY_BG_ALERTS_ENABLED, true)) {
                return;
            }
            Intent i = new Intent(context.getApplicationContext(), PondokBackgroundService.class);
            i.setAction(ACTION_START_TIMEKEEPER);
            ContextCompat.startForegroundService(context.getApplicationContext(), i);
        } catch (Exception ignored) {}
    }

    public static void startForActivePlayback(Context context, String nowPlayingLabel) {
        if (context == null) return;
        try {
            Intent i = new Intent(context.getApplicationContext(), PondokBackgroundService.class);
            i.setAction(ACTION_START_PLAYBACK);
            i.putExtra("label", nowPlayingLabel == null ? "Memutar audio Pondok Hafidz Netra..." : nowPlayingLabel);
            ContextCompat.startForegroundService(context.getApplicationContext(), i);
        } catch (Exception ignored) {}
    }

    public static void triggerScheduledAudio(Context context, String label, int rawBellResId,
                                             String mp3FileName, String spokenText) {
        if (context == null) return;
        try {
            Intent i = new Intent(context.getApplicationContext(), PondokBackgroundService.class);
            i.setAction(ACTION_TRIGGER_SCHEDULED_AUDIO);
            i.putExtra("label", label == null ? "Panggilan Jadwal Pondok" : label);
            i.putExtra("bell_res", rawBellResId);
            i.putExtra("mp3_file", mp3FileName == null ? "" : mp3FileName);
            i.putExtra("spoken_text", spokenText == null ? "" : spokenText);
            ContextCompat.startForegroundService(context.getApplicationContext(), i);
        } catch (Exception ignored) {}
    }

    public static void stopServiceNow(Context context) {
        if (context == null) return;
        try {
            Intent i = new Intent(context.getApplicationContext(), PondokBackgroundService.class);
            i.setAction(ACTION_STOP_PLAYBACK);
            context.getApplicationContext().startService(i);
        } catch (Exception ignored) {}
    }

    public static void stopCompletely(Context context) {
        if (context == null) return;
        try {
            Intent i = new Intent(context.getApplicationContext(), PondokBackgroundService.class);
            context.getApplicationContext().stopService(i);
        } catch (Exception ignored) {}
    }

    @Override
    public void onCreate() {
        super.onCreate();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        initBgTts();
    }

    private void initBgTts() {
        try {
            bgTts = new TextToSpeech(getApplicationContext(), status -> {
                if (status == TextToSpeech.SUCCESS && bgTts != null) {
                    bgTts.setLanguage(new Locale("id", "ID"));
                    bgTts.setSpeechRate(0.95f);
                    ttsReady = true;
                    if (pendingSpeechAction != null) {
                        Runnable r = pendingSpeechAction;
                        pendingSpeechAction = null;
                        mainHandler.post(r);
                    }
                }
            });
        } catch (Exception ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START_TIMEKEEPER : intent.getAction();
        if (action == null) action = ACTION_START_TIMEKEEPER;

        if (ACTION_STOP_ALL.equals(action)) {
            stopInternalAudio();
            stopForegroundCompat();
            stopSelf();
            return START_NOT_STICKY;
        }

        if (ACTION_STOP_PLAYBACK.equals(action)) {
            stopInternalAudio();
            Intent stopBc = new Intent(BROADCAST_USER_STOPPED);
            stopBc.setPackage(getPackageName());
            sendBroadcast(stopBc);
            updateForegroundNotification(buildIdleSummary());
            return START_STICKY;
        }

        if (ACTION_START_PLAYBACK.equals(action)) {
            String label = intent.getStringExtra("label");
            if (label == null || label.trim().isEmpty()) {
                label = "Memutar audio Pondok Hafidz Netra...";
            }
            updateForegroundNotification(label);
            return START_STICKY;
        }

        if (ACTION_TRIGGER_SCHEDULED_AUDIO.equals(action)) {
            String label = intent.getStringExtra("label");
            int bellRes = intent.getIntExtra("bell_res", R.raw.bel_masuk_kelas);
            String mp3File = intent.getStringExtra("mp3_file");
            String spokenText = intent.getStringExtra("spoken_text");
            updateForegroundNotification(label == null ? "Panggilan Otomatis Pondok" : label);

            if (!isPhoneBusy(this)) {
                playAutomaticAnnouncement(bellRes, mp3File, spokenText);
            }
            return START_STICKY;
        }

        // Default: ACTION_START_TIMEKEEPER
        updateForegroundNotification(buildIdleSummary());
        return START_STICKY;
    }

    private String buildIdleSummary() {
        try {
            SchoolScheduleEngine sched = new SchoolScheduleEngine(this);
            if (sched.isRealSundayToday() && !sched.isSimClockEnabled()) {
                return "Penjaga Waktu Aktif • Ahad Libur & Sambangan Keluarga";
            }
            return "Penjaga Waktu Aktif • " + ReminderScheduler.getNextScheduleHint(this);
        } catch (Exception e) {
            return "Penjaga Waktu Pondok Hafidz Netra aktif";
        }
    }

    private void playAutomaticAnnouncement(int bellResId, String mp3FileName, String spokenText) {
        stopInternalAudio();
        acquireShortWakeLock();
        requestAudioFocus();

        Runnable afterBell = () -> playVoiceOrTts(mp3FileName, spokenText);

        if (bellResId != 0) {
            try {
                AssetFileDescriptor afd = getResources().openRawResourceFd(bellResId);
                if (afd != null) {
                    bellPlayer = new MediaPlayer();
                    bellPlayer.setAudioAttributes(buildAudioAttributes());
                    bellPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                    afd.close();
                    bellPlayer.setOnCompletionListener(mp -> {
                        releaseBellPlayer();
                        mainHandler.postDelayed(afterBell, 350);
                    });
                    bellPlayer.setOnErrorListener((mp, w, e) -> {
                        releaseBellPlayer();
                        mainHandler.post(afterBell);
                        return true;
                    });
                    bellPlayer.prepare();
                    bellPlayer.start();
                    return;
                }
            } catch (Exception ignored) {
                releaseBellPlayer();
            }
        }
        afterBell.run();
    }

    private void playVoiceOrTts(String mp3FileName, String spokenText) {
        if (isPhoneBusy(this)) {
            finishAnnouncement();
            return;
        }
        if (mp3FileName != null && !mp3FileName.trim().isEmpty()) {
            File cachedMp3 = new File(new File(getFilesDir(), "audio_ustadz"), mp3FileName.trim());
            if (cachedMp3.exists() && cachedMp3.length() > 1024) {
                try {
                    voicePlayer = new MediaPlayer();
                    voicePlayer.setAudioAttributes(buildAudioAttributes());
                    voicePlayer.setDataSource(cachedMp3.getAbsolutePath());
                    voicePlayer.setOnCompletionListener(mp -> finishAnnouncement());
                    voicePlayer.setOnErrorListener((mp, w, e) -> {
                        releaseVoicePlayer();
                        speakWithBgTts(spokenText);
                        return true;
                    });
                    voicePlayer.prepare();
                    voicePlayer.start();
                    return;
                } catch (Exception ignored) {
                    releaseVoicePlayer();
                }
            }
        }
        speakWithBgTts(spokenText);
    }

    private void speakWithBgTts(String spokenText) {
        if (spokenText == null || spokenText.trim().isEmpty() || isPhoneBusy(this)) {
            finishAnnouncement();
            return;
        }
        Runnable doSpeak = () -> {
            if (bgTts == null || !ttsReady || isPhoneBusy(this)) {
                finishAnnouncement();
                return;
            }
            try {
                bgTts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) {}
                    @Override public void onDone(String utteranceId) {
                        mainHandler.post(() -> finishAnnouncement());
                    }
                    @Override public void onError(String utteranceId) {
                        mainHandler.post(() -> finishAnnouncement());
                    }
                });
                bgTts.speak(spokenText, TextToSpeech.QUEUE_FLUSH, null, "pondok_auto_" + System.currentTimeMillis());
            } catch (Exception ignored) {
                finishAnnouncement();
            }
        };

        if (ttsReady) {
            doSpeak.run();
        } else {
            pendingSpeechAction = doSpeak;
            mainHandler.postDelayed(() -> {
                if (pendingSpeechAction != null) {
                    pendingSpeechAction = null;
                    finishAnnouncement();
                }
            }, 6000);
        }
    }

    private void finishAnnouncement() {
        releaseBellPlayer();
        releaseVoicePlayer();
        abandonAudioFocus();
        releaseWakeLock();
        updateForegroundNotification(buildIdleSummary());
    }

    private void stopInternalAudio() {
        pendingSpeechAction = null;
        releaseBellPlayer();
        releaseVoicePlayer();
        try {
            if (bgTts != null) bgTts.stop();
        } catch (Exception ignored) {}
        abandonAudioFocus();
        releaseWakeLock();
    }

    private void releaseBellPlayer() {
        try {
            if (bellPlayer != null) {
                bellPlayer.stop();
                bellPlayer.release();
            }
        } catch (Exception ignored) {}
        bellPlayer = null;
    }

    private void releaseVoicePlayer() {
        try {
            if (voicePlayer != null) {
                voicePlayer.stop();
                voicePlayer.release();
            }
        } catch (Exception ignored) {}
        voicePlayer = null;
    }

    private AudioAttributes buildAudioAttributes() {
        return new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build();
    }

    private void requestAudioFocus() {
        if (audioManager == null) return;
        try {
            focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(buildAudioAttributes())
                    .setOnAudioFocusChangeListener(focusChange -> {
                        if (focusChange == AudioManager.AUDIOFOCUS_LOSS
                                || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                            stopInternalAudio();
                        }
                    })
                    .build();
            audioManager.requestAudioFocus(focusRequest);
        } catch (Exception ignored) {}
    }

    private void abandonAudioFocus() {
        if (audioManager == null || focusRequest == null) return;
        try {
            audioManager.abandonAudioFocusRequest(focusRequest);
        } catch (Exception ignored) {}
        focusRequest = null;
    }

    private void acquireShortWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                releaseWakeLock();
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MadrasahHafizNetra:AutoAudio");
                wakeLock.acquire(45_000L);
            }
        } catch (Exception ignored) {}
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {}
        wakeLock = null;
    }

    private void updateForegroundNotification(String statusText) {
        currentStatusText = statusText == null ? "Penjaga Waktu Pondok Hafidz Netra aktif" : statusText;
        Notification n = buildNotification(currentStatusText);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception ignored) {}
    }

    private void stopForegroundCompat() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE);
            } else {
                stopForeground(true);
            }
        } catch (Exception ignored) {}
    }

    private Notification buildNotification(String label) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Penjaga Waktu & Audio Pondok", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Menjaga bel kelas, Doa Pagi, Wirid Sore, dan audio murattal tetap berjalan otomatis.");
            nm.createNotificationChannel(ch);
        }

        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 7702, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, PondokBackgroundService.class);
        stopIntent.setAction(ACTION_STOP_PLAYBACK);
        PendingIntent stopPi = PendingIntent.getService(this, 7703, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Pondok Hafidz Netra — Penjaga Waktu")
                .setContentText(label)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(label))
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(openPi)
                .addAction(android.R.drawable.ic_media_pause, "Hentikan Audio", stopPi)
                .build();
    }

    @Override
    public void onDestroy() {
        stopInternalAudio();
        try {
            if (bgTts != null) {
                bgTts.shutdown();
            }
        } catch (Exception ignored) {}
        bgTts = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
