package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Mesin Deteksi Pintar & Adaptif Santri Digital (v6.0 — Pondok Resmi Hidup).
 * Memetakan pola kesulitan nyata, Jam Emas belajar, deteksi dini futur,
 * skor kesiapan sidang 0-100%, antrean penguatan besok, memori blok sulit,
 * serta rekomendasi metode belajar yang bisa langsung diterapkan ke pemutar audio.
 */
public final class SmartLearningEngine {
    public static final String ERR_TRANSITION = "TRANSITION";
    public static final String ERR_LONG_BREATH = "LONG_BREATH";
    public static final String ERR_SIMILAR = "SIMILAR";
    public static final String ERR_PRONUNCIATION = "PRONUNCIATION";

    public static final class AdaptiveRecommendation {
        public final int methodIndex;
        public final float playbackSpeed;
        public final int repeatCount;
        public final int pauseSeconds;
        public final String methodLabel;
        public final String reason;

        public AdaptiveRecommendation(int methodIndex, float playbackSpeed, int repeatCount,
                                      int pauseSeconds, String methodLabel, String reason) {
            this.methodIndex = methodIndex;
            this.playbackSpeed = playbackSpeed;
            this.repeatCount = repeatCount;
            this.pauseSeconds = pauseSeconds;
            this.methodLabel = methodLabel;
            this.reason = reason;
        }
    }

    private final SharedPreferences prefs;
    private final Map<String, Integer> sessionStruggleCounts = new HashMap<>();

    public SmartLearningEngine(Context context) {
        this.prefs = context.getApplicationContext()
                .getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
    }

    // ================= PENGHITUNG HARI DI PONDOK & TA'ARUF =================
    public void ensureFirstJoinRecorded() {
        if (prefs.getLong(AppConfig.KEY_FIRST_JOIN_EPOCH, 0L) == 0L) {
            prefs.edit().putLong(AppConfig.KEY_FIRST_JOIN_EPOCH, System.currentTimeMillis()).apply();
        }
    }

    public int getDayNumberAtPondok() {
        long start = prefs.getLong(AppConfig.KEY_FIRST_JOIN_EPOCH, 0L);
        if (start <= 0L) return 1;
        long diffDays = Math.max(0L, (System.currentTimeMillis() - start) / 86_400_000L);
        return (int) diffDays + 1;
    }

    public boolean isTaarufCompleted() {
        return prefs.getBoolean(AppConfig.KEY_TAARUF_DONE, false);
    }

    public void markTaarufCompleted() {
        ensureFirstJoinRecorded();
        prefs.edit().putBoolean(AppConfig.KEY_TAARUF_DONE, true).apply();
    }

    // ================= JAM EMAS BELAJAR NYATA =================
    public void recordSuccessAtCurrentHour() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_GOLDEN_HOUR_JSON, "{}"));
            String k = String.valueOf(hour);
            obj.put(k, obj.optInt(k, 0) + 1);
            prefs.edit()
                    .putString(AppConfig.KEY_GOLDEN_HOUR_JSON, obj.toString())
                    .putLong(AppConfig.KEY_LAST_ACTIVITY_EPOCH, System.currentTimeMillis())
                    .apply();
        } catch (Exception ignored) {}
    }

    public int getBestGoldenHour() {
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_GOLDEN_HOUR_JSON, "{}"));
            int bestHour = -1;
            int bestScore = 0;
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                int v = obj.optInt(k, 0);
                if (v > bestScore) {
                    bestScore = v;
                    bestHour = Integer.parseInt(k);
                }
            }
            return bestScore >= 2 ? bestHour : -1;
        } catch (Exception ignored) {
            return -1;
        }
    }

    public String getGoldenHourAdvice() {
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_GOLDEN_HOUR_JSON, "{}"));
            int bestHour = -1;
            int bestScore = 0;
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                int v = obj.optInt(k, 0);
                if (v > bestScore) {
                    bestScore = v;
                    bestHour = Integer.parseInt(k);
                }
            }
            if (bestHour >= 0 && bestScore >= 2) {
                return String.format(Locale.US,
                        "Jam Emas kamu: Pukul %02d.00 WIB (%d kali lulus setoran/latihan di jam ini).",
                        bestHour, bestScore);
            }
        } catch (Exception ignored) {}
        return "Jam Emas sedang dipetakan (butuh minimal 2 kali latihan/setoran berhasil).";
    }

    // ================= POLA KESULITAN & REKOMENDASI ADAPTIF =================
    public void recordDifficultyPattern(String patternKey) {
        if (patternKey == null || patternKey.trim().isEmpty()) return;
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_ERROR_PATTERN_JSON, "{}"));
            obj.put(patternKey, obj.optInt(patternKey, 0) + 1);
            prefs.edit()
                    .putString(AppConfig.KEY_ERROR_PATTERN_JSON, obj.toString())
                    .putLong(AppConfig.KEY_LAST_ACTIVITY_EPOCH, System.currentTimeMillis())
                    .apply();
        } catch (Exception ignored) {}
    }

    public int getPatternCount(String patternKey) {
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_ERROR_PATTERN_JSON, "{}"));
            return obj.optInt(patternKey, 0);
        } catch (Exception ignored) {
            return 0;
        }
    }

    /**
     * Menghasilkan rekomendasi metode belajar yang BENAR-BENAR bisa diterapkan
     * ke spMethodV4, spSpeed, spRepeat, dan spPause di Ruang Belajar.
     */
    public AdaptiveRecommendation buildAdaptiveRecommendation(int ayahWordCount, int currentMasteryPct, boolean hasMutasyabihat) {
        if (isEarlyFuturDetected()) {
            return new AdaptiveRecommendation(
                    0, 0.75f, 2, 4,
                    safeMethodLabel(0),
                    "Terdeteksi jeda belajar lebih dari 48 jam. Mulai ringan dulu dengan Talaqqi Per Ayat pelan 0,75x agar semangat pulih tanpa beban."
            );
        }
        if (ayahWordCount >= 14 && currentMasteryPct < 60) {
            return new AdaptiveRecommendation(
                    2, 0.75f, 3, 5,
                    safeMethodLabel(2),
                    "Ayat ini panjang (" + ayahWordCount + " kata) dan penguasaan baru " + currentMasteryPct
                            + "%. Gunakan Penggal Napas Waqaf + tempo 0,75x."
            );
        }
        if (hasMutasyabihat && currentMasteryPct < 85) {
            return new AdaptiveRecommendation(
                    17, 1.0f, 3, 4,
                    safeMethodLabel(17),
                    "Ayat ini memiliki kemiripan bunyi dengan ayat lain (Mutasyabihat). Gunakan Latihan Mutasyabihat agar tidak tertukar saat setoran."
            );
        }

        int t = getPatternCount(ERR_TRANSITION);
        int l = getPatternCount(ERR_LONG_BREATH);
        int s = getPatternCount(ERR_SIMILAR);
        int p = getPatternCount(ERR_PRONUNCIATION);

        if (p >= t && p >= l && p >= s && p >= 2) {
            return new AdaptiveRecommendation(
                    1, 0.75f, 3, 4,
                    safeMethodLabel(1),
                    "Pola kesulitan dominan pada pelafalan/makhraj (" + p + "x). Gunakan Talaqqi Per Kata dengan tempo 0,75x."
            );
        }
        if (t >= l && t >= s && t >= 2) {
            return new AdaptiveRecommendation(
                    8, 1.0f, 3, 4,
                    safeMethodLabel(8),
                    "Sering ragu saat menyambung antar-ayat (" + t + "x). Gunakan Metode Tautan Engsel untuk mengunci ujung ayat ke ayat berikutnya."
            );
        }
        if (l >= t && l >= s && l >= 2) {
            return new AdaptiveRecommendation(
                    2, 0.75f, 3, 5,
                    safeMethodLabel(2),
                    "Napas sering terputus di tengah ayat (" + l + "x). Gunakan Penggal Napas Waqaf dengan jeda 5 detik."
            );
        }
        if (s >= 2) {
            return new AdaptiveRecommendation(
                    11, 1.0f, 3, 4,
                    safeMethodLabel(11),
                    "Ayat rawan tertukar (" + s + "x). Gunakan Audio Buka-Tutup untuk menguji daya ingat ujung ayat."
            );
        }

        if (currentMasteryPct >= 80) {
            return new AdaptiveRecommendation(
                    12, 1.0f, 3, 4,
                    safeMethodLabel(12),
                    "Penguasaan ayat sudah " + currentMasteryPct + "%. Mantapkan menuju 100% Hijau dengan Mode Estafet Gantian."
            );
        }
        if (currentMasteryPct >= 40) {
            return new AdaptiveRecommendation(
                    11, 1.0f, 3, 4,
                    safeMethodLabel(11),
                    "Ayat mulai lengket (" + currentMasteryPct + "%). Uji kelancaran pakai Audio Buka-Tutup."
            );
        }
        return new AdaptiveRecommendation(
                0, 1.0f, 3, 4,
                safeMethodLabel(0),
                "Ayat baru (" + currentMasteryPct + "%). Mulai dengan Talaqqi Per Ayat 3x ulangan dan jeda 4 detik."
        );
    }

    private String safeMethodLabel(int idx) {
        if (AppConfig.METHOD_LABELS_V4 != null && idx >= 0 && idx < AppConfig.METHOD_LABELS_V4.length) {
            return AppConfig.METHOD_LABELS_V4[idx];
        }
        return "Talaqqi Per Ayat";
    }

    // ================= DETEKSI DINI FUTUR =================
    public long getInactiveHours() {
        long last = prefs.getLong(AppConfig.KEY_LAST_ACTIVITY_EPOCH, 0L);
        if (last <= 0L) return 0L;
        return Math.max(0L, (System.currentTimeMillis() - last) / 3_600_000L);
    }

    public boolean isEarlyFuturDetected() {
        return getInactiveHours() >= 48L;
    }

    public String buildFuturRecoveryPlan() {
        long hrs = getInactiveHours();
        if (hrs < 48L) {
            return "Ritme belajarmu stabil (terakhir aktif " + hrs + " jam yang lalu). Pertahankan istiqamah!";
        }
        long days = hrs / 24L;
        return "Terdeteksi jeda " + days + " hari (" + hrs + " jam). Jangan langsung memaksa banyak ayat — "
                + "cukup selesaikan 1 ayat pemanasan dengan tempo 0,75x hari ini agar rantai hafalan tersambung lagi.";
    }

    // ================= INTERVENSI REAL-TIME SAAT LATIHAN =================
    public String recordAyahAttemptAndCheckIntervention(int surahNo, String surahName, int ayahNo,
                                                        int wordCount, boolean success) {
        String key = surahNo + ":" + ayahNo;
        prefs.edit().putLong(AppConfig.KEY_LAST_ACTIVITY_EPOCH, System.currentTimeMillis()).apply();
        if (success) {
            sessionStruggleCounts.put(key, 0);
            removeTomorrowRetryItem(surahNo, ayahNo);
            recordSuccessAtCurrentHour();
            return null;
        }

        int cnt = sessionStruggleCounts.containsKey(key) ? sessionStruggleCounts.get(key) + 1 : 1;
        sessionStruggleCounts.put(key, cnt);
        recordDifficultyPattern(wordCount >= 14 ? ERR_LONG_BREATH : ERR_PRONUNCIATION);

        if (cnt >= 3) {
            addTomorrowRetryItem(surahNo, surahName, ayahNo);
            return "Deteksi Pintar Aktif: Kamu sudah mencoba " + surahName + " ayat " + ayahNo
                    + " sebanyak " + cnt + " kali dan masih tersendat. Sistem otomatis menurunkan tempo ke 0,75x "
                    + "serta memasukkan ayat ini ke Antrean Penguatan Besok agar besok pagi kita ulang pelan dulu.";
        }
        return null;
    }

    // ================= SKOR KESIAPAN SIDANG & LAPORAN JUJUR =================
    public int computeExamReadinessPct(int attendancePct, int finalGrade, int masteredAyahs, int dueReviewCount) {
        int masteryFactor = Math.min(100, masteredAyahs * 10);
        int duePenalty = Math.min(25, dueReviewCount * 5);
        int raw = (int) Math.round(attendancePct * 0.25 + masteryFactor * 0.40 + finalGrade * 0.35) - duePenalty;
        return Math.max(0, Math.min(100, raw));
    }

    public String buildHonestStrictFeedback(int scorePct, String surahName, int ayahNo) {
        if (scorePct >= 85) {
            return "KOREKSI JUJUR GURU [LULUS MUTQIN — " + scorePct + "%]: MasyaAllah! Bacaan "
                    + surahName + " ayat " + ayahNo + " jelas dan tepat. Ayat ini naik tingkat dan layak lanjut ke ayat berikutnya.";
        }
        if (scorePct >= 75) {
            return "KOREKSI JUJUR GURU [LULUS — " + scorePct + "%]: Bacaan "
                    + surahName + " ayat " + ayahNo + " sudah memenuhi batas lulus 75%, tapi masih bisa lebih bersih lagi.";
        }
        if (scorePct >= 55) {
            return "KOREKSI JUJUR GURU [BELUM LULUS — " + scorePct + "%]: Hampir tepat, tetapi masih ada kata yang meleset di "
                    + surahName + " ayat " + ayahNo + ". Ulangi pelan 2 putaran sebelum setor ulang.";
        }
        return "TEGURAN TEGAS & JUJUR GURU [BELUM LULUS — " + scorePct + "%]: Maaf, bacaan "
                + surahName + " ayat " + ayahNo + " belum memenuhi standar kelulusan (minimal 75%). "
                + "Turunkan tempo ke 0,75x dan ulangi lewat Talaqqi Per Kata. Ayat ini dicatat untuk penguatan!";
    }

    public String buildSmartDiagnosisReport(int attendancePct, int finalGrade, int iqraLevel,
                                            int masteredAyahs, int dueReviewCount, int ayahWordCount,
                                            int activeAyahMastery, boolean hasMutasyabihat) {
        int sessions = prefs.getInt(AppConfig.KEY_TOTAL_STUDY_SESSIONS, 0);
        int mins = prefs.getInt(AppConfig.KEY_TOTAL_STUDY_MINUTES, 0);
        int ready = computeExamReadinessPct(attendancePct, finalGrade, masteredAyahs, dueReviewCount);
        int retryCnt = getTomorrowRetryItems().size();
        AdaptiveRecommendation rec = buildAdaptiveRecommendation(ayahWordCount, activeAyahMastery, hasMutasyabihat);

        String statusJujur;
        if (sessions == 0) {
            statusJujur = "BELUM ADA LATIHAN NYATA — Mulai minimal 1 sesi Talaqqi atau Setoran Suara hari ini.";
        } else if (ready >= 75 && dueReviewCount == 0) {
            statusJujur = "SIAP MAJU SIDANG MUNAQASYAH";
        } else if (dueReviewCount > 0) {
            statusJujur = "PERLU MURAJAAH ANTI-LUPA (" + dueReviewCount + " ayat jatuh tempo)";
        } else {
            statusJujur = "BERKEMBANG — Perkuat ayat kuning/merah sebelum sidang";
        }

        String recentLog = prefs.getString(AppConfig.KEY_AUTO_STUDY_LOG, "Belum ada sesi belajar tercatat.");
        return "DIAGNOSIS MESIN DETEKSI PINTAR (Hari ke-" + getDayNumberAtPondok() + ")\n\n"
                + "• Status Jujur: " + statusJujur + "\n"
                + "• Skor Kesiapan Sidang: " + ready + "%\n"
                + "• Total Latihan Nyata: " + sessions + " sesi (" + mins + " menit) | Iqra' Jilid " + iqraLevel + "\n"
                + "• Ayat 100% Hijau: " + masteredAyahs + " ayat | Jatuh Tempo Anti-Lupa: " + dueReviewCount
                + " | PR Penguatan: " + retryCnt + "\n"
                + "• " + getGoldenHourAdvice() + "\n"
                + "• Stamina & Futur: " + buildFuturRecoveryPlan() + "\n"
                + "• Kedekatan Penghuni Pondok: " + getClosenessLabel() + "\n\n"
                + "REKOMENDASI METODE ADAPTIF:\n"
                + "Metode: " + rec.methodLabel + " (Tempo " + rec.playbackSpeed + "x, Ulangan " + rec.repeatCount + "x, Jeda " + rec.pauseSeconds + "d)\n"
                + "Alasan: " + rec.reason + "\n\n"
                + "CATATAN SESI TERAKHIR:\n" + recentLog;
    }

    // ================= ANTREAN PENGUATAN BESOK =================
    public void addTomorrowRetryItem(int surahNo, String surahName, int ayahNo) {
        String raw = prefs.getString(AppConfig.KEY_TOMORROW_RETRY_QUEUE, "");
        String item = surahNo + "|" + surahName + "|" + ayahNo;
        if (raw.contains(item)) return;
        String next = raw.isEmpty() ? item : raw + ";;" + item;
        prefs.edit().putString(AppConfig.KEY_TOMORROW_RETRY_QUEUE, next).apply();
    }

    public void removeTomorrowRetryItem(int surahNo, int ayahNo) {
        List<String> items = getTomorrowRetryItems();
        if (items.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        String prefix = surahNo + "|";
        String suffix = "|" + ayahNo;
        for (String it : items) {
            if (it.startsWith(prefix) && it.endsWith(suffix)) continue;
            if (sb.length() > 0) sb.append(";;");
            sb.append(it);
        }
        prefs.edit().putString(AppConfig.KEY_TOMORROW_RETRY_QUEUE, sb.toString()).apply();
    }

    public List<String> getTomorrowRetryItems() {
        List<String> list = new ArrayList<>();
        String raw = prefs.getString(AppConfig.KEY_TOMORROW_RETRY_QUEUE, "");
        if (raw == null || raw.trim().isEmpty()) return list;
        for (String p : raw.split(";;")) {
            if (!p.trim().isEmpty()) list.add(p.trim());
        }
        return list;
    }

    public String buildTomorrowRetryBanner() {
        List<String> items = getTomorrowRetryItems();
        if (items.isEmpty()) return "";
        StringBuilder sb = new StringBuilder("Antrean Penguatan (" + items.size() + " ayat): ");
        for (int i = 0; i < Math.min(3, items.size()); i++) {
            String[] parts = items.get(i).split("\\|");
            if (parts.length >= 3) {
                if (i > 0) sb.append(", ");
                sb.append(parts[1]).append(" ayat ").append(parts[2]);
            }
        }
        return sb.toString();
    }

    public void clearTomorrowRetryQueue() {
        prefs.edit().remove(AppConfig.KEY_TOMORROW_RETRY_QUEUE).apply();
    }

    // ================= LOG SESI & BUKU MUTABA'AH YAUMIYAH =================
    public void logAutoStudySession(String topic, String methodUsed, int minutes, int scorePct) {
        int sessions = prefs.getInt(AppConfig.KEY_TOTAL_STUDY_SESSIONS, 0) + 1;
        int totalMins = prefs.getInt(AppConfig.KEY_TOTAL_STUDY_MINUTES, 0) + Math.max(1, minutes);
        String stamp = new SimpleDateFormat("dd/MM HH:mm", Locale.US).format(new Date());
        String line = stamp + " | " + topic + " (" + methodUsed + ") — " + Math.max(1, minutes) + " mnt | Skor " + scorePct + "%";
        String old = prefs.getString(AppConfig.KEY_AUTO_STUDY_LOG, "");
        String next = old.isEmpty() ? line : (line + "\n" + old);
        if (next.length() > 2500) next = next.substring(0, 2500);
        prefs.edit()
                .putInt(AppConfig.KEY_TOTAL_STUDY_SESSIONS, sessions)
                .putInt(AppConfig.KEY_TOTAL_STUDY_MINUTES, totalMins)
                .putString(AppConfig.KEY_AUTO_STUDY_LOG, next)
                .putLong(AppConfig.KEY_LAST_ACTIVITY_EPOCH, System.currentTimeMillis())
                .apply();
    }

    public void appendMutabaah(String jenis, String surahAyah, int kelancaranPct, String catatan) {
        try {
            JSONArray arr = new JSONArray(prefs.getString(AppConfig.KEY_MUTABAAH_JSON, "[]"));
            String tgl = new SimpleDateFormat("dd/MM/yy HH:mm", Locale.US).format(new Date());
            arr.put(tgl + " | " + jenis + " | " + surahAyah + " | " + kelancaranPct + "% | " + catatan);
            JSONArray trim = new JSONArray();
            for (int i = Math.max(0, arr.length() - 25); i < arr.length(); i++) {
                trim.put(arr.getString(i));
            }
            prefs.edit()
                    .putString(AppConfig.KEY_MUTABAAH_JSON, trim.toString())
                    .putLong(AppConfig.KEY_LAST_ACTIVITY_EPOCH, System.currentTimeMillis())
                    .apply();
        } catch (Exception ignored) {}
    }

    public String buildMutabaahReport(String nama, String nis) {
        StringBuilder sb = new StringBuilder();
        sb.append("BUKU MUTABA'AH YAUMIYAH RESMI\n");
        sb.append(AppConfig.INSTITUTION_NAME).append(" — ").append(AppConfig.ACADEMIC_YEAR).append("\n");
        sb.append("Santri: ").append(nama).append(" (NIS: ").append(nis).append(")\n\n");
        try {
            JSONArray arr = new JSONArray(prefs.getString(AppConfig.KEY_MUTABAAH_JSON, "[]"));
            if (arr.length() == 0) {
                sb.append("• Belum ada catatan setoran Ziyadah/Murajaah.\n");
            }
            for (int i = arr.length() - 1; i >= 0; i--) {
                sb.append("• ").append(arr.getString(i)).append("\n");
            }
        } catch (Exception ignored) {}
        return sb.toString();
    }

    // ================= MEMORI BLOK KESULITAN AYAT =================
    public void saveDifficultBlock(int surahNo, String surahName, int startAyah, int endAyah) {
        int s = Math.max(1, Math.min(startAyah, endAyah));
        int e = Math.max(s, Math.max(startAyah, endAyah));
        prefs.edit()
                .putInt(AppConfig.KEY_DIFF_BLOCK_SURAH, surahNo)
                .putString(AppConfig.KEY_DIFF_BLOCK_NAME, surahName)
                .putInt(AppConfig.KEY_DIFF_BLOCK_START, s)
                .putInt(AppConfig.KEY_DIFF_BLOCK_END, e)
                .apply();
    }

    public boolean hasActiveDifficultBlock() {
        return prefs.getInt(AppConfig.KEY_DIFF_BLOCK_SURAH, 0) > 0;
    }

    public int getDifficultBlockSurah() { return prefs.getInt(AppConfig.KEY_DIFF_BLOCK_SURAH, 0); }
    public String getDifficultBlockName() { return prefs.getString(AppConfig.KEY_DIFF_BLOCK_NAME, ""); }
    public int getDifficultBlockStart() { return prefs.getInt(AppConfig.KEY_DIFF_BLOCK_START, 1); }
    public int getDifficultBlockEnd() { return prefs.getInt(AppConfig.KEY_DIFF_BLOCK_END, 1); }

    public String getDifficultBlockSummary() {
        if (!hasActiveDifficultBlock()) return "";
        return "Blok Kesulitan Aktif: " + getDifficultBlockName() + " ayat "
                + getDifficultBlockStart() + "-" + getDifficultBlockEnd() + " (perlu dituntaskan).";
    }

    public void clearDifficultBlock() {
        prefs.edit()
                .remove(AppConfig.KEY_DIFF_BLOCK_SURAH)
                .remove(AppConfig.KEY_DIFF_BLOCK_NAME)
                .remove(AppConfig.KEY_DIFF_BLOCK_START)
                .remove(AppConfig.KEY_DIFF_BLOCK_END)
                .apply();
    }

    // ================= KEDEKATAN PENGHUNI PONDOK =================
    public void addCloseness(int pts) {
        int cur = Math.max(0, prefs.getInt(AppConfig.KEY_CLOSENESS_POINTS, 0) + pts);
        prefs.edit().putInt(AppConfig.KEY_CLOSENESS_POINTS, cur).apply();
    }

    public int getClosenessPoints() {
        return prefs.getInt(AppConfig.KEY_CLOSENESS_POINTS, 0);
    }

    public String getClosenessLabel() {
        int c = getClosenessPoints();
        if (c >= 150) return "Santri Teladan Kepercayaan Pondok (" + c + " poin)";
        if (c >= 60) return "Akrab dengan Pengurus & Kamar (" + c + " poin)";
        return "Santri Baru Asrama (" + c + " poin)";
    }

    // ================= v7.0 RESPON EMOSIONAL GURU & MEMORI LANJUTAN BELAJAR =================

    /**
     * Menghasilkan sapaan dan respon emosional guru yang manusiawi berdasarkan kondisi nyata santri:
     * futur/lama tidak membuka, stamina lelah, ayat sulit berulang, baru belajar tekun dari rumah,
     * atau konsisten menjaga hafalan.
     */
    public String buildTeacherEmotionalResponse(String teacherName, String santriName,
                                                int staminaPct, int repeatStruggles,
                                                int homeReadyCount, boolean justReturnedFromIzin) {
        String guru = (teacherName == null || teacherName.trim().isEmpty()) ? "Ustadzah Nur" : teacherName;
        String nama = (santriName == null || santriName.trim().isEmpty()) ? "Santri" : santriName;

        if (isEarlyFuturDetected()) {
            return guru + ": Assalamu'alaikum " + nama + ", lama tidak bertemu di majelis. Tidak apa-apa kalau kemarin sempat lelah atau sibuk — yang penting hari ini kita mulai pelan-pelan lagi dari 1 ayat saja ya.";
        }
        if (justReturnedFromIzin) {
            return guru + ": Alhamdulillah " + nama + " sudah kembali sehat dan siap belajar. Kita mulai dengan pemanasan ringan dulu tanpa terburu-buru.";
        }
        if (staminaPct < 35) {
            return guru + ": " + nama + ", suaramu dan staminamu (" + staminaPct + "%) tampak agak lelah. Mari kita baca perlahan saja, atau istirahat sebentar dan minum air hangat di Dapur Rumah ya.";
        }
        if (repeatStruggles >= 3) {
            return guru + ": MasyaAllah " + nama + ", kamu sangat sabar mengulang bagian sulit ini (" + repeatStruggles + " kali). Di sisi Allah setiap huruf yang diulang dengan susah payah mendapat dua pahala. Yuk kita pecah pelan per potongan.";
        }
        if (homeReadyCount > 0) {
            return guru + ": MasyaAllah " + nama + ", guru melihat ada " + homeReadyCount + " surat yang sudah kamu matangkan dari Rumah (>=75%)! Semangatmu luar biasa — hari ini langsung kita masukkan ke pelajaran dan setoran kelas ya.";
        }
        return guru + ": Assalamu'alaikum " + nama + ", senang melihatmu hadir tepat waktu dan tenang hari ini. Semoga Allah mudahkan setiap huruf yang kita hafal.";
    }

    /**
     * Membangun ringkasan Memori Lanjutan Belajar antar hari agar guru menyambung tepat
     * dari titik belajar santri pada hari sebelumnya.
     */
    public String buildDailyContinuationBrief(LivingMadrasahEngine living) {
        if (living == null) return "Siap memulai sesi belajar hari ini.";
        StringBuilder sb = new StringBuilder();
        String lastDate = living.getLastStudyDate();
        if (lastDate != null && !lastDate.isEmpty()) {
            sb.append("Memori Lanjutan Belajar (").append(lastDate).append("): ")
                    .append("Terakhir di ").append(living.getLastStudyLocation())
                    .append(" — ");
            if (living.getJenjangIndex() == 0) {
                sb.append("Iqra' Jilid ").append(living.getLastStudyIqraJilid());
            } else {
                sb.append("Surat ").append(living.getLastStudySurahName())
                        .append(" ayat ").append(living.getLastStudyAyahNo());
            }
            if (!living.getLastStudyNote().isEmpty()) {
                sb.append(" (").append(living.getLastStudyNote()).append(")");
            }
            sb.append(".");
        } else {
            sb.append("Ini catatan awal perjalanan belajarmu di Pondok Hafidz Netra v7.0.");
        }

        List<String> homeReady = living.getHomeReadySurahsForSchool();
        if (!homeReady.isEmpty()) {
            sb.append("\nPemberitahuan Pembimbing: ").append(homeReady.size())
                    .append(" surat dari latihan Rumah sudah matang (>=75%) dan otomatis masuk antrean setoran kelas!");
        }
        List<String> retry = getTomorrowRetryItems();
        if (!retry.isEmpty()) {
            sb.append("\nPR Murajaah Kemarin: ").append(retry.get(0));
        }
        return sb.toString();
    }

}
