package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Mesin Ruang Kelas Interaktif & Pohon Hafalan (v6.0 — Belajar Sesungguhnya).
 * - Peta Kekuatan Ayat 0-100% (Merah / Kuning / Hijau / Emas Mutqin)
 * - Jadwal Anti-Lupa 1-3-7-14 Hari (Spaced Repetition Nyata)
 * - Sesi Blok Ayat Tahap-demi-Tahap (mis. Ayat 1-3) dengan respon santri & adaptasi otomatis
 * - Pohon Hafalan Pondok yang tumbuh langsung dari ayat kuat & murajaah nyata
 * - Hitung Mundur Target Khatam Pribadi & Evaluasi Kenaikan Jenjang
 */
public class InteractiveClassroomEngine {
    public static final int STAGE_LISTEN_REPEAT = 1;
    public static final int STAGE_REMEDIAL_SLOW = 2;
    public static final int STAGE_VERIFY_AYAH = 3;
    public static final int STAGE_COMBINE_BLOCK = 4;
    public static final int STAGE_BLOCK_COMPLETE = 5;

    public static final String RESP_LANCAR = "LANCAR";
    public static final String RESP_RAGU_SAMBUNG = "RAGU_SAMBUNG";
    public static final String RESP_SULIT_NAPAS = "SULIT_NAPAS";
    public static final String RESP_SULIT_MAKHRAJ = "SULIT_MAKHRAJ";
    public static final String RESP_TERTUKAR = "TERTUKAR";

    /**
     * State machine nyata untuk belajar blok ayat (misalnya Ayat 1 sampai 3)
     * tahap demi tahap dengan respon santri di setiap langkah.
     */
    public static final class GuidedBlockSession {
        public final int surahNo;
        public final String surahName;
        public final int startIdx;   // 0-based
        public final int endIdx;     // 0-based inclusive
        public int activeIdx;        // 0-based ayat yang sedang dilatih
        public int stage;            // STAGE_*
        public int struggleOnActive; // berapa kali santri mengaku sulit di ayat aktif
        public String lastTeacherNote;
        public int suggestedMethodIndex;
        public float suggestedSpeed;
        public int suggestedRepeat;
        public int suggestedPauseSec;

        public GuidedBlockSession(int surahNo, String surahName, int startIdx, int endIdx) {
            this.surahNo = surahNo;
            this.surahName = surahName;
            this.startIdx = Math.max(0, startIdx);
            this.endIdx = Math.max(this.startIdx, endIdx);
            this.activeIdx = this.startIdx;
            this.stage = STAGE_LISTEN_REPEAT;
            this.struggleOnActive = 0;
            this.suggestedMethodIndex = 0;
            this.suggestedSpeed = 1.0f;
            this.suggestedRepeat = 3;
            this.suggestedPauseSec = 4;
            this.lastTeacherNote = "Bismillah, kita mulai belajar blok " + surahName
                    + " ayat " + (this.startIdx + 1) + " sampai " + (this.endIdx + 1)
                    + ". Langkah pertama: simak dan tirukan ayat " + (this.activeIdx + 1) + " dulu.";
        }

        public int getStartAyahNo() { return startIdx + 1; }
        public int getEndAyahNo() { return endIdx + 1; }
        public int getActiveAyahNo() { return activeIdx + 1; }
        public int getTotalBlockAyahs() { return (endIdx - startIdx) + 1; }
        public int getCompletedCount() {
            if (stage == STAGE_BLOCK_COMPLETE || stage == STAGE_COMBINE_BLOCK) return getTotalBlockAyahs();
            return Math.max(0, activeIdx - startIdx);
        }

        public String getStageLabel() {
            switch (stage) {
                case STAGE_LISTEN_REPEAT: return "Tahap 1: Talaqqi & Simak Ayat " + getActiveAyahNo();
                case STAGE_REMEDIAL_SLOW: return "Tahap Penguatan Khusus Ayat " + getActiveAyahNo();
                case STAGE_VERIFY_AYAH: return "Tahap Verifikasi Nyata Ayat " + getActiveAyahNo();
                case STAGE_COMBINE_BLOCK: return "Tahap Gabung Blok (Rabt Ayat " + getStartAyahNo() + "-" + getEndAyahNo() + ")";
                default: return "Blok Ayat " + getStartAyahNo() + "-" + getEndAyahNo() + " TUNTAS!";
            }
        }
    }

    private static final int[] REP_DAYS = {1, 3, 7, 14};
    private final SharedPreferences prefs;
    private final SmartLearningEngine smart;

    public InteractiveClassroomEngine(Context context) {
        Context appCtx = context.getApplicationContext();
        this.prefs = appCtx.getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
        this.smart = new SmartLearningEngine(appCtx);
    }

    public SmartLearningEngine getSmartEngine() {
        return smart;
    }

    // ================= SESI BELAJAR BLOK TAHAP DEMI TAHAP =================
    public GuidedBlockSession startGuidedBlock(int surahNo, String surahName, int startAyah1Based,
                                               int endAyah1Based, int totalAyahsInSurah) {
        int s = Math.max(1, Math.min(startAyah1Based, Math.max(1, totalAyahsInSurah)));
        int e = Math.max(s, Math.min(endAyah1Based, Math.max(1, totalAyahsInSurah)));
        return new GuidedBlockSession(surahNo, surahName, s - 1, e - 1);
    }

    /**
     * Memproses respon jujur santri setelah memutar ayat aktif di dalam blok.
     * Mengubah tahap, metode, kecepatan, dan mencatat pola kesulitan ke SmartLearningEngine.
     */
    public void handleStudentBlockResponse(GuidedBlockSession session, String responseCode, int activeAyahWordCount) {
        if (session == null) return;
        int ayahNo = session.getActiveAyahNo();

        if (RESP_LANCAR.equals(responseCode)) {
            session.stage = STAGE_VERIFY_AYAH;
            session.lastTeacherNote = "Bagus! Karena kamu merasa ayat " + ayahNo
                    + " sudah lengket, ayo buktikan lewat Setoran Suara Mikrofon (minimal 75%) atau Uji Sambung Ayat sebelum kita lanjut ke langkah berikutnya.";
            return;
        }

        // Santri mengaku masih sulit / ragu -> sistem langsung beradaptasi!
        session.struggleOnActive++;
        session.stage = STAGE_REMEDIAL_SLOW;
        markDifficultAyah(session.surahNo, ayahNo);

        if (RESP_SULIT_NAPAS.equals(responseCode)) {
            smart.recordDifficultyPattern(SmartLearningEngine.ERR_LONG_BREATH);
            session.suggestedMethodIndex = 2; // Penggal Napas Waqaf
            session.suggestedSpeed = 0.75f;
            session.suggestedRepeat = 2;
            session.suggestedPauseSec = 5;
            session.lastTeacherNote = "Tenang, tidak apa-apa napas terasa pendek di ayat " + ayahNo
                    + ". Sistem otomatis mengganti metode ke Penggal Napas Waqaf (tempo 0,75x, jeda 5 detik). Putar lagi pelan-pelan ya.";
        } else if (RESP_SULIT_MAKHRAJ.equals(responseCode)) {
            smart.recordDifficultyPattern(SmartLearningEngine.ERR_PRONUNCIATION);
            session.suggestedMethodIndex = 1; // Talaqqi Per Kata
            session.suggestedSpeed = 0.75f;
            session.suggestedRepeat = 3;
            session.suggestedPauseSec = 4;
            session.lastTeacherNote = "Baik, mari kita bedah ayat " + ayahNo
                    + " kata demi kata dengan tempo pelan 0,75x agar makhraj dan panjang-pendeknya makin bersih.";
        } else if (RESP_RAGU_SAMBUNG.equals(responseCode)) {
            smart.recordDifficultyPattern(SmartLearningEngine.ERR_TRANSITION);
            session.suggestedMethodIndex = 8; // Tautan Engsel
            session.suggestedSpeed = 1.0f;
            session.suggestedRepeat = 3;
            session.suggestedPauseSec = 4;
            session.lastTeacherNote = "Pola keraguan perpindahan ayat tercatat. Sistem mengarahkan ke Metode Tautan Engsel untuk mengunci sambungan ayat "
                    + ayahNo + " ke ayat berikutnya.";
        } else {
            // RESP_TERTUKAR
            smart.recordDifficultyPattern(SmartLearningEngine.ERR_SIMILAR);
            session.suggestedMethodIndex = 11; // Audio Buka-Tutup
            session.suggestedSpeed = 1.0f;
            session.suggestedRepeat = 2;
            session.suggestedPauseSec = 5;
            session.lastTeacherNote = "Agar tidak tertukar di ujung ayat " + ayahNo
                    + ", sistem mengaktifkan Metode Audio Buka-Tutup supaya kamu berlatih meneruskan akhir ayat secara mandiri.";
        }

        if (session.struggleOnActive >= 3) {
            smart.addTomorrowRetryItem(session.surahNo, session.surahName, ayahNo);
            smart.saveDifficultBlock(session.surahNo, session.surahName, session.getStartAyahNo(), session.getEndAyahNo());
            session.lastTeacherNote += "\n\n[Deteksi Pintar] Karena sudah 3x tersendat di ayat " + ayahNo
                    + ", blok ayat " + session.getStartAyahNo() + "-" + session.getEndAyahNo()
                    + " otomatis disimpan ke Antrean Penguatan Besok agar terus dikawal sampai tuntas.";
        }
    }

    /**
     * Dipanggil SETELAH santri benar-benar lulus verifikasi (Mic >= 75% atau Kuis Sambung benar)
     * pada ayat aktif dalam sesi blok.
     */
    public boolean completeVerifiedAyahInBlock(GuidedBlockSession session, int scorePct) {
        if (session == null) return false;
        int ayahNo = session.getActiveAyahNo();
        int curPct = getAyahMastery(session.surahNo, ayahNo);
        int nextPct = Math.max(curPct + 35, scorePct >= 85 ? 100 : 75);
        setAyahMastery(session.surahNo, ayahNo, nextPct);
        smart.recordAyahAttemptAndCheckIntervention(session.surahNo, session.surahName, ayahNo, 8, true);
        smart.appendMutabaah("Blok Terpimpin", session.surahName + ":" + ayahNo, nextPct, "Lulus verifikasi (" + scorePct + "%)");

        session.struggleOnActive = 0;
        if (session.activeIdx < session.endIdx) {
            session.activeIdx++;
            session.stage = STAGE_LISTEN_REPEAT;
            session.suggestedMethodIndex = 0;
            session.suggestedSpeed = 1.0f;
            session.lastTeacherNote = "Alhamdulillah, ayat " + ayahNo + " lulus (" + scorePct
                    + "%)! Sekarang kita lanjut tahap berikutnya: Ayat " + session.getActiveAyahNo()
                    + " (dari blok " + session.getStartAyahNo() + "-" + session.getEndAyahNo() + ").";
            return false;
        } else {
            if (session.getTotalBlockAyahs() >= 2) {
                session.stage = STAGE_COMBINE_BLOCK;
                session.suggestedMethodIndex = 5; // Tikrar Berantai / Gabung Blok
                session.suggestedSpeed = 1.0f;
                session.lastTeacherNote = "MasyaAllah! Seluruh ayat " + session.getStartAyahNo()
                        + " sampai " + session.getEndAyahNo() + " sudah lulus per ayat. "
                        + "Tahap terakhir: putar Gabungan Blok (Rabt) dari ayat " + session.getStartAyahNo()
                        + " sampai " + session.getEndAyahNo() + " agar menyatu utuh!";
            } else {
                session.stage = STAGE_BLOCK_COMPLETE;
                session.lastTeacherNote = "MasyaAllah! Target ayat " + ayahNo + " tuntas dengan baik!";
            }
            return true;
        }
    }

    public void finishCombineBlock(GuidedBlockSession session) {
        if (session == null) return;
        session.stage = STAGE_BLOCK_COMPLETE;
        for (int idx = session.startIdx; idx <= session.endIdx; idx++) {
            int ayahNo = idx + 1;
            if (getAyahMastery(session.surahNo, ayahNo) < 100) {
                setAyahMastery(session.surahNo, ayahNo, 100);
            }
        }
        if (smart.hasActiveDifficultBlock() && smart.getDifficultBlockSurah() == session.surahNo) {
            smart.clearDifficultBlock();
        }
        smart.logAutoStudySession(
                session.surahName + " Blok " + session.getStartAyahNo() + "-" + session.getEndAyahNo(),
                "Blok Terpimpin Bertahap",
                Math.max(3, session.getTotalBlockAyahs() * 2),
                95
        );
        session.lastTeacherNote = "Alhamdulillah! Blok " + session.surahName + " ayat "
                + session.getStartAyahNo() + " sampai " + session.getEndAyahNo()
                + " resmi TUNTAS 100% Hijau, masuk jadwal Anti-Lupa 1-3-7-14 hari, dan menyuburkan Pohon Hafalanmu!";
    }

    // ================= PETA KEKUATAN AYAT 0-100% =================
    public int getAyahMastery(int surahNo, int ayahNo) {
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_AYAH_MASTERY_JSON, "{}"));
            return obj.optInt(surahNo + ":" + ayahNo, 0);
        } catch (Exception ignored) {
            return 0;
        }
    }

    public void setAyahMastery(int surahNo, int ayahNo, int scorePct) {
        int clamped = Math.max(0, Math.min(100, scorePct));
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_AYAH_MASTERY_JSON, "{}"));
            obj.put(surahNo + ":" + ayahNo, clamped);
            prefs.edit().putString(AppConfig.KEY_AYAH_MASTERY_JSON, obj.toString()).apply();
            if (clamped >= 100) {
                scheduleSpacedRepetition(surahNo, ayahNo);
                removeDifficultAyah(surahNo, ayahNo);
                smart.removeTomorrowRetryItem(surahNo, ayahNo);
            }
        } catch (Exception ignored) {}
    }

    public void bumpAyahMastery(int surahNo, int ayahNo, int delta) {
        setAyahMastery(surahNo, ayahNo, getAyahMastery(surahNo, ayahNo) + delta);
    }

    public String getMasteryBadge(int pct) {
        if (pct >= 100) return "HIJAU 100% (Hafal Kuat)";
        if (pct >= 60) return "KUNING " + pct + "% (Mulai Lengket)";
        if (pct > 0) return "MERAH " + pct + "% (Baru Kenal)";
        return "MERAH 0% (Belum Dilatih)";
    }

    public String buildSurahStrengthMap(int surahNo, String surahName, int totalAyahs) {
        int hijau = 0, kuning = 0, merah = 0;
        StringBuilder detail = new StringBuilder();
        for (int a = 1; a <= totalAyahs; a++) {
            int p = getAyahMastery(surahNo, a);
            if (p >= 100) hijau++;
            else if (p >= 60) kuning++;
            else merah++;
            if (a <= 20) {
                detail.append("• Ayat ").append(a).append(": ").append(getMasteryBadge(p)).append("\n");
            }
        }
        int avg = totalAyahs > 0 ? ((hijau * 100 + kuning * 65 + merah * 10) / totalAyahs) : 0;
        return "PETA KEKUATAN SURAT " + surahName.toUpperCase() + " (" + avg + "%)\n"
                + "Hijau (100% Kuat): " + hijau + " | Kuning: " + kuning + " | Merah: " + merah + "\n\n" + detail;
    }

    public List<Integer> getWeakAyahIndices(int surahNo, int totalAyahs) {
        List<Integer> weak = new ArrayList<>();
        for (int a = 1; a <= totalAyahs; a++) {
            if (getAyahMastery(surahNo, a) < 100) weak.add(a - 1);
        }
        return weak;
    }

    // ================= DAFTAR AYAT SULIT =================
    public void markDifficultAyah(int surahNo, int ayahNo) {
        try {
            JSONArray arr = new JSONArray(prefs.getString(AppConfig.KEY_DIFFICULT_AYAHS_JSON, "[]"));
            String key = surahNo + ":" + ayahNo;
            for (int i = 0; i < arr.length(); i++) {
                if (key.equals(arr.getString(i))) return;
            }
            arr.put(key);
            prefs.edit().putString(AppConfig.KEY_DIFFICULT_AYAHS_JSON, arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public void removeDifficultAyah(int surahNo, int ayahNo) {
        try {
            JSONArray arr = new JSONArray(prefs.getString(AppConfig.KEY_DIFFICULT_AYAHS_JSON, "[]"));
            JSONArray out = new JSONArray();
            String key = surahNo + ":" + ayahNo;
            for (int i = 0; i < arr.length(); i++) {
                if (!key.equals(arr.getString(i))) out.put(arr.getString(i));
            }
            prefs.edit().putString(AppConfig.KEY_DIFFICULT_AYAHS_JSON, out.toString()).apply();
        } catch (Exception ignored) {}
    }

    public List<String> getDifficultAyahKeys() {
        List<String> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString(AppConfig.KEY_DIFFICULT_AYAHS_JSON, "[]"));
            for (int i = 0; i < arr.length(); i++) out.add(arr.getString(i));
        } catch (Exception ignored) {}
        return out;
    }

    // ================= ANTI-LUPA 1-3-7-14 HARI (SPACED REPETITION) =================
    public void scheduleSpacedRepetition(int surahNo, int ayahNo) {
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_SPACED_REP_JSON, "{}"));
            String k = surahNo + ":" + ayahNo;
            JSONObject item = obj.optJSONObject(k);
            int stage = item != null ? item.optInt("stage", 0) : 0;
            if (stage >= REP_DAYS.length) return; // Sudah Emas / Mutqin
            if (item != null && item.optLong("dueMs", 0L) > System.currentTimeMillis()) return;
            long nextDue = System.currentTimeMillis() + (REP_DAYS[stage] * 86_400_000L);
            JSONObject updated = new JSONObject();
            updated.put("stage", stage);
            updated.put("dueMs", nextDue);
            obj.put(k, updated);
            prefs.edit().putString(AppConfig.KEY_SPACED_REP_JSON, obj.toString()).apply();
        } catch (Exception ignored) {}
    }

    public String advanceSpacedRepetition(int surahNo, int ayahNo) {
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_SPACED_REP_JSON, "{}"));
            String k = surahNo + ":" + ayahNo;
            JSONObject item = obj.optJSONObject(k);
            int nextStage = (item != null ? item.optInt("stage", 0) : 0) + 1;
            JSONObject updated = new JSONObject();
            updated.put("stage", nextStage);
            if (nextStage >= REP_DAYS.length) {
                updated.put("dueMs", Long.MAX_VALUE);
                obj.put(k, updated);
                prefs.edit().putString(AppConfig.KEY_SPACED_REP_JSON, obj.toString()).apply();
                return "MasyaAllah! Ayat ini resmi naik menjadi HAFALAN EMAS (Mutqin Permanen) dan menambah buah emas di Pohon Hafalanmu!";
            } else {
                updated.put("dueMs", System.currentTimeMillis() + (REP_DAYS[nextStage] * 86_400_000L));
                obj.put(k, updated);
                prefs.edit().putString(AppConfig.KEY_SPACED_REP_JSON, obj.toString()).apply();
                return "Bagus! Murajaah Anti-Lupa berikutnya dijadwalkan " + REP_DAYS[nextStage] + " hari lagi.";
            }
        } catch (Exception ignored) {
            return "Murajaah tercatat.";
        }
    }

    public List<String> getDueReviewAyahs() {
        List<String> due = new ArrayList<>();
        long now = System.currentTimeMillis();
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_SPACED_REP_JSON, "{}"));
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                JSONObject it = obj.optJSONObject(k);
                if (it != null && it.optLong("dueMs", Long.MAX_VALUE) <= now) due.add(k);
            }
        } catch (Exception ignored) {}
        return due;
    }

    public int countGoldMutqinAyahs() {
        int c = 0;
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_SPACED_REP_JSON, "{}"));
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                JSONObject it = obj.optJSONObject(keys.next());
                if (it != null && it.optInt("stage", 0) >= REP_DAYS.length) c++;
            }
        } catch (Exception ignored) {}
        return c;
    }

    public int countMasteredAyahs() {
        int c = 0;
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_AYAH_MASTERY_JSON, "{}"));
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                if (obj.optInt(keys.next(), 0) >= 100) c++;
            }
        } catch (Exception ignored) {}
        return c;
    }

    // ================= POHON HAFALAN PONDOK (TERHUBUNG LANGSUNG KE AYAT NYATA) =================
    public String buildPohonHafalanSummary(int unlockedSurahs) {
        int mastered = countMasteredAyahs();
        int gold = countGoldMutqinAyahs();
        int due = getDueReviewAyahs().size();
        int difficult = getDifficultAyahKeys().size();

        String stage;
        if (gold >= 20 || mastered >= 120) stage = "Pohon Emas Berbuah Lebat";
        else if (mastered >= 40) stage = "Pohon Kokoh Berbunga";
        else if (mastered >= 10) stage = "Pohon Muda Berdaun Rimbun";
        else if (mastered >= 1) stage = "Tunas Hijau Mulai Tumbuh";
        else stage = "Benih Baru (Belum Ada Ayat 100% Hijau)";

        String health = due == 0
                ? "Segar & Terawat (0 ayat layu/jatuh tempo)"
                : "Butuh Siraman Murajaah (" + due + " ayat jatuh tempo Anti-Lupa!)";

        return "POHON HAFALAN PONDOK — " + stage + "\n"
                + "• Kondisi Pohon: " + health + "\n"
                + "• Daun Hijau (Ayat 100% Kuat): " + mastered + " ayat\n"
                + "• Buah Emas (Mutqin 1-3-7-14 Hari): " + gold + " ayat\n"
                + "• Surat Juz 30 Terbuka: " + unlockedSurahs + " / 37 surat\n"
                + "• Ayat Perlu Penguatan: " + difficult + " ayat\n"
                + "• " + buildKhatamCountdownText();
    }

    // ================= TARGET KHATAM PRIBADI =================
    public void setKhatamTargetDays(int days) {
        prefs.edit()
                .putInt(AppConfig.KEY_KHATAM_TARGET_DAYS, Math.max(7, days))
                .putLong(AppConfig.KEY_KHATAM_START_EPOCH, System.currentTimeMillis())
                .apply();
    }

    public String buildKhatamCountdownText() {
        int target = prefs.getInt(AppConfig.KEY_KHATAM_TARGET_DAYS, 60);
        long start = prefs.getLong(AppConfig.KEY_KHATAM_START_EPOCH, System.currentTimeMillis());
        int elapsed = (int) ((System.currentTimeMillis() - start) / 86_400_000L);
        int left = Math.max(1, target - elapsed);
        int remAyahs = Math.max(1, 564 - countMasteredAyahs());
        int perDay = Math.max(1, (int) Math.ceil((double) remAyahs / left));
        return "Target Khatam Juz 30: Sisa " + left + " hari (dari " + target + " hari) — Cukup " + perDay + " ayat/hari.";
    }

    // ================= 6 SURAT PILIHAN & ANALISIS KESULITAN =================
    public boolean isSixSelectedSurah(int surahNo) {
        for (int s : AppConfig.SIX_SELECTED_SURAHS) {
            if (s == surahNo) return true;
        }
        return false;
    }

    public int countMasteredInSurah(int surahNo, int maxCheckAyahs) {
        int c = 0;
        for (int a = 1; a <= maxCheckAyahs; a++) {
            if (getAyahMastery(surahNo, a) >= 85) c++;
        }
        return c;
    }

    public String checkSixSurahSpecialMentorTrigger(int surahNo, String surahName, int totalAyahs) {
        if (!isSixSelectedSurah(surahNo)) return null;
        int mastered = countMasteredInSurah(surahNo, Math.min(totalAyahs, 110));
        if (mastered == 3 || mastered == 10) {
            return "MasyaAllah! Kamu sudah menguasai " + mastered + " ayat 100% Hijau di Surat Pilihan "
                    + surahName + ". Kamu diarahkan ke Ruang Pembimbing Khusus untuk setoran bimbingan langsung!";
        }
        return null;
    }

    public int getUnlockedLearningTier(int jenjangIdx) {
        int mastered = countMasteredAyahs();
        if (jenjangIdx >= 3 || mastered >= 30) return 4;
        if (jenjangIdx >= 2 || mastered >= 15) return 3;
        if (jenjangIdx >= 1 || mastered >= 5) return 2;
        return 1;
    }

    public String buildSurahDifficultyAnalysis(int surahNo, String surahName, List<QuranRepository.AyahItem> ayahs) {
        if (ayahs == null || ayahs.isEmpty()) return "Data ayat belum dimuat.";
        int green = 0, yellow = 0, red = 0;
        int hardestAyahNo = 1;
        int lowestPct = 101;
        for (QuranRepository.AyahItem a : ayahs) {
            int p = getAyahMastery(surahNo, a.nomorAyat);
            if (p >= 85) green++;
            else if (p >= 50) yellow++;
            else red++;
            if (p < lowestPct) {
                lowestPct = p;
                hardestAyahNo = a.nomorAyat;
            }
        }
        return "Analisis Kesulitan Nyata — " + surahName + " (" + ayahs.size() + " ayat):\n"
                + "• Hijau (Mutqin >=85%): " + green + " ayat\n"
                + "• Kuning (Berkembang 50-84%): " + yellow + " ayat\n"
                + "• Merah (Perlu Penguatan <50%): " + red + " ayat\n"
                + "• Titik Paling Lemah Saat Ini: Ayat " + hardestAyahNo + " (" + lowestPct + "%)\n"
                + "Saran Guru: Mulai Sesi Blok Terpimpin dari Ayat " + hardestAyahNo + " dulu!";
    }

    public String evaluatePromotionEligibility(int curJenjang, int attPct, int finalGrade, int mahadSks) {
        int mastered = countMasteredAyahs();
        if (curJenjang >= AppConfig.JENJANG_LABELS.length - 1) {
            return "LULUS_MAHAD: Kamu sudah di jenjang tertinggi Ma'had Aly! Total ayat hijau: " + mastered + ", SKS: " + mahadSks + ".";
        }
        int reqAyat = (curJenjang + 1) * 5;
        int reqGrade = 75;
        int reqAtt = 75;
        if (mastered >= reqAyat && finalGrade >= reqGrade && attPct >= reqAtt) {
            return "SIAP_NAIK: Syarat terpenuhi! (Ayat Hijau " + mastered + "/" + reqAyat
                    + ", Nilai " + finalGrade + "/" + reqGrade + ", Kehadiran " + attPct + "%/" + reqAtt + "%).";
        }
        return "BELUM_SIAP: Untuk naik dari " + AppConfig.JENJANG_LABELS[curJenjang]
                + " butuh minimal " + reqAyat + " ayat hijau (saat ini " + mastered
                + "), nilai akhir " + reqGrade + " (saat ini " + finalGrade
                + "), dan kehadiran " + reqAtt + "% (saat ini " + attPct + "%).";
    }

    // ================= DELEGASI KOMPATIBILITAS KE SmartLearningEngine =================
    public void ensureFirstJoinRecorded() { smart.ensureFirstJoinRecorded(); }
    public int getDayNumberAtPondok() { return smart.getDayNumberAtPondok(); }
    public boolean isTaarufCompleted() { return smart.isTaarufCompleted(); }
    public void markTaarufCompleted() { smart.markTaarufCompleted(); }
    public void recordSuccessAtCurrentHour() { smart.recordSuccessAtCurrentHour(); }
    public String getGoldenHourAdvice() { return smart.getGoldenHourAdvice(); }
    public void recordDifficultyPattern(String p) { smart.recordDifficultyPattern(p); }
    public boolean isEarlyFuturDetected() { return smart.isEarlyFuturDetected(); }
    public int computeExamReadinessPct(int attPct, int finalGrade) {
        return smart.computeExamReadinessPct(attPct, finalGrade, countMasteredAyahs(), getDueReviewAyahs().size());
    }
    public void appendMutabaah(String jenis, String surahAyah, int kelancaranPct, String catatan) {
        smart.appendMutabaah(jenis, surahAyah, kelancaranPct, catatan);
    }
    public String buildMutabaahReport(String nama, String nis) { return smart.buildMutabaahReport(nama, nis); }
    public void addCloseness(int pts) { smart.addCloseness(pts); }
    public String getClosenessLabel() { return smart.getClosenessLabel(); }
    public String recordAyahAttemptAndCheckIntervention(int surahNo, String surahName, int ayahNo, boolean success) {
        if (success) {
            bumpAyahMastery(surahNo, ayahNo, 25);
        } else {
            markDifficultAyah(surahNo, ayahNo);
        }
        return smart.recordAyahAttemptAndCheckIntervention(surahNo, surahName, ayahNo, 8, success);
    }
    public void addTomorrowRetryItem(int s, String n, int a) { smart.addTomorrowRetryItem(s, n, a); }
    public List<String> getTomorrowRetryItems() { return smart.getTomorrowRetryItems(); }
    public String buildTomorrowRetryBanner() { return smart.buildTomorrowRetryBanner(); }
    public void clearTomorrowRetryQueue() { smart.clearTomorrowRetryQueue(); }
    public void logAutoStudySession(String topic, String methodUsed, int minutes, int scorePct) {
        smart.logAutoStudySession(topic, methodUsed, minutes, scorePct);
    }
    public String buildHonestStrictFeedback(int scorePct, String surahName, int ayahNo) {
        return smart.buildHonestStrictFeedback(scorePct, surahName, ayahNo);
    }
    public String buildDiagnosticAbilityReport(int attPct, int finalGrade, int iqraLevel) {
        return smart.buildSmartDiagnosisReport(attPct, finalGrade, iqraLevel,
                countMasteredAyahs(), getDueReviewAyahs().size(), 8, 50, false);
    }
    public void saveDifficultBlock(int s, String n, int st, int en) { smart.saveDifficultBlock(s, n, st, en); }
    public boolean hasActiveDifficultBlock() { return smart.hasActiveDifficultBlock(); }
    public int getDifficultBlockSurah() { return smart.getDifficultBlockSurah(); }
    public String getDifficultBlockName() { return smart.getDifficultBlockName(); }
    public int getDifficultBlockStart() { return smart.getDifficultBlockStart(); }
    public int getDifficultBlockEnd() { return smart.getDifficultBlockEnd(); }
    public String getDifficultBlockSummary() { return smart.getDifficultBlockSummary(); }
    public void clearDifficultBlock() { smart.clearDifficultBlock(); }
}
