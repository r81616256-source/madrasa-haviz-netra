package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

/**
 * Mesin Sarana & Perangkat Digital Interaktif Nyata (v7.0 — Bukan Pajangan).
 * Setiap perangkat di Gedung Kelas, Kantor TU, Masjid Agung, dan Rumah Santri
 * memiliki kondisi nyata (0-100%), terhubung ke fungsi asli aplikasi, dan dapat
 * dirawat atau diservis melalui Koperasi Pondok.
 */
public class FacilityDeviceEngine {

    public static final String DEV_MESIN_PRESENSI = "kelas_mesin_presensi";
    public static final String DEV_SMARTBOARD_AUDIO = "kelas_smartboard_audio";
    public static final String DEV_KOMPUTER_LAB = "kelas_komputer_lab";

    public static final String DEV_MESIN_ANTREAN = "tu_mesin_antrean";
    public static final String DEV_SERVER_TU = "tu_server_komputer";
    public static final String DEV_PRINTER_RESMI = "tu_printer_resmi";
    public static final String DEV_MIKROFON_CORONG = "tu_mikrofon_corong";

    public static final String DEV_SOUND_SYSTEM = "masjid_sound_system";
    public static final String DEV_JAM_DIGITAL = "masjid_jam_digital";

    public static final String DEV_SPEAKER_MUROTTAL = "rumah_speaker_murottal";
    public static final String DEV_MUSHAF_DIGITAL = "rumah_mushaf_digital";
    public static final String DEV_BUKU_CATATAN = "rumah_buku_catatan";

    public static class DeviceInfo {
        public final String id;
        public final String location;
        public final String name;
        public final String functionDesc;
        public final int conditionPct;

        public DeviceInfo(String id, String location, String name, String functionDesc, int conditionPct) {
            this.id = id;
            this.location = location;
            this.name = name;
            this.functionDesc = functionDesc;
            this.conditionPct = conditionPct;
        }

        public String getConditionLabel() {
            if (conditionPct >= 80) return "Prima (" + conditionPct + "%)";
            if (conditionPct >= 50) return "Normal (" + conditionPct + "%)";
            if (conditionPct >= 25) return "Perlu Perawatan di Koperasi (" + conditionPct + "%)";
            return "Butuh Servis Segera di Koperasi (" + conditionPct + "%)";
        }
    }

    private final SharedPreferences prefs;

    public FacilityDeviceEngine(Context context) {
        this.prefs = context.getApplicationContext().getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
    }

    public int getCondition(String deviceId) {
        return Math.max(10, Math.min(100, prefs.getInt("v7_dev_cond_" + deviceId, 95)));
    }

    /**
     * Dipanggil ketika santri memakai perangkat secara nyata; menurunkan kondisi sedikit
     * agar terasa hidup dan mendorong kebiasaan merawat fasilitas pondok.
     */
    public String useDevice(String deviceId, String actionNote) {
        int cur = getCondition(deviceId);
        int next = Math.max(20, cur - 3);
        prefs.edit().putInt("v7_dev_cond_" + deviceId, next).apply();
        DeviceInfo info = getDeviceInfo(deviceId);
        String warn = next < 50 ? " Perangkat ini mulai butuh perawatan di Koperasi Pondok." : "";
        return info.name + " digunakan (" + actionNote + "). Kondisi: " + next + "%." + warn;
    }

    /**
     * Merawat/menyervis perangkat melalui Koperasi Pondok hingga kembali 100% prima.
     */
    public String serviceDeviceAtKoperasi(String deviceId) {
        prefs.edit().putInt("v7_dev_cond_" + deviceId, 100).apply();
        DeviceInfo info = getDeviceInfo(deviceId);
        return "Alhamdulillah, " + info.name + " (" + info.location + ") selesai dirawat melalui Koperasi Pondok. Kondisi kembali 100% prima!";
    }

    public String serviceAllDevicesAtKoperasi() {
        for (DeviceInfo d : getAllDevices()) {
            prefs.edit().putInt("v7_dev_cond_" + d.id, 100).apply();
        }
        return "Seluruh 12 sarana & perangkat digital Pondok Hafidz Netra telah dibersihkan dan diservis lewat Koperasi Pondok. Semua kembali 100% prima!";
    }

    public DeviceInfo getDeviceInfo(String id) {
        for (DeviceInfo d : getAllDevices()) {
            if (d.id.equals(id)) return d;
        }
        return new DeviceInfo(id, "Pondok", "Perangkat Digital", "Sarana pendukung pondok", getCondition(id));
    }

    public List<DeviceInfo> getDevicesByLocation(String locationKey) {
        List<DeviceInfo> out = new ArrayList<>();
        for (DeviceInfo d : getAllDevices()) {
            if (d.location.equalsIgnoreCase(locationKey)) out.add(d);
        }
        return out;
    }

    public List<DeviceInfo> getAllDevices() {
        List<DeviceInfo> list = new ArrayList<>();
        list.add(new DeviceInfo(DEV_MESIN_PRESENSI, "KELAS", "Mesin Presensi Digital",
                "Mencatat kehadiran kelas 5 status secara otomatis.", getCondition(DEV_MESIN_PRESENSI)));
        list.add(new DeviceInfo(DEV_SMARTBOARD_AUDIO, "KELAS", "Smartboard Audio Kelas",
                "Menyajikan materi hari ini dan blok hafalan terarah.", getCondition(DEV_SMARTBOARD_AUDIO)));
        list.add(new DeviceInfo(DEV_KOMPUTER_LAB, "KELAS", "Komputer Lab Tajwid & Evaluasi",
                "Menjalankan analisis kesulitan ayat dan ujian anti-klik-sembarangan.", getCondition(DEV_KOMPUTER_LAB)));

        list.add(new DeviceInfo(DEV_MESIN_ANTREAN, "TU", "Mesin Antrean Loket TU",
                "Mengatur nomor antrean layanan Kantor TU Ustadzah Nur.", getCondition(DEV_MESIN_ANTREAN)));
        list.add(new DeviceInfo(DEV_SERVER_TU, "TU", "Komputer Server TU",
                "Menerima catatan/PR rumah santri dan memverifikasi NIS Firebase.", getCondition(DEV_SERVER_TU)));
        list.add(new DeviceInfo(DEV_PRINTER_RESMI, "TU", "Printer Dokumen Resmi",
                "Mencetak KTS, SK PSB, Rapor Gelar Kehormatan, dan Buku Absensi PNG+Teks.", getCondition(DEV_PRINTER_RESMI)));
        list.add(new DeviceInfo(DEV_MIKROFON_CORONG, "TU", "Mikrofon Corong Pondok",
                "Menyiarkan pengumuman pondok dan pesan semangat ke Firebase.", getCondition(DEV_MIKROFON_CORONG)));

        list.add(new DeviceInfo(DEV_SOUND_SYSTEM, "MASJID", "Sound System Masjid Agung",
                "Mengalirkan lantunan Qari Yasin/Tahlil, Wirid Sore, dan Majelis Malam Jumat.", getCondition(DEV_SOUND_SYSTEM)));
        list.add(new DeviceInfo(DEV_JAM_DIGITAL, "MASJID", "Jam Digital Waktu & Jadwal Masjid",
                "Menampilkan jam dunia nyata, tanggal Hijriah, dan jadwal alarm otomatis.", getCondition(DEV_JAM_DIGITAL)));

        list.add(new DeviceInfo(DEV_SPEAKER_MUROTTAL, "RUMAH", "Speaker Murottal Rumah",
                "Memutar murajaah santai surat pilihan 24 jam di Rumah Santri.", getCondition(DEV_SPEAKER_MUROTTAL)));
        list.add(new DeviceInfo(DEV_MUSHAF_DIGITAL, "RUMAH", "Mushaf Audio & Braille Digital",
                "Meja belajar bebas Juz 1-30, 20 metode hafalan, dan Iqra' manual.", getCondition(DEV_MUSHAF_DIGITAL)));
        list.add(new DeviceInfo(DEV_BUKU_CATATAN, "RUMAH", "Buku Catatan & Jurnal Digital",
                "Menulis jurnal refleksi dan catatan PR rumah lalu mengirimnya ke Server TU.", getCondition(DEV_BUKU_CATATAN)));
        return list;
    }

    public int countDevicesNeedingCare() {
        int c = 0;
        for (DeviceInfo d : getAllDevices()) {
            if (d.conditionPct < 70) c++;
        }
        return c;
    }

    public String buildLocationDevicesSummary(String locationKey) {
        List<DeviceInfo> list = getDevicesByLocation(locationKey);
        StringBuilder sb = new StringBuilder("Sarana Digital Aktif:\n");
        for (DeviceInfo d : list) {
            sb.append("• ").append(d.name).append(" — ").append(d.getConditionLabel()).append("\n");
        }
        return sb.toString().trim();
    }
}
