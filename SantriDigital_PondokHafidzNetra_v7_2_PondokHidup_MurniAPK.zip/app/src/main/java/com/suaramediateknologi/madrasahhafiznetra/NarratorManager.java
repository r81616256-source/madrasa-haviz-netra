package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Pengelola Narator Hybrid MP3 Ardi/Gadis + TTS Lokal + 6 Bel Asli res/raw (v6.0).
 * - Jeda anti-tabrakan TalkBack/Jieshuo 750 ms (0,75 detik) TANPA membungkam instruksi metode,
 *   arti ayat, daftar doa arwah, atau dialog guru.
 * - Menggunakan seluruh 6 efek suara asli di res/raw/ sesuai fungsinya.
 * - Melepas AudioFocus secara bersih setiap selesai bicara agar suara Jieshuo/TalkBack tidak tertahan pelan.
 */
public class NarratorManager {
    public interface DoneCallback {
        void onDone();
    }

    private static final long TALKBACK_ANTI_COLLISION_MS = 750L;

    private final Context context;
    private final SharedPreferences prefs;
    private final AudioManager audioManager;
    private final QuranRepository repo;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private MediaPlayer narratorPlayer;
    private AudioFocusRequest focusRequest;
    private DoneCallback pendingCallback;
    private Runnable pendingDelayedSpeak;

    public NarratorManager(Context context, QuranRepository repo) {
        this.context = context.getApplicationContext();
        this.repo = repo;
        this.prefs = this.context.getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
        this.audioManager = (AudioManager) this.context.getSystemService(Context.AUDIO_SERVICE);
        initTts();
    }

    public void initTts() {
        releaseTtsOnly();
        String mode = prefs.getString(AppConfig.KEY_TTS_ENGINE_MODE, "SYSTEM");
        TextToSpeech.OnInitListener listener = status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                ttsReady = true;
                tts.setLanguage(new Locale("id", "ID"));
                applySavedVoice();
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) {}

                    @Override public void onDone(String utteranceId) {
                        abandonAudioFocus();
                        DoneCallback cb = pendingCallback;
                        pendingCallback = null;
                        if (cb != null) mainHandler.post(cb::onDone);
                    }

                    @Override public void onError(String utteranceId) {
                        abandonAudioFocus();
                        DoneCallback cb = pendingCallback;
                        pendingCallback = null;
                        if (cb != null) mainHandler.post(cb::onDone);
                    }
                });
            }
        };

        if ("GOOGLE".equals(mode)) {
            tts = new TextToSpeech(context, listener, AppConfig.GOOGLE_TTS_PACKAGE);
        } else {
            tts = new TextToSpeech(context, listener);
        }
    }

    public void setOfflineTtsMode(String mode) {
        prefs.edit().putString(AppConfig.KEY_TTS_ENGINE_MODE, mode).apply();
        initTts();
    }

    public String getOfflineTtsMode() {
        return prefs.getString(AppConfig.KEY_TTS_ENGINE_MODE, "SYSTEM");
    }

    public List<String> getAvailableIndonesianVoices() {
        List<String> names = new ArrayList<>();
        if (tts != null && ttsReady) {
            try {
                Set<Voice> voices = tts.getVoices();
                if (voices != null) {
                    for (Voice v : voices) {
                        Locale loc = v.getLocale();
                        if (loc != null && ("id".equalsIgnoreCase(loc.getLanguage()) || "in".equalsIgnoreCase(loc.getLanguage()))) {
                            names.add(v.getName());
                        }
                    }
                }
            } catch (Exception ignored) {}
        }
        return names;
    }

    public void selectVoiceByName(String voiceName) {
        prefs.edit().putString(AppConfig.KEY_TTS_VOICE_NAME, voiceName).apply();
        applySavedVoice();
    }

    private void applySavedVoice() {
        if (tts == null || !ttsReady) return;
        String saved = prefs.getString(AppConfig.KEY_TTS_VOICE_NAME, "");
        if (saved == null || saved.isEmpty()) return;
        try {
            Set<Voice> voices = tts.getVoices();
            if (voices != null) {
                for (Voice v : voices) {
                    if (saved.equals(v.getName())) {
                        tts.setVoice(v);
                        break;
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private long getAntiCollisionDelayMs() {
        boolean delayOn = prefs.getBoolean(AppConfig.KEY_TALKBACK_DELAY_ENABLED, true)
                || prefs.getBoolean(AppConfig.KEY_ANTI_OVERLAP_TALKBACK, true);
        return delayOn ? TALKBACK_ANTI_COLLISION_MS : 0L;
    }

    /**
     * Memutar MP3 Ustadz Ardi / Ustadzah Gadis dari GitHub Releases, dengan fallback TTS
     * yang TETAP berbunyi setelah jeda aman 0,75 detik (tidak membungkam arti ayat/instruksi metode).
     */
    public void speakHybrid(String mp3FileName, String fallbackText, DoneCallback onDone) {
        stopSpeaking();
        final long delayMs = getAntiCollisionDelayMs();
        if (mp3FileName != null && !mp3FileName.trim().isEmpty()) {
            new Thread(() -> {
                String url = mp3FileName.startsWith("http") ? mp3FileName : AppConfig.RELEASE_BASE_URL + mp3FileName;
                String safeName = "nar_" + mp3FileName.replaceAll("[^a-zA-Z0-9._-]", "_");
                File f = repo.getOrDownloadAudio(url, safeName);
                if (f != null && f.exists()) {
                    pendingDelayedSpeak = () -> {
                        requestAudioFocus();
                        playLocalMp3(f, () -> {
                            abandonAudioFocus();
                            if (onDone != null) onDone.onDone();
                        }, () -> speakOfflineTtsWithDelay(fallbackText, 0L, onDone));
                    };
                    mainHandler.postDelayed(pendingDelayedSpeak, delayMs);
                } else {
                    speakOfflineTtsWithDelay(fallbackText, delayMs, onDone);
                }
            }).start();
        } else {
            speakOfflineTtsWithDelay(fallbackText, delayMs, onDone);
        }
    }

    public void speakOfflineTts(String text, DoneCallback onDone) {
        speakOfflineTtsWithDelay(text, getAntiCollisionDelayMs(), onDone);
    }

    private void speakOfflineTtsWithDelay(String text, long delayMs, DoneCallback onDone) {
        stopSpeaking();
        if (text == null || text.trim().isEmpty()) {
            if (onDone != null) mainHandler.post(onDone::onDone);
            return;
        }
        pendingDelayedSpeak = () -> {
            requestAudioFocus();
            if (tts != null && ttsReady) {
                pendingCallback = onDone;
                String uttId = UUID.randomUUID().toString();
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, uttId);
            } else {
                abandonAudioFocus();
                if (onDone != null) mainHandler.post(onDone::onDone);
            }
        };
        if (delayMs > 0L) {
            mainHandler.postDelayed(pendingDelayedSpeak, delayMs);
        } else {
            mainHandler.post(pendingDelayedSpeak);
        }
    }

    /**
     * Suara karakter pengurus pondok (Ustadz Yeni, Ustadzah Nur, Kang Ridho, Mbak Aisyah, Kak Bilal, Ibu Nyai)
     * dengan pembeda pitch/tempo halus dan jeda anti-tabrakan 0,75 detik.
     */
    public void speakAsCharacter(String characterId, String text, DoneCallback onDone) {
        stopSpeaking();
        if (text == null || text.trim().isEmpty()) {
            if (onDone != null) mainHandler.post(onDone::onDone);
            return;
        }
        long delayMs = getAntiCollisionDelayMs();
        pendingDelayedSpeak = () -> {
            if (tts != null && ttsReady) {
                float pitch = 1.0f;
                float rate = 1.0f;
                if ("YENI".equals(characterId)) { pitch = 0.90f; rate = 0.96f; }
                else if ("SHOLEH".equals(characterId)) { pitch = 0.86f; rate = 0.90f; }
                else if ("RIDHO".equals(characterId)) { pitch = 0.96f; rate = 1.04f; }
                else if ("BILAL".equals(characterId)) { pitch = 1.04f; rate = 1.06f; }
                else if ("AISYAH".equals(characterId)) { pitch = 1.08f; rate = 1.02f; }
                else if ("NYAI".equals(characterId)) { pitch = 0.98f; rate = 0.88f; }
                else if ("NUR".equals(characterId)) { pitch = 1.06f; rate = 0.98f; }
                try {
                    tts.setPitch(pitch);
                    tts.setSpeechRate(rate);
                } catch (Exception ignored) {}
            }
            speakOfflineTtsWithDelay(text, 0L, () -> {
                if (tts != null) {
                    try { tts.setPitch(1.0f); tts.setSpeechRate(1.0f); } catch (Exception ignored) {}
                }
                if (onDone != null) onDone.onDone();
            });
        };
        mainHandler.postDelayed(pendingDelayedSpeak, delayMs);
    }

    // ================= 6 EFEK BEL ASLI res/raw/ (SEMUA TERPAKAI) =================
    public void playTingTungBell(DoneCallback onDone) {
        String customUriStr = prefs.getString(AppConfig.KEY_CUSTOM_ALARM_URI, "");
        if (customUriStr != null && !customUriStr.isEmpty()) {
            playUriAudio(Uri.parse(customUriStr), onDone, () -> playRawSound(R.raw.bel_lift_tingtung, onDone));
            return;
        }
        playRawSound(R.raw.bel_lift_tingtung, onDone);
    }

    public void playClassBell(DoneCallback onDone) {
        playRawSound(R.raw.bel_masuk_kelas, onDone);
    }

    public void playCorongChime(DoneCallback onDone) {
        playRawSound(R.raw.corong_pengumuman, onDone);
    }

    public void playSelectedPondokBell(DoneCallback onDone) {
        int theme = prefs.getInt(AppConfig.KEY_BELL_THEME, 0);
        if (theme == 1) playRawSound(R.raw.bel_lift_tingtung, onDone);
        else if (theme == 2) playRawSound(R.raw.corong_pengumuman, onDone);
        else playRawSound(R.raw.bel_masuk_kelas, onDone);
    }

    public void playImitationBeep() { playRawSound(R.raw.lonceng_giliran_baca, null); }
    public void playCorrectChime() { playRawSound(R.raw.chime_lulus_benar, null); }
    public void playWrongTone() { playRawSound(R.raw.chime_coba_lagi, null); }
    public void playRawEffect(int rawResId, DoneCallback onDone) { playRawSound(rawResId, onDone); }

    private void playRawSound(int rawResId, DoneCallback onDone) {
        mainHandler.post(() -> {
            try {
                requestAudioFocus();
                MediaPlayer mp = MediaPlayer.create(context, rawResId);
                if (mp == null) {
                    abandonAudioFocus();
                    if (onDone != null) onDone.onDone();
                    return;
                }
                mp.setOnCompletionListener(player -> {
                    try { player.release(); } catch (Exception ignored) {}
                    abandonAudioFocus();
                    if (onDone != null) onDone.onDone();
                });
                mp.setOnErrorListener((player, what, extra) -> {
                    try { player.release(); } catch (Exception ignored) {}
                    abandonAudioFocus();
                    if (onDone != null) onDone.onDone();
                    return true;
                });
                mp.start();
            } catch (Exception e) {
                abandonAudioFocus();
                if (onDone != null) onDone.onDone();
            }
        });
    }

    private void playUriAudio(Uri uri, DoneCallback onDone, Runnable onError) {
        releaseNarratorPlayer();
        try {
            requestAudioFocus();
            narratorPlayer = new MediaPlayer();
            narratorPlayer.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            narratorPlayer.setDataSource(context, uri);
            narratorPlayer.setOnCompletionListener(mp -> {
                releaseNarratorPlayer();
                abandonAudioFocus();
                if (onDone != null) onDone.onDone();
            });
            narratorPlayer.setOnErrorListener((mp, what, extra) -> {
                releaseNarratorPlayer();
                abandonAudioFocus();
                if (onError != null) onError.run();
                return true;
            });
            narratorPlayer.prepare();
            narratorPlayer.start();
        } catch (Exception e) {
            releaseNarratorPlayer();
            abandonAudioFocus();
            if (onError != null) onError.run();
        }
    }

    private void playLocalMp3(File file, DoneCallback onDone, Runnable onError) {
        releaseNarratorPlayer();
        try {
            narratorPlayer = new MediaPlayer();
            narratorPlayer.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            narratorPlayer.setDataSource(file.getAbsolutePath());
            narratorPlayer.setOnCompletionListener(mp -> {
                releaseNarratorPlayer();
                if (onDone != null) onDone.onDone();
            });
            narratorPlayer.setOnErrorListener((mp, what, extra) -> {
                releaseNarratorPlayer();
                if (onError != null) onError.run();
                return true;
            });
            narratorPlayer.prepare();
            narratorPlayer.start();
        } catch (Exception e) {
            releaseNarratorPlayer();
            if (onError != null) onError.run();
        }
    }

    // ================= AUDIO FOCUS BERSIH =================
    public void requestAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build())
                        .build();
                audioManager.requestAudioFocus(focusRequest);
            } else {
                audioManager.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
            }
        } catch (Exception ignored) {}
    }

    public void abandonAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && focusRequest != null) {
                audioManager.abandonAudioFocusRequest(focusRequest);
            } else {
                audioManager.abandonAudioFocus(null);
            }
        } catch (Exception ignored) {}
    }

    public void stopSpeaking() {
        if (pendingDelayedSpeak != null) {
            mainHandler.removeCallbacks(pendingDelayedSpeak);
            pendingDelayedSpeak = null;
        }
        pendingCallback = null;
        releaseNarratorPlayer();
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) {}
        }
        abandonAudioFocus();
    }

    private void releaseNarratorPlayer() {
        if (narratorPlayer != null) {
            try {
                if (narratorPlayer.isPlaying()) narratorPlayer.stop();
                narratorPlayer.release();
            } catch (Exception ignored) {}
            narratorPlayer = null;
        }
    }

    private void releaseTtsOnly() {
        if (tts != null) {
            try {
                tts.stop();
                tts.shutdown();
            } catch (Exception ignored) {}
            tts = null;
            ttsReady = false;
        }
    }

    public void shutdown() {
        stopSpeaking();
        releaseTtsOnly();
    }
}
