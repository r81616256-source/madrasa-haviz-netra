package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Mesin Ekonomi Kemandirian Pondok, Panen Pasif, Bangun Gedung Penghasilan,
 * Toko, Dapur Asrama, Kebun & Pasar Pondok (v7.0).
 * - Saldo awal kas pengembangan Pondok: Rp 4.000.000.000 (Rp 4 Miliar).
 * - 5 Gedung Penghasilan & Toko dapat dibangun & ditingkatkan hingga total potensi
 *   penghasilan pasif Rp 500.000.000 (500 Juta) per siklus waktu nyata.
 * - Kebun & Kolam Asrama menghasilkan panen pasif berkala yang bisa dimasak di
 *   Dapur Asrama atau dijual di Pasar Pondok.
 */
public class PondokEconomyEngine {

    public static final long INITIAL_SALDO_PONDOK = 4_000_000_000L; // Rp 4 Miliar
    public static final long TARGET_PASSIVE_CAP = 500_000_000L;     // Rp 500 Juta

    private static final String KEY_SALDO = "v7_econ_saldo_pondok";
    private static final String KEY_TOTAL_INCOME = "v7_econ_total_income";
    private static final String KEY_LAST_PASSIVE_CLAIM = "v7_econ_last_passive_ms";
    private static final String KEY_LAST_GARDEN_HARVEST = "v7_econ_last_garden_ms";
    private static final String KEY_STOK_KEBUN = "v7_econ_stok_kebun";
    private static final String KEY_STOK_KOLAM = "v7_econ_stok_kolam";
    private static final String KEY_STOK_DAPUR = "v7_econ_stok_dapur";

    public static class BuildingUnit {
        public final String id;
        public final String name;
        public final String desc;
        public final long buildCost;
        public final long maxCycleIncome; // Kontribusi menuju Rp 500 Juta
        public final int level;           // 0 = belum dibangun, 1..5 = aktif

        public BuildingUnit(String id, String name, String desc, long buildCost, long maxCycleIncome, int level) {
            this.id = id;
            this.name = name;
            this.desc = desc;
            this.buildCost = buildCost;
            this.maxCycleIncome = maxCycleIncome;
            this.level = level;
        }

        public long getCurrentCycleIncome() {
            if (level <= 0) return 0L;
            return (maxCycleIncome * level) / 5L;
        }

        public long getNextUpgradeCost() {
            if (level <= 0) return buildCost;
            return buildCost / 2L + (level * 50_000_000L);
        }
    }

    private final SharedPreferences prefs;

    public PondokEconomyEngine(Context context) {
        this.prefs = context.getApplicationContext().getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
        if (!prefs.contains(KEY_SALDO)) {
            prefs.edit()
                    .putLong(KEY_SALDO, INITIAL_SALDO_PONDOK)
                    .putLong(KEY_LAST_PASSIVE_CLAIM, System.currentTimeMillis() - 10 * 60_000L)
                    .putLong(KEY_LAST_GARDEN_HARVEST, System.currentTimeMillis() - 10 * 60_000L)
                    .putInt(KEY_STOK_KEBUN, 6)
                    .putInt(KEY_STOK_KOLAM, 4)
                    .putInt(KEY_STOK_DAPUR, 5)
                    .putInt("v7_bld_lvl_toko_kitab", 1) // 1 toko awal sudah berdiri agar langsung menghasilkan
                    .apply();
        }
    }

    public long getSaldoPondok() {
        return prefs.getLong(KEY_SALDO, INITIAL_SALDO_PONDOK);
    }

    public long getTotalIncomeEarned() {
        return prefs.getLong(KEY_TOTAL_INCOME, 0L);
    }

    public int getStokKebun() { return prefs.getInt(KEY_STOK_KEBUN, 0); }
    public int getStokKolam() { return prefs.getInt(KEY_STOK_KOLAM, 0); }
    public int getStokDapurAsrama() { return prefs.getInt(KEY_STOK_DAPUR, 0); }

    public static String formatRupiah(long amount) {
        NumberFormat nf = NumberFormat.getInstance(new Locale("id", "ID"));
        return "Rp " + nf.format(amount);
    }

    public List<BuildingUnit> getAllBuildings() {
        List<BuildingUnit> list = new ArrayList<>();
        list.add(new BuildingUnit("toko_kitab", "Toko Kitab & Mushaf Braille",
                "Menyediakan Al-Qur'an Braille, buku tajwid, dan perangkat belajar netra.",
                250_000_000L, 80_000_000L, prefs.getInt("v7_bld_lvl_toko_kitab", 1)));
        list.add(new BuildingUnit("kantin_jahe", "Kantin & Kedai Jahe Hangat Pondok",
                "Melayani hidangan sehat dan minuman penjaga suara bagi santri & tamu.",
                300_000_000L, 90_000_000L, prefs.getInt("v7_bld_lvl_kantin_jahe", 0)));
        list.add(new BuildingUnit("minimarket_syariah", "Minimarket & Koperasi Syariah",
                "Pusat kebutuhan harian santri, asrama, dan warga sekitar pondok.",
                450_000_000L, 110_000_000L, prefs.getInt("v7_bld_lvl_minimarket_syariah", 0)));
        list.add(new BuildingUnit("studio_audio", "Studio Audio & Percetakan Netra",
                "Produksi buku audio, murottal, dan percetakan edukasi inklusif.",
                500_000_000L, 110_000_000L, prefs.getInt("v7_bld_lvl_studio_audio", 0)));
        list.add(new BuildingUnit("wisma_wali", "Wisma & Guest House Wali Santri",
                "Penginapan nyaman bagi keluarga yang berkunjung saat Sambangan Ahad.",
                600_000_000L, 110_000_000L, prefs.getInt("v7_bld_lvl_wisma_wali", 0)));
        return list;
    }

    public long getTotalCycleIncomeCapacity() {
        long sum = 0L;
        for (BuildingUnit b : getAllBuildings()) {
            sum += b.getCurrentCycleIncome();
        }
        return Math.min(TARGET_PASSIVE_CAP, sum);
    }

    /**
     * Menghitung akumulasi penghasilan pasif nyata berdasarkan waktu yang berlalu.
     * Setiap 15 menit waktu nyata menghasilkan 1 siklus penuh (proporsional per menit, minimal 10% agar terasa hidup).
     */
    public long getPendingPassiveIncome() {
        long capacity = getTotalCycleIncomeCapacity();
        if (capacity <= 0L) return 0L;
        long last = prefs.getLong(KEY_LAST_PASSIVE_CLAIM, System.currentTimeMillis());
        long elapsedMin = Math.max(1L, (System.currentTimeMillis() - last) / 60_000L);
        long ratioPct = Math.min(100L, Math.max(10L, (elapsedMin * 100L) / 15L));
        return (capacity * ratioPct) / 100L;
    }

    public long claimPassiveIncome() {
        long pending = getPendingPassiveIncome();
        if (pending <= 0L) return 0L;
        long newSaldo = getSaldoPondok() + pending;
        long newTotal = getTotalIncomeEarned() + pending;
        prefs.edit()
                .putLong(KEY_SALDO, newSaldo)
                .putLong(KEY_TOTAL_INCOME, newTotal)
                .putLong(KEY_LAST_PASSIVE_CLAIM, System.currentTimeMillis())
                .apply();
        return pending;
    }

    public String buildOrUpgradeUnit(String unitId) {
        BuildingUnit target = null;
        for (BuildingUnit b : getAllBuildings()) {
            if (b.id.equals(unitId)) {
                target = b;
                break;
            }
        }
        if (target == null) return "Unit gedung tidak ditemukan.";
        if (target.level >= 5) return target.name + " sudah mencapai Level Maksimal (Level 5).";

        long cost = target.getNextUpgradeCost();
        long saldo = getSaldoPondok();
        if (saldo < cost) {
            return "Saldo Pondok belum mencukupi (" + formatRupiah(saldo) + "). Butuh " + formatRupiah(cost) + ".";
        }

        int nextLvl = target.level + 1;
        prefs.edit()
                .putLong(KEY_SALDO, saldo - cost)
                .putInt("v7_bld_lvl_" + target.id, nextLvl)
                .apply();

        String verb = (target.level == 0) ? "resmi selesai dibangun (Level 1)" : "berhasil ditingkatkan ke Level " + nextLvl;
        return "Alhamdulillah! " + target.name + " " + verb + " dengan biaya " + formatRupiah(cost)
                + ". Potensi penghasilan pasif pondok kini " + formatRupiah(getTotalCycleIncomeCapacity()) + " per siklus!";
    }

    // ================= KEBUN & KOLAM PANEN PASIF ASRAMA =================

    public String harvestKebunDanKolamAsrama() {
        long last = prefs.getLong(KEY_LAST_GARDEN_HARVEST, 0L);
        long elapsedMin = Math.max(1L, (System.currentTimeMillis() - last) / 60_000L);
        int panenSayur = (int) Math.min(20, Math.max(3, elapsedMin));
        int panenIkan = (int) Math.min(15, Math.max(2, elapsedMin / 2 + 2));

        int nextKebun = getStokKebun() + panenSayur;
        int nextKolam = getStokKolam() + panenIkan;
        prefs.edit()
                .putInt(KEY_STOK_KEBUN, nextKebun)
                .putInt(KEY_STOK_KOLAM, nextKolam)
                .putLong(KEY_LAST_GARDEN_HARVEST, System.currentTimeMillis())
                .apply();
        return "Alhamdulillah panen pasif berhasil! Kebun Asrama menghasilkan +" + panenSayur
                + " keranjang sayur & jahe (total " + nextKebun + "), dan Kolam Berkah +" + panenIkan
                + " paket ikan segar (total " + nextKolam + ").";
    }

    // ================= DAPUR ASRAMA & PASAR PONDOK =================

    public String cookAtDapurAsrama() {
        int kebun = getStokKebun();
        int kolam = getStokKolam();
        int dapur = getStokDapurAsrama();
        if (kebun >= 1 && kolam >= 1) {
            prefs.edit()
                    .putInt(KEY_STOK_KEBUN, kebun - 1)
                    .putInt(KEY_STOK_KOLAM, kolam - 1)
                    .apply();
            return "MasyaAllah, Dapur Asrama memasak ikan segar dan sup jahe dari hasil panen Kebun & Kolam sendiri! Stamina santri pulih +30%.";
        }
        if (dapur >= 1) {
            prefs.edit().putInt(KEY_STOK_DAPUR, dapur - 1).apply();
            return "Alhamdulillah, Dapur Asrama menyajikan hidangan hangat dari persediaan belanja Pasar Pondok! Stamina santri pulih +25%.";
        }
        return "Bahan Dapur Asrama sedang habis. Yuk panen Kebun/Kolam atau belanja bahan segar di Pasar Pondok dulu!";
    }

    public String sellHarvestAtPasarPondok() {
        int kebun = getStokKebun();
        int kolam = getStokKolam();
        if (kebun <= 0 && kolam <= 0) {
            return "Belum ada hasil panen Kebun atau Kolam untuk dijual. Yuk panen dulu di Kebun Asrama!";
        }
        long revenue = (kebun * 2_500_000L) + (kolam * 4_000_000L);
        prefs.edit()
                .putInt(KEY_STOK_KEBUN, 0)
                .putInt(KEY_STOK_KOLAM, 0)
                .putLong(KEY_SALDO, getSaldoPondok() + revenue)
                .putLong(KEY_TOTAL_INCOME, getTotalIncomeEarned() + revenue)
                .apply();
        return "Alhamdulillah! " + kebun + " keranjang kebun & " + kolam + " paket ikan laku terjual di Pasar Pondok sebesar "
                + formatRupiah(revenue) + ". Saldo Kas Pondok bertambah!";
    }

    public String buyKitchenSuppliesAtPasarPondok() {
        long cost = 5_000_000L;
        long saldo = getSaldoPondok();
        if (saldo < cost) {
            return "Saldo Pondok belum cukup untuk belanja grosir Dapur Asrama.";
        }
        int nextDapur = getStokDapurAsrama() + 10;
        prefs.edit()
                .putLong(KEY_SALDO, saldo - cost)
                .putInt(KEY_STOK_DAPUR, nextDapur)
                .apply();
        return "Belanja grosir di Pasar Pondok berhasil (" + formatRupiah(cost)
                + "). Persediaan bahan Dapur Asrama bertambah +10 paket (total " + nextDapur + " paket).";
    }
}
