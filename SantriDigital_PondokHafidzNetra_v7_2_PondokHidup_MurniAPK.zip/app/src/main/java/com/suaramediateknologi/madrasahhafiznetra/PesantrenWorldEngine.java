package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Mesin Dunia Pesantren, Kantor TU Hidup, Koperasi Berkah 0 Rp, & Ekosistem Nyata (v6.0).
 * - Menghapus ekonomi palsu Rp 500 Juta/55 detik: Kebun & Tambak memakai jeda tumbuh nyata
 *   dan mendapat "Embun Hafalan" dari setiap ayat yang benar-benar dikuasai santri.
 * - Dialog Kantor TU Ustadzah Nur kontekstual berdasarkan jam, absen, SP, dan piket.
 * - Dokumen resmi didelegasikan penuh ke OfficialDocumentGenerator.
 */
public class PesantrenWorldEngine {
    private static final String KEY_GARDEN_READY_EPOCH = "v6_garden_ready_epoch";
    private static final String KEY_POND_READY_EPOCH = "v6_pond_ready_epoch";
    private static final String KEY_EMBUN_HAFALAN = "v6_embun_hafalan";
    private static final long GROWTH_STEP_MS = 10 * 60 * 1000L; // 10 menit tumbuh nyata (bisa dipercepat pakai Embun Hafalan!)

    private final SharedPreferences prefs;

    public PesantrenWorldEngine(Context context) {
        this.prefs = context.getApplicationContext()
                .getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
    }

    // ================= SAPAAN KONTEKSTUAL PENGURUS & KANTOR TU HIDUP =================
    public String getKangRidhoGreeting(String nama, SchoolScheduleEngine sched) {
        String p = sched.getBoardingPhase();
        if (sched.isSunday()) {
            return "Kang Ridho (Gerbang): Selamat Hari Ahad, " + nama + "! Kelas wajib libur hari ini, silakan santai atau murajaah ringan.";
        }
        if (SchoolScheduleEngine.PHASE_TENGAH_MALAM.equals(p)) {
            return "Kang Ridho (Piket Malam): Sudah lewat tengah malam, " + nama + ". Jaga kesehatan, kalau mau murajaah tenang bisa di kamar asrama.";
        }
        String st = sched.getClassWindowState();
        if ("ACTIVE_ONTIME".equals(st)) {
            return "Kang Ridho (Gerbang): Assalamu'alaikum " + nama + "! Tepat waktu masuk kelas, semangat ya!";
        }
        if ("ACTIVE_LATE".equals(st)) {
            return "Kang Ridho (Gerbang): Assalamu'alaikum " + nama + ", agak telat sedikit. Gerbang masih terbuka, ayo langsung masuk kelas.";
        }
        return "Kang Ridho (Gerbang): Assalamu'alaikum " + nama + "! Selamat datang di Pondok Hafidz Netra.";
    }

    public String buildDynamicTuGreeting(String nama, LivingMadrasahEngine eng, SchoolScheduleEngine sched) {
        String p = sched.getBoardingPhase();
        String base;
        if (!sched.isTuOfficeOpenNow()) {
            base = "Kang Ridho (Piket Malam TU): Layanan tatap muka Ustadzah Nur buka pukul 07.00-17.00. Loket darurat malam tetap melayani cetak KTS, surat izin mendadak, dan pengumuman.";
        } else if (SchoolScheduleEngine.PHASE_SUBUH.equals(p) || SchoolScheduleEngine.PHASE_PAGI.equals(p)) {
            base = "Ustadzah Nur (Kantor TU Pagi): Wa'alaikumussalam " + nama + ", pagi-pagi sudah rapi datang ke Kantor TU! Silakan duduk dulu.";
        } else if (SchoolScheduleEngine.PHASE_SIANG.equals(p)) {
            base = "Ustadzah Nur (Kantor TU Siang): Wa'alaikumussalam " + nama + ", mumpung jam istirahat siang, ada keperluan berkas, izin, atau kenaikan jenjang?";
        } else {
            base = "Ustadzah Nur (Kantor TU Sore): Wa'alaikumussalam " + nama + ", sore ini TU sedang rekap kehadiran harian pondok.";
        }

        if (!eng.isRegistered()) {
            return base + "\n\nCatatan TU: Data pendaftaran PSB kamu belum tercatat. Silakan mulai Pendaftaran Santri Baru di Loket 1 dulu ya.";
        }
        if (eng.getSpLevel() > 0) {
            return base + "\n\nPerhatian Disiplin: Status kamu sedang " + eng.getSpStatusText()
                    + ". Silakan ke Loket 5 (Banding SP & Ta'zir) untuk pemulihan resmi.";
        }
        if ("NONE".equals(eng.getAttendanceTodayStatus()) && !sched.isHolidayToday() && !sched.isOnCuti()) {
            return base + "\n\nCatatan Absen: Hari ini nama kamu belum tercatat di buku hadir. Kalau sedang berhalangan, ajukan Surat Izin di Loket 2 agar aman dari SP.";
        }
        if (!eng.isPiketDoneThisWeek()) {
            return base + "\n\nInfo Khidmah: Jadwal Piket Pondok pekan ini masih menunggu giliran kamu.";
        }
        if (sched.isThursdayNight()) {
            return base + "\n\nInfo Masjid: Malam Jumat ini pendaftaran nama Doa Arwah sedang dibuka.";
        }
        return base + "\n\nSemua administrasi kamu rapi! Koperasi Berkah 0 Rp (Mbak Aisyah) di sebelah loket juga buka untuk menukar Poin Berkah.";
    }

    public String buildDailyWaliMessage(String nama, LivingMadrasahEngine eng, SchoolScheduleEngine sched, InteractiveClassroomEngine cls) {
        if (sched.isSunday()) {
            return "Pesan Ustadzah Nur: Selamat Hari Ahad, " + nama + "! Istirahat yang cukup ya.";
        }
        int due = cls.getDueReviewAyahs().size();
        if (due > 0) {
            return "Pesan Ustadzah Nur: Ada " + due + " ayat di Pohon Hafalan yang jatuh tempo murajaah Anti-Lupa hari ini. Yuk siram dulu agar tidak layu!";
        }
        int diff = cls.getDifficultAyahKeys().size();
        if (diff > 0) {
            return "Pesan Ustadzah Nur: Ada " + diff + " ayat sulit yang kemarin ditandai. Kita taklukkan pelan-pelan pakai Sesi Blok Terpimpin hari ini.";
        }
        if (eng.getSpLevel() > 0) {
            return "Pesan Ustadzah Nur: Statusmu sedang " + eng.getSpStatusText() + ". Selesaikan Ta'zir di Loket 5 TU supaya aktif bersih lagi ya.";
        }
        return "Pesan Ustadzah Nur: MasyaAllah " + nama + ", terus jaga istiqamah! " + cls.buildKhatamCountdownText();
    }

    // ================= ADMINISTRASI SURAT, CUTI & MAP BERKAS =================
    public String issueNumberedLetter(String prefix, String jenis, String alasan, String santriName) {
        String year = new SimpleDateFormat("yyyy", Locale.US).format(new Date());
        int seq = (int) ((System.currentTimeMillis() / 1000L) % 900) + 100;
        String nomor = prefix + "-MHN-" + year + "-" + seq;
        String dateStr = new SimpleDateFormat("dd MMM yyyy", new Locale("id", "ID")).format(new Date());
        String record = nomor + " | " + jenis + " (" + dateStr + ") — " + santriName + " | Ket: " + alasan;
        try {
            JSONArray arr = new JSONArray(prefs.getString(AppConfig.KEY_SURAT_ARSIP_JSON, "[]"));
            arr.put(record);
            prefs.edit().putString(AppConfig.KEY_SURAT_ARSIP_JSON, arr.toString()).apply();
        } catch (Exception ignored) {}
        appendHistory("Menerbitkan " + jenis + " resmi: " + nomor);
        return nomor;
    }

    public String getMapBerkasSummary(LivingMadrasahEngine eng) {
        String sk = prefs.getString(AppConfig.KEY_SK_NUMBER, "SK-PSB/MHN/2026/" + eng.getSantriNis());
        String honor = prefs.getString(AppConfig.KEY_HONOR_TITLE, "Santri Istiqamah");
        int shield = prefs.getInt(AppConfig.KEY_PELINDUNG_SP_COUNT, 0);
        StringBuilder sb = new StringBuilder();
        sb.append("MAP BERKAS RESMI SANTRI\n");
        sb.append("• Nomor SK PSB: ").append(sk).append("\n");
        sb.append("• NIS Resmi: ").append(eng.getSantriNis()).append("\n");
        sb.append("• Gelar Kehormatan: ").append(honor).append("\n");
        sb.append("• Kartu Pelindung SP: ").append(shield).append(" buah\n");
        sb.append("• Embun Hafalan (untuk Pohon & Kebun): ").append(getEmbunHafalan()).append(" tetes\n\n");
        sb.append("Arsip Surat Izin / Sakit / Cuti:\n");
        try {
            JSONArray arr = new JSONArray(prefs.getString(AppConfig.KEY_SURAT_ARSIP_JSON, "[]"));
            if (arr.length() == 0) sb.append("• Belum ada surat izin tercatat.\n");
            for (int i = arr.length() - 1; i >= Math.max(0, arr.length() - 10); i--) {
                sb.append("• ").append(arr.getString(i)).append("\n");
            }
        } catch (Exception ignored) {}
        return sb.toString();
    }

    public String activateCutiDays(int days, String alasan, String santriName) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, Math.max(1, days));
        String until = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
        prefs.edit().putString(AppConfig.KEY_CUTI_UNTIL_DAY, until).apply();
        return issueNumberedLetter("CTI", "Surat Cuti " + days + " Hari", alasan + " (s.d. " + until + ")", santriName);
    }

    // ================= KOPERASI BERKAH 0 RUPIAH (TERHUBUNG KE XP & SP) =================
    public int getPelindungSpCount() {
        return prefs.getInt(AppConfig.KEY_PELINDUNG_SP_COUNT, 0);
    }

    public boolean buyPelindungSp(LivingMadrasahEngine eng) {
        if (eng.getXpPoints() < 80) return false;
        eng.addXp(-80);
        int cur = getPelindungSpCount();
        prefs.edit().putInt(AppConfig.KEY_PELINDUNG_SP_COUNT, cur + 1).apply();
        appendHistory("Menukar 80 Poin Berkah untuk 1 Kartu Pelindung SP di Koperasi Mbak Aisyah.");
        return true;
    }

    public boolean buyHonorTitle(LivingMadrasahEngine eng, String title, int cost) {
        if (eng.getXpPoints() < cost) return false;
        eng.addXp(-cost);
        prefs.edit().putString(AppConfig.KEY_HONOR_TITLE, title).apply();
        appendHistory("Meraih Gelar Kehormatan: " + title);
        return true;
    }

    public boolean usePelindungSpIfAvailable() {
        int cur = getPelindungSpCount();
        if (cur > 0) {
            prefs.edit().putInt(AppConfig.KEY_PELINDUNG_SP_COUNT, cur - 1).apply();
            appendHistory("Kartu Pelindung SP dipakai untuk melindungi status disiplin.");
            return true;
        }
        return false;
    }

    // ================= EMBUN HAFALAN & KEBUN/TAMBAK NYATA (BUKAN KLIK 2 DETIK) =================
    public void addEmbunHafalan(int amount) {
        int cur = Math.max(0, prefs.getInt(KEY_EMBUN_HAFALAN, 0) + amount);
        prefs.edit().putInt(KEY_EMBUN_HAFALAN, cur).apply();
    }

    public int getEmbunHafalan() {
        return prefs.getInt(KEY_EMBUN_HAFALAN, 0);
    }

    public long getGardenWaitMinutes() {
        long readyAt = prefs.getLong(KEY_GARDEN_READY_EPOCH, 0L);
        long rem = readyAt - System.currentTimeMillis();
        return rem <= 0L ? 0L : (rem + 59999L) / 60000L;
    }

    public long getPondWaitMinutes() {
        long readyAt = prefs.getLong(KEY_POND_READY_EPOCH, 0L);
        long rem = readyAt - System.currentTimeMillis();
        return rem <= 0L ? 0L : (rem + 59999L) / 60000L;
    }

    public String advanceGardenAction() {
        int st = prefs.getInt(AppConfig.KEY_GARDEN_STAGE, 0);
        long waitMin = getGardenWaitMinutes();
        if (st > 0 && waitMin > 0) {
            int embun = getEmbunHafalan();
            if (embun > 0) {
                prefs.edit()
                        .putInt(KEY_EMBUN_HAFALAN, embun - 1)
                        .putLong(KEY_GARDEN_READY_EPOCH, 0L)
                        .apply();
                return "Kamu menyiram kebun dengan 1 Embun Hafalan (hasil belajar ayatmu)! Tanaman langsung siap ke tahap berikutnya (sisa Embun: " + (embun - 1) + "). Ketuk sekali lagi untuk lanjut.";
            }
            return "Tanaman kebun sedang bertumbuh nyata (" + waitMin
                    + " menit lagi siap). Tunggu sebentar atau selesaikan 1 ayat hafalan di kelas untuk mendapat Embun Hafalan!";
        }
        if (st == 0) {
            prefs.edit()
                    .putInt(AppConfig.KEY_GARDEN_STAGE, 1)
                    .putLong(KEY_GARDEN_READY_EPOCH, System.currentTimeMillis() + GROWTH_STEP_MS)
                    .apply();
            return "Tahap 1 Kebun Organik: Bibit sayur & buah ditanam. Butuh 10 menit tumbuh alami (atau 1 Embun Hafalan dari belajar nyata) sebelum disiram.";
        } else if (st == 1) {
            prefs.edit()
                    .putInt(AppConfig.KEY_GARDEN_STAGE, 2)
                    .putLong(KEY_GARDEN_READY_EPOCH, System.currentTimeMillis() + GROWTH_STEP_MS)
                    .apply();
            return "Tahap 2 Kebun Organik: Tanaman disiram dan mulai berbuah. Butuh 10 menit lagi (atau 1 Embun Hafalan) hingga siap panen.";
        } else {
            prefs.edit()
                    .putInt(AppConfig.KEY_GARDEN_STAGE, 0)
                    .putLong(KEY_GARDEN_READY_EPOCH, 0L)
                    .apply();
            addPantryItem("Sayur & Buah Organik Hasil Panen Kebun");
            setKasWakaf(getKasWakaf() + 150000L);
            appendHistory("Panen Kebun Organik: +1 paket bahan dapur & +Rp 150.000 Kas Koperasi.");
            return "Panen Nyata Kebun Organik! Hasil panen masuk langsung ke Stok Dapur Umum (+1 paket bahan masak) dan Kas Koperasi Pondok bertambah Rp 150.000.";
        }
    }

    public String advancePondAction() {
        int st = prefs.getInt(AppConfig.KEY_POND_STAGE, 0);
        long waitMin = getPondWaitMinutes();
        if (st > 0 && waitMin > 0) {
            int embun = getEmbunHafalan();
            if (embun > 0) {
                prefs.edit()
                        .putInt(KEY_EMBUN_HAFALAN, embun - 1)
                        .putLong(KEY_POND_READY_EPOCH, 0L)
                        .apply();
                return "1 Embun Hafalan dipakai merawat kolam! Ikan langsung siap ke tahap berikutnya (sisa Embun: " + (embun - 1) + "). Ketuk sekali lagi untuk lanjut.";
            }
            return "Ikan di tambak sedang tumbuh (" + waitMin
                    + " menit lagi siap). Tunggu sebentar atau kuasai 1 ayat di kelas untuk mendapat Embun Hafalan.";
        }
        if (st == 0) {
            prefs.edit()
                    .putInt(AppConfig.KEY_POND_STAGE, 1)
                    .putLong(KEY_POND_READY_EPOCH, System.currentTimeMillis() + GROWTH_STEP_MS)
                    .apply();
            return "Tahap 1 Tambak Ikan: Benih nila & gurame ditebar. Butuh 10 menit (atau 1 Embun Hafalan) sebelum jadwal pakan.";
        } else if (st == 1) {
            prefs.edit()
                    .putInt(AppConfig.KEY_POND_STAGE, 2)
                    .putLong(KEY_POND_READY_EPOCH, System.currentTimeMillis() + GROWTH_STEP_MS)
                    .apply();
            return "Tahap 2 Tambak Ikan: Pakan sudah diberikan, ikan tumbuh sehat. Butuh 10 menit lagi hingga siap panen.";
        } else {
            prefs.edit()
                    .putInt(AppConfig.KEY_POND_STAGE, 0)
                    .putLong(KEY_POND_READY_EPOCH, 0L)
                    .apply();
            addPantryItem("Ikan Nila & Gurame Segar Hasil Tambak");
            setKasWakaf(getKasWakaf() + 200000L);
            appendHistory("Panen Tambak Ikan: +1 paket lauk dapur & +Rp 200.000 Kas Koperasi.");
            return "Panen Nyata Tambak Ikan! Lauk ikan segar masuk ke Stok Dapur Umum (+1 paket) dan Kas Koperasi Pondok bertambah Rp 200.000.";
        }
    }

    // ================= KAS KOPERASI REALISTIS, DAPUR, STAMINA & UKS =================
    public long getKasWakaf() {
        long raw = prefs.getLong(AppConfig.KEY_KAS_WAKAF, 1_000_000L);
        return Math.max(0L, raw);
    }

    public void setKasWakaf(long amount) {
        prefs.edit().putLong(AppConfig.KEY_KAS_WAKAF, Math.max(0L, amount)).apply();
    }

    public static String formatRupiah(long amount) {
        java.text.NumberFormat nf = java.text.NumberFormat.getInstance(new Locale("id", "ID"));
        return "Rp " + nf.format(amount);
    }

    public int getBuildingLevel(String buildingId) {
        return prefs.getInt(AppConfig.KEY_BUILDINGS_LEVELS + "_" + buildingId, 1);
    }

    public int getTotalCampusUpgradeLevel() {
        int sum = 0;
        for (String[] b : AppConfig.BUILDING_UPGRADES) sum += getBuildingLevel(b[0]);
        return sum;
    }

    public String upgradeBuilding(String buildingId, String label, long baseCost) {
        int lvl = getBuildingLevel(buildingId);
        // Skala biaya realistis agar sesuai hasil kebun/tambak/belajar
        long realisticCost = Math.min(baseCost, 250_000L) * lvl;
        long kas = getKasWakaf();
        if (kas < realisticCost) {
            return "Kas Koperasi belum cukup untuk perawatan/peningkatan " + label
                    + " (butuh " + formatRupiah(realisticCost) + ", saldo " + formatRupiah(kas)
                    + "). Panen kebun/tambak atau tuntaskan target hafalan dulu ya.";
        }
        setKasWakaf(kas - realisticCost);
        prefs.edit().putInt(AppConfig.KEY_BUILDINGS_LEVELS + "_" + buildingId, lvl + 1).apply();
        appendHistory("Merawat & meningkatkan " + label + " ke Level " + (lvl + 1));
        return "Alhamdulillah! " + label + " kini naik ke Level " + (lvl + 1) + ". Saldo Kas Koperasi: " + formatRupiah(getKasWakaf()) + ".";
    }

    public String giveInfaqBeasiswa(long amount) {
        long kas = getKasWakaf();
        if (kas < amount) return "Saldo Kas Koperasi belum mencukupi untuk infaq " + formatRupiah(amount) + ".";
        setKasWakaf(kas - amount);
        long total = prefs.getLong(AppConfig.KEY_TOTAL_INFAQ, 0L) + amount;
        prefs.edit().putLong(AppConfig.KEY_TOTAL_INFAQ, total).apply();
        appendHistory("Menyalurkan Infaq & Beasiswa Santri " + formatRupiah(amount));
        return "MasyaAllah! Infaq & Beasiswa sebesar " + formatRupiah(amount)
                + " disalurkan. Total infaq tercatat: " + formatRupiah(total) + ".";
    }

    public int getStamina() { return prefs.getInt(AppConfig.KEY_STAMINA, 90); }

    public void changeStamina(int delta) {
        int next = Math.max(10, Math.min(100, getStamina() + delta));
        prefs.edit().putInt(AppConfig.KEY_STAMINA, next).apply();
    }

    public boolean isStaminaLow() { return getStamina() <= 30; }

    public void addPantryItem(String itemName) {
        String old = prefs.getString(AppConfig.KEY_PANTRY_ITEMS, "");
        String next = old.isEmpty() ? itemName : old + ";;" + itemName;
        prefs.edit().putString(AppConfig.KEY_PANTRY_ITEMS, next).apply();
    }

    public String buyMarketIngredient(String itemName, long price) {
        long realisticPrice = Math.min(price, 50_000L);
        long kas = getKasWakaf();
        if (kas < realisticPrice) return "Kas Koperasi belum cukup untuk membeli " + itemName + ".";
        setKasWakaf(kas - realisticPrice);
        addPantryItem(itemName);
        appendHistory("Belanja Pasar Pondok: " + itemName);
        return "Berhasil membeli " + itemName + " (" + formatRupiah(realisticPrice) + "). Bahan masuk ke Stok Dapur Umum!";
    }

    public void ensureInitialPantryStock() {
        if (!prefs.getBoolean(AppConfig.KEY_PANTRY_INIT_V52, false)) {
            prefs.edit()
                    .putBoolean(AppConfig.KEY_PANTRY_INIT_V52, true)
                    .putString(AppConfig.KEY_PANTRY_ITEMS, "Paket Beras & Bumbu Awal Pondok;;Paket Sayur Segar Awal Pondok")
                    .apply();
        }
    }

    public int getPantryCount() {
        ensureInitialPantryStock();
        String raw = prefs.getString(AppConfig.KEY_PANTRY_ITEMS, "").trim();
        if (raw.isEmpty()) return 0;
        return raw.split(";;").length;
    }

    public String getPantrySummary() {
        ensureInitialPantryStock();
        String raw = prefs.getString(AppConfig.KEY_PANTRY_ITEMS, "").trim();
        if (raw.isEmpty()) return "Stok Dapur: Habis (panen Kebun/Tambak atau belanja di Pasar Pondok dulu).";
        String[] arr = raw.split(";;");
        return "Stok Dapur (" + arr.length + " paket): " + arr[arr.length - 1] + (arr.length > 1 ? " dan lainnya." : ".");
    }

    public boolean consumeOnePantryStock() {
        ensureInitialPantryStock();
        String raw = prefs.getString(AppConfig.KEY_PANTRY_ITEMS, "").trim();
        if (raw.isEmpty()) return false;
        String[] arr = raw.split(";;");
        if (arr.length <= 1) {
            prefs.edit().putString(AppConfig.KEY_PANTRY_ITEMS, "").apply();
            return true;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i < arr.length; i++) {
            if (sb.length() > 0) sb.append(";;");
            sb.append(arr[i]);
        }
        prefs.edit().putString(AppConfig.KEY_PANTRY_ITEMS, sb.toString()).apply();
        return true;
    }

    public String generateKitchenRecipe(int seed) {
        int s = Math.abs(seed);
        String main = AppConfig.KITCHEN_MAINS[s % AppConfig.KITCHEN_MAINS.length];
        String style = AppConfig.KITCHEN_STYLES[(s / 7) % AppConfig.KITCHEN_STYLES.length];
        String side = AppConfig.KITCHEN_SIDES[(s / 13) % AppConfig.KITCHEN_SIDES.length];
        String drink = AppConfig.KITCHEN_DRINKS[(s / 19) % AppConfig.KITCHEN_DRINKS.length];
        return main + " " + style + " + " + side + " + " + drink;
    }

    public String cookAndEatMeal(String recipeTitle) {
        changeStamina(25);
        int cnt = prefs.getInt(AppConfig.KEY_COOKED_COUNT, 0) + 1;
        prefs.edit().putInt(AppConfig.KEY_COOKED_COUNT, cnt).apply();
        appendHistory("Memasak & makan di Dapur Umum: " + recipeTitle);
        return "Bismillah, masakan matang dan dinikmati bersama santri (" + recipeTitle
                + "). Stamina belajar pulih menjadi " + getStamina() + "%.";
    }

    public String takeUksHerbal(String herbName) {
        changeStamina(30);
        appendHistory("Klinik UKS: Minum Herbal Sunnah " + herbName);
        return "Alhamdulillah, setelah minum " + herbName + " dan istirahat di Klinik UKS, stamina pulih menjadi " + getStamina() + "%.";
    }

    public String getCurrentLocationId() { return prefs.getString(AppConfig.KEY_CURRENT_LOCATION, "gerbang"); }
    public void setCurrentLocationId(String locId) { prefs.edit().putString(AppConfig.KEY_CURRENT_LOCATION, locId).apply(); }

    public void appendHistory(String event) {
        try {
            JSONArray arr = new JSONArray(prefs.getString(AppConfig.KEY_HISTORY_TIMELINE_JSON, "[]"));
            String d = new SimpleDateFormat("dd MMM yyyy", new Locale("id", "ID")).format(new Date());
            arr.put(d + " — " + event);
            prefs.edit().putString(AppConfig.KEY_HISTORY_TIMELINE_JSON, arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public String buildKapsulWaktuText(String nama) {
        StringBuilder sb = new StringBuilder("KAPSUL WAKTU & JEJAK PERJALANAN " + nama.toUpperCase(Locale.ROOT) + "\n\n");
        try {
            JSONArray arr = new JSONArray(prefs.getString(AppConfig.KEY_HISTORY_TIMELINE_JSON, "[]"));
            if (arr.length() == 0) sb.append("• Perjalanan baru saja dimulai hari ini.\n");
            for (int i = arr.length() - 1; i >= Math.max(0, arr.length() - 15); i--) {
                sb.append("• ").append(arr.getString(i)).append("\n");
            }
        } catch (Exception ignored) {}
        return sb.toString();
    }

    public String generatePermitTemplate(int seed, String santriName, String jenisStatus, String untukHari) {
        int s = Math.abs(seed);
        String open = AppConfig.PERMIT_OPENINGS[s % AppConfig.PERMIT_OPENINGS.length];
        String reason = AppConfig.PERMIT_REASONS[(s / 5) % AppConfig.PERMIT_REASONS.length];
        String commit = AppConfig.PERMIT_COMMITMENTS[(s / 11) % AppConfig.PERMIT_COMMITMENTS.length];
        String close = AppConfig.PERMIT_CLOSINGS[(s / 17) % AppConfig.PERMIT_CLOSINGS.length];
        return open + "\n\nSaya " + santriName + " mengajukan " + jenisStatus + " untuk jadwal " + untukHari
                + " dikarenakan " + reason + ".\n\n" + commit + "\n\n" + close;
    }

    // Delegasi bersih ke OfficialDocumentGenerator
    public static String buildOfficialText(String docTitle, String docNumber, List<String> bodyLines) {
        return OfficialDocumentGenerator.buildOfficialText(docTitle, docNumber, bodyLines);
    }

    public static File generateOfficialPngPhoto(Context context, String filePrefix, String docTitle,
                                                String docNumber, List<String> bodyLines) {
        return OfficialDocumentGenerator.generateOfficialPngPhoto(context, filePrefix, docTitle, docNumber, bodyLines);
    }

    // Papan Denah Kampus Visual + Ramah TalkBack/Jieshuo
    public static class CampusMapView extends android.view.View {
        private String skyPhase = "PAGI";
        private String activeLocation = "gerbang";
        private int masteredAyahs = 0;
        private int totalBuildingLevel = 8;
        private boolean schoolNightLocked = false;
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        public CampusMapView(Context context) {
            super(context);
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
            setFocusable(true);
        }

        public void updateCampusState(String phase, String locId, int mastered, int bldgLvl, boolean nightLocked) {
            this.skyPhase = phase == null ? "PAGI" : phase;
            this.activeLocation = locId == null ? "gerbang" : locId;
            this.masteredAyahs = mastered;
            this.totalBuildingLevel = bldgLvl;
            this.schoolNightLocked = nightLocked;
            setContentDescription("Denah Pondok Santri Digital. Waktu: " + skyPhase
                    + ". Posisi sekarang: " + locId
                    + ". Utara: Masjid, Kelas Utama, Ma'had Aly. Timur: Kantor TU, Koperasi Berkah, Perpustakaan. "
                    + "Barat: Asrama 24 Jam, Dapur Umum, UKS, Kebun & Tambak. Selatan: Gerbang, Rumah Santri 24 Jam, Pasar. "
                    + (nightLocked ? "Gedung Kelas sedang tutup malam, belajar 24 jam di Asrama atau Rumah Santri." : "Seluruh gedung aktif."));
            invalidate();
        }

        @Override
        protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            int skyColor = android.graphics.Color.parseColor("#1E4E79");
            if ("SUBUH".equals(skyPhase)) skyColor = android.graphics.Color.parseColor("#2A2F5B");
            else if ("PAGI".equals(skyPhase)) skyColor = android.graphics.Color.parseColor("#2B7CB3");
            else if ("SIANG".equals(skyPhase)) skyColor = android.graphics.Color.parseColor("#1C8ADB");
            else if ("SORE".equals(skyPhase)) skyColor = android.graphics.Color.parseColor("#C26A2D");
            else if ("MALAM".equals(skyPhase)) skyColor = android.graphics.Color.parseColor("#0D1B2A");
            canvas.drawColor(skyColor);

            paint.setColor("MALAM".equals(skyPhase) || "SUBUH".equals(skyPhase)
                    ? android.graphics.Color.parseColor("#F5E6A8")
                    : android.graphics.Color.parseColor("#FFD166"));
            canvas.drawCircle(w * 0.86f, h * 0.16f, Math.min(w, h) * 0.06f, paint);

            paint.setColor("MALAM".equals(skyPhase)
                    ? android.graphics.Color.parseColor("#143628")
                    : android.graphics.Color.parseColor("#1F6B48"));
            canvas.drawRect(0, h * 0.28f, w, h, paint);

            paint.setColor(android.graphics.Color.parseColor("#D9CBB3"));
            canvas.drawRect(w * 0.45f, h * 0.30f, w * 0.55f, h * 0.94f, paint);
            canvas.drawRect(w * 0.08f, h * 0.56f, w * 0.92f, h * 0.65f, paint);

            drawZone(canvas, w * 0.32f, h * 0.31f, w * 0.68f, h * 0.50f,
                    schoolNightLocked ? "#3A4754" : "#F4D35E",
                    "UTARA: MASJID, KELAS & MA'HAD",
                    "masjid".equals(activeLocation) || "kelas".equals(activeLocation) || "kampus".equals(activeLocation));
            drawZone(canvas, w * 0.60f, h * 0.52f, w * 0.95f, h * 0.72f,
                    "#4EA8DE", "TIMUR: TU, KOPERASI, PERPUS",
                    "tu".equals(activeLocation) || "ekonomi".equals(activeLocation) || "perpus".equals(activeLocation));
            drawZone(canvas, w * 0.05f, h * 0.52f, w * 0.40f, h * 0.72f,
                    "#52B788", "BARAT: ASRAMA, DAPUR, KEBUN",
                    "asrama".equals(activeLocation) || "dapur".equals(activeLocation) || "kebun".equals(activeLocation));
            drawZone(canvas, w * 0.20f, h * 0.76f, w * 0.80f, h * 0.94f,
                    "#E76F51", "SELATAN: GERBANG, RUMAH & PASAR",
                    "gerbang".equals(activeLocation) || "rumah".equals(activeLocation) || "pasar".equals(activeLocation));

            paint.setColor(android.graphics.Color.WHITE);
            paint.setTextSize(Math.max(24f, w * 0.033f));
            paint.setFakeBoldText(true);
            canvas.drawText("DENAH PONDOK (" + skyPhase + ") — U / T / B / S", w * 0.04f, h * 0.14f, paint);
            paint.setTextSize(Math.max(19f, w * 0.025f));
            paint.setFakeBoldText(false);
            canvas.drawText("Posisi: " + activeLocation.toUpperCase(Locale.US)
                    + " | Ayat Hijau: " + masteredAyahs + " | Lv Kampus: " + totalBuildingLevel,
                    w * 0.04f, h * 0.23f, paint);
        }

        private void drawZone(android.graphics.Canvas c, float l, float t, float r, float b,
                              String hexColor, String label, boolean highlighted) {
            paint.setColor(android.graphics.Color.parseColor(hexColor));
            c.drawRoundRect(new android.graphics.RectF(l, t, r, b), 14f, 14f, paint);
            if (highlighted) {
                paint.setStyle(android.graphics.Paint.Style.STROKE);
                paint.setStrokeWidth(6f);
                paint.setColor(android.graphics.Color.WHITE);
                c.drawRoundRect(new android.graphics.RectF(l, t, r, b), 14f, 14f, paint);
                paint.setStyle(android.graphics.Paint.Style.FILL);
            }
            paint.setColor(android.graphics.Color.parseColor("#0B132B"));
            paint.setTextSize(Math.max(17f, (r - l) * 0.065f));
            paint.setFakeBoldText(true);
            c.drawText(label, l + 10f, (t + b) / 2f + 6f, paint);
        }
    }
}
