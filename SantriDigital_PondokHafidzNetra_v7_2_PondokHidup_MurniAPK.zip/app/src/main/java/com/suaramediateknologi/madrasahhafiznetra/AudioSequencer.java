package com.suaramediateknologi.madrasahhafiznetra;

import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class AudioSequencer {
    public interface StatusListener {
        void onStatusChanged(String statusText);
        void onSequenceFinished();
    }

    public static class Step {
        public static final int TYPE_NARRATOR = 1;
        public static final int TYPE_AUDIO_URL = 2;
        public static final int TYPE_PAUSE_IMITATE = 3;

        public int type;
        public String mp3OrUrl;
        public String cacheKey;
        public String textOrLabel;
        public String cueMp3;
        public String cueText;
        public int pauseMs;
        public float overrideSpeed = -1f;
        public float partialPlayRatio = 1.0f;

        public static Step narrator(String mp3FileName, String fallbackText) {
            Step s = new Step();
            s.type = TYPE_NARRATOR;
            s.mp3OrUrl = mp3FileName;
            s.textOrLabel = fallbackText;
            return s;
        }

        public static Step audioUrl(String url, String cacheKey, String label) {
            Step s = new Step();
            s.type = TYPE_AUDIO_URL;
            s.mp3OrUrl = url;
            s.cacheKey = cacheKey;
            s.textOrLabel = label;
            return s;
        }

        public static Step audioUrlPartial(String url, String cacheKey, String label, float ratio) {
            Step s = audioUrl(url, cacheKey, label);
            s.partialPlayRatio = ratio;
            return s;
        }

        public static Step audioUrlWithSpeed(String url, String cacheKey, String label, float speedOverride) {
            Step s = audioUrl(url, cacheKey, label);
            s.overrideSpeed = speedOverride;
            return s;
        }

        public static Step imitatePause(int ms, String label) {
            return imitatePause(ms, label, "giliran_baca.mp3", "Sekarang giliran santri menirukan bacaan.");
        }

        public static Step imitatePause(int ms, String label, String cueMp3, String cueText) {
            Step s = new Step();
            s.type = TYPE_PAUSE_IMITATE;
            s.pauseMs = ms;
            s.textOrLabel = label;
            s.cueMp3 = cueMp3;
            s.cueText = cueText;
            return s;
        }
    }

    private final QuranRepository repo;
    private final NarratorManager narrator;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final List<Step> queue = new ArrayList<>();
    private int currentIndex = 0;
    private boolean active = false;
    private boolean paused = false;
    private float speed = 1.0f;
    private float volume = 1.0f;
    private MediaPlayer qariPlayer;
    private StatusListener listener;
    private Runnable pauseRunnable;
    private Runnable autoStopRunnable;

    public AudioSequencer(QuranRepository repo, NarratorManager narrator) {
        this.repo = repo;
        this.narrator = narrator;
    }

    public void setStatusListener(StatusListener listener) {
        this.listener = listener;
    }

    public void setPlaybackSpeed(float speed) {
        this.speed = Math.max(0.70f, Math.min(1.50f, speed));
    }

    public void setVolume(float vol) {
        this.volume = Math.max(0.1f, Math.min(1.0f, vol));
        if (qariPlayer != null) {
            try { qariPlayer.setVolume(this.volume, this.volume); } catch (Exception ignored) {}
        }
    }

    public void setAutoStopMinutes(int minutes) {
        cancelAutoStop();
        if (minutes > 0) {
            autoStopRunnable = () -> {
                if (active) {
                    stop();
                    notifyStatus("Timer tidur " + minutes + " menit selesai. Audio dihentikan otomatis.");
                    narrator.speakHybrid("salam_penutup.mp3", "Timer selesai. Alhamdulillah, sesi dengar santai berhenti otomatis.", null);
                }
            };
            mainHandler.postDelayed(autoStopRunnable, minutes * 60_000L);
        }
    }

    private void cancelAutoStop() {
        if (autoStopRunnable != null) {
            mainHandler.removeCallbacks(autoStopRunnable);
            autoStopRunnable = null;
        }
    }

    public boolean isActive() {
        return active;
    }

    public void startQueue(List<Step> steps) {
        stop();
        if (steps == null || steps.isEmpty()) {
            notifyStatus("Antrean audio kosong. Pastikan surat sudah termuat.");
            return;
        }
        queue.clear();
        queue.addAll(steps);
        currentIndex = 0;
        active = true;
        paused = false;
        playNext();
    }

    // 1. Talaqqi Per Ayat + Jeda Tirukan + Arti
    public List<Step> buildTalaqqiPerAyahSteps(QuranRepository.AyahItem ayah, int qariIndex, int repeatCount, int pauseSeconds, boolean withArti) {
        List<Step> steps = new ArrayList<>();
        String url = AppConfig.buildEveryAyahUrl(qariIndex, ayah.surahNo, ayah.nomorAyat);
        String key = "q" + qariIndex + "_" + ayah.surahNo + "_" + ayah.nomorAyat + ".mp3";
        int pauseMs = Math.max(2000, pauseSeconds * 1000);
        steps.add(Step.narrator(this.speed <= 0.80f ? "metode_lambat.mp3" : "metode_talaqqi.mp3", "Talaqqi Surat " + ayah.surahName + " ayat " + ayah.nomorAyat + ", diulang " + repeatCount + " kali. Simak bacaan Qori."));
        for (int i = 1; i <= repeatCount; i++) {
            steps.add(Step.audioUrl(url, key, "Putaran " + i + " dari " + repeatCount + " — " + ayah.surahName + " ayat " + ayah.nomorAyat));
            steps.add(Step.imitatePause(pauseMs, "Giliran santri menirukan ayat " + ayah.nomorAyat,
                    "giliran_baca.mp3", "Sekarang giliran santri menirukan bacaan."));
        }
        if (withArti && ayah.teksIndonesia != null && !ayah.teksIndonesia.isEmpty()) {
            steps.add(Step.narrator("metode_tadabbur.mp3", "Artinya: " + ayah.teksIndonesia));
            steps.add(Step.narrator("", ayah.teksIndonesia));
        }
        steps.add(Step.narrator("salam_penutup.mp3", "Alhamdulillah, Talaqqi ayat " + ayah.nomorAyat + " selesai."));
        return steps;
    }

    // 2. Tikrar Berantai Otomatis (Auto-clamp safe + Ardi Cues)
    public List<Step> buildTikrarBerantaiSteps(List<QuranRepository.AyahItem> ayahs, int startIdx, int count, int qariIndex, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        if (ayahs == null || ayahs.isEmpty()) return steps;
        int safeStart = Math.max(0, Math.min(startIdx, ayahs.size() - 1));
        int safeCount = Math.max(1, count);
        int endIdx = Math.min(ayahs.size(), safeStart + safeCount);
        int pauseMs = Math.max(2000, pauseSeconds * 1000);

        steps.add(Step.narrator("metode_tikrar_berantai.mp3",
                "Memulai Tikrar Berantai Otomatis untuk ayat " + ayahs.get(safeStart).nomorAyat + " sampai " + ayahs.get(endIdx - 1).nomorAyat + "."));
        for (int i = safeStart; i < endIdx; i++) {
            QuranRepository.AyahItem cur = ayahs.get(i);
            String url = AppConfig.buildEveryAyahUrl(qariIndex, cur.surahNo, cur.nomorAyat);
            String key = "q" + qariIndex + "_" + cur.surahNo + "_" + cur.nomorAyat + ".mp3";
            for (int r = 1; r <= 3; r++) {
                steps.add(Step.audioUrl(url, key, "Tikrar Ayat " + cur.nomorAyat + " (" + r + "/3)"));
                steps.add(Step.imitatePause(pauseMs, "Tirukan ayat " + cur.nomorAyat,
                        "giliran_baca.mp3", "Sekarang giliran santri menirukan bacaan."));
            }
            if (i > safeStart) {
                steps.add(Step.narrator("metode_sabak_sabqi.mp3",
                        "Bagus! Sekarang kita gabungkan ayat " + ayahs.get(safeStart).nomorAyat + " sampai ayat " + cur.nomorAyat + "."));
                for (int g = safeStart; g <= i; g++) {
                    QuranRepository.AyahItem ga = ayahs.get(g);
                    String gUrl = AppConfig.buildEveryAyahUrl(qariIndex, ga.surahNo, ga.nomorAyat);
                    String gKey = "q" + qariIndex + "_" + ga.surahNo + "_" + ga.nomorAyat + ".mp3";
                    steps.add(Step.audioUrl(gUrl, gKey, "Gabungan ayat " + ga.nomorAyat));
                }
                steps.add(Step.imitatePause(pauseMs + 2000, "Tirukan gabungan ayat",
                        "giliran_baca.mp3", "Sekarang tirukan gabungan ayatnya secara utuh."));
            }
        }
        steps.add(Step.narrator("salam_penutup.mp3", "Alhamdulillah, sesi Tikrar Berantai selesai."));
        return steps;
    }

    // 3. Tikrar Intensif 10x / 20x Per Ayat (Metode Syaikh Al-Qasim)
    public List<Step> buildTikrarIntensifSteps(QuranRepository.AyahItem ayah, int qariIndex, int repeatTotal, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        if (ayah == null) return steps;
        String url = AppConfig.buildEveryAyahUrl(qariIndex, ayah.surahNo, ayah.nomorAyat);
        String key = "q" + qariIndex + "_" + ayah.surahNo + "_" + ayah.nomorAyat + ".mp3";
        int pauseMs = Math.max(3000, pauseSeconds * 1000);
        steps.add(Step.narrator("metode_tikrar_intensif.mp3",
                "Memulai Tikrar Intensif " + repeatTotal + " kali untuk Surat " + ayah.surahName + " ayat " + ayah.nomorAyat + "."));
        for (int i = 1; i <= repeatTotal; i++) {
            steps.add(Step.audioUrl(url, key, "Tikrar Bertahap " + i + "/" + repeatTotal + " — Ayat " + ayah.nomorAyat));
            steps.add(Step.imitatePause(pauseMs, "Tirukan putaran ke-" + i + " (" + pauseSeconds + " detik)",
                    "giliran_baca.mp3", "Tirukan bacaan putaran ke-" + i + "."));
        }
        steps.add(Step.imitatePause(pauseMs + 3000, "Uji baca mandiri tanpa suara Qari",
                "giliran_baca.mp3", "Sekarang silakan baca sendiri tanpa suara Qori."));
        steps.add(Step.narrator("salam_penutup.mp3", "Alhamdulillah, Tikrar Intensif " + repeatTotal + " kali selesai."));
        return steps;
    }

    // 4. Metode Sabak-Sabqi (Sambung Tarik Mundur dari Ayat 1)
    public List<Step> buildSabakSabqiSteps(List<QuranRepository.AyahItem> ayahs, int targetIdx, int qariIndex, int repeatNew, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        if (ayahs == null || ayahs.isEmpty()) return steps;
        int safeTarget = Math.max(0, Math.min(targetIdx, ayahs.size() - 1));
        int pauseMs = Math.max(2500, pauseSeconds * 1000);
        int reps = Math.max(3, Math.min(repeatNew, 10));
        QuranRepository.AyahItem cur = ayahs.get(safeTarget);
        String url = AppConfig.buildEveryAyahUrl(qariIndex, cur.surahNo, cur.nomorAyat);
        String key = "q" + qariIndex + "_" + cur.surahNo + "_" + cur.nomorAyat + ".mp3";

        steps.add(Step.narrator("metode_sabak_sabqi.mp3",
                "Memulai Metode Sabak dan Sabqi untuk ayat " + cur.nomorAyat + ", lalu tarik mundur dari ayat 1."));
        for (int r = 1; r <= reps; r++) {
            steps.add(Step.audioUrl(url, key, "Sabak Ayat " + cur.nomorAyat + " (" + r + "/" + reps + ")"));
            steps.add(Step.imitatePause(pauseMs, "Tirukan Sabak ayat " + cur.nomorAyat,
                    "giliran_baca.mp3", "Sekarang giliran santri menirukan bacaan."));
        }
        if (safeTarget == 0 && ayahs.size() >= 2) {
            QuranRepository.AyahItem nextA = ayahs.get(1);
            String nUrl = AppConfig.buildEveryAyahUrl(qariIndex, nextA.surahNo, nextA.nomorAyat);
            String nKey = "q" + qariIndex + "_" + nextA.surahNo + "_" + nextA.nomorAyat + ".mp3";
            steps.add(Step.narrator("metode_sabak_sabqi.mp3",
                    "Sekarang lanjut Sabak ayat 2 lalu kita sambungkan bersama ayat 1."));
            steps.add(Step.audioUrl(nUrl, nKey, "Sabak Ayat 2"));
            steps.add(Step.imitatePause(pauseMs, "Tirukan Ayat 2 (" + pauseSeconds + " detik)"));
            steps.add(Step.audioUrl(url, key, "Sambung Ayat 1"));
            steps.add(Step.audioUrl(nUrl, nKey, "Sambung Ayat 2"));
            steps.add(Step.imitatePause(pauseMs + 2000, "Tirukan sambungan Ayat 1 dan 2"));
        } else if (safeTarget > 0) {
            steps.add(Step.narrator("metode_sabak_sabqi.mp3",
                    "Bagus! Sekarang kita tarik mundur dan sambungkan dari ayat 1 sampai ayat " + cur.nomorAyat + "."));
            for (int i = 0; i <= safeTarget; i++) {
                QuranRepository.AyahItem ga = ayahs.get(i);
                String gUrl = AppConfig.buildEveryAyahUrl(qariIndex, ga.surahNo, ga.nomorAyat);
                String gKey = "q" + qariIndex + "_" + ga.surahNo + "_" + ga.nomorAyat + ".mp3";
                steps.add(Step.audioUrl(gUrl, gKey, "Tarik Mundur Ayat " + ga.nomorAyat));
            }
            steps.add(Step.imitatePause(pauseMs + 3000, "Tirukan sambungan ayat 1 s.d. " + cur.nomorAyat,
                    "giliran_baca.mp3", "Sekarang tirukan gabungan ayatnya secara utuh."));
        }
        steps.add(Step.narrator("salam_penutup.mp3", "Alhamdulillah, sesi Sabak Sabqi selesai."));
        return steps;
    }

    // 5. Mode Dengar Santai / Pengulangan Otomatis (Loop Blok Fokus)
    public List<Step> buildDengarSantaiLoopSteps(List<QuranRepository.AyahItem> ayahs, int startIdx, int count, int qariIndex, int loops) {
        List<Step> steps = new ArrayList<>();
        if (ayahs == null || ayahs.isEmpty()) return steps;
        int safeStart = Math.max(0, Math.min(startIdx, ayahs.size() - 1));
        int endIdx = Math.min(ayahs.size(), safeStart + Math.max(1, count));
        int totalLoops = Math.max(3, Math.min(loops, 40));

        steps.add(Step.narrator("metode_santai.mp3",
                "Memulai Mode Dengar Santai, mengulang ayat " + ayahs.get(safeStart).nomorAyat + " sampai " + ayahs.get(endIdx - 1).nomorAyat + " sebanyak " + totalLoops + " putaran."));
        for (int lp = 1; lp <= totalLoops; lp++) {
            for (int i = safeStart; i < endIdx; i++) {
                QuranRepository.AyahItem a = ayahs.get(i);
                String u = AppConfig.buildEveryAyahUrl(qariIndex, a.surahNo, a.nomorAyat);
                String k = "q" + qariIndex + "_" + a.surahNo + "_" + a.nomorAyat + ".mp3";
                steps.add(Step.audioUrl(u, k, "Dengar Santai Putaran " + lp + "/" + totalLoops + " — Ayat " + a.nomorAyat));
            }
        }
        steps.add(Step.narrator("salam_penutup.mp3", "Alhamdulillah, sesi dengar santai selesai."));
        return steps;
    }

    // 6. Metode Baca Bareng (Shadowing 3 Tahap: 0.75x Simak -> 0.90x Baca Bareng -> Mandiri)
    public List<Step> buildShadowing3StageSteps(QuranRepository.AyahItem ayah, int qariIndex, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        if (ayah == null) return steps;
        String url = AppConfig.buildEveryAyahUrl(qariIndex, ayah.surahNo, ayah.nomorAyat);
        String key = "q" + qariIndex + "_" + ayah.surahNo + "_" + ayah.nomorAyat + ".mp3";
        int pauseMs = Math.max(3000, pauseSeconds * 1000);

        steps.add(Step.narrator("metode_shadowing.mp3",
                "Memulai Metode Baca Bareng 3 Tahap untuk Surat " + ayah.surahName + " ayat " + ayah.nomorAyat + "."));
        // Tahap 1: Pelan 0.75x
        steps.add(Step.narrator("metode_talaqqi.mp3", "Tahap 1: Simak bacaan pelan Qori dengan saksama."));
        steps.add(Step.audioUrlWithSpeed(url, key, "Tahap 1 (Simak Pelan 0.75x) — Ayat " + ayah.nomorAyat, 0.75f));
        // Tahap 2: Baca Bareng 0.90x (2 kali)
        steps.add(Step.narrator("giliran_baca.mp3", "Tahap 2: Ayo baca bersama Qori sekarang."));
        steps.add(Step.audioUrlWithSpeed(url, key, "Tahap 2 (Baca Bareng 1/2) — Ayat " + ayah.nomorAyat, 0.90f));
        steps.add(Step.narrator("giliran_baca.mp3", "Sekali lagi, baca bersama Qori."));
        steps.add(Step.audioUrlWithSpeed(url, key, "Tahap 2 (Baca Bareng 2/2) — Ayat " + ayah.nomorAyat, 0.90f));
        // Tahap 3: Baca Mandiri
        steps.add(Step.imitatePause(pauseMs + 3000, "Tahap 3: Baca mandiri tanpa suara Qari",
                "giliran_baca.mp3", "Tahap 3: Sekarang silakan baca sendiri tanpa suara Qori."));
        steps.add(Step.narrator("salam_penutup.mp3", "Alhamdulillah, 3 tahap baca bareng selesai."));
        return steps;
    }

    public List<Step> buildWordByWordSteps(QuranRepository.AyahItem ayah, List<QuranRepository.WordItem> words, int qariIndex) {
        return buildWordByWordSteps(ayah, words, qariIndex, 2, 3);
    }

    public List<Step> buildWordByWordSteps(QuranRepository.AyahItem ayah, List<QuranRepository.WordItem> words, int qariIndex, int repeatPerWord, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        int reps = Math.max(1, Math.min(repeatPerWord, 10));
        int pauseMs = Math.max(1500, pauseSeconds * 1000);
        steps.add(Step.narrator("metode_perkata.mp3",
                "Talaqqi per kata Surat " + ayah.surahName + " ayat " + ayah.nomorAyat
                        + ", ulangan " + reps + " kali per kata dengan jeda " + pauseSeconds + " detik."));
        int idx = 1;
        for (QuranRepository.WordItem w : words) {
            for (int r = 1; r <= reps; r++) {
                if (w.audioUrl != null && !w.audioUrl.isEmpty()) {
                    steps.add(Step.audioUrl(w.audioUrl, "wbw_" + ayah.surahNo + "_" + ayah.nomorAyat + "_" + idx + ".mp3",
                            "Kata ke-" + idx + " (Ulangan " + r + "/" + reps + ")"));
                    steps.add(Step.imitatePause(pauseMs, "Tirukan kata ke-" + idx + " (" + pauseSeconds + " detik)",
                            "giliran_baca.mp3", "Tirukan kata ke-" + idx + "."));
                } else {
                    steps.add(Step.narrator("", "Kata ke-" + idx + " ulangan " + r + ": " + w.transliteration));
                    steps.add(Step.imitatePause(pauseMs, "Tirukan kata ke-" + idx));
                }
            }
            idx++;
        }
        String fullUrl = AppConfig.buildEveryAyahUrl(qariIndex, ayah.surahNo, ayah.nomorAyat);
        String fullKey = "q" + qariIndex + "_" + ayah.surahNo + "_" + ayah.nomorAyat + ".mp3";
        steps.add(Step.narrator("giliran_baca.mp3", "Sekarang simak satu ayat penuh lalu tirukan."));
        steps.add(Step.audioUrl(fullUrl, fullKey, "Ayat penuh"));
        steps.add(Step.imitatePause(pauseMs + 1000, "Tirukan ayat penuh (" + (pauseSeconds + 1) + " detik)"));
        return steps;
    }

    public List<Step> buildWaqafSegmentSteps(QuranRepository.AyahItem ayah, List<QuranRepository.WaqafSegment> segments, int qariIndex, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        int pauseMs = Math.max(2000, pauseSeconds * 1000);
        steps.add(Step.narrator("metode_waqaf.mp3", "Pemecah ayat panjang Surat " + ayah.surahName + " ayat " + ayah.nomorAyat + ", dibagi menjadi " + segments.size() + " penggalan napas."));
        for (QuranRepository.WaqafSegment seg : segments) {
            steps.add(Step.narrator("", "Penggalan ke-" + seg.index));
            for (int r = 1; r <= 2; r++) {
                for (QuranRepository.WordItem w : seg.words) {
                    if (w.audioUrl != null && !w.audioUrl.isEmpty()) {
                        steps.add(Step.audioUrl(w.audioUrl, "wbw_" + ayah.surahNo + "_" + ayah.nomorAyat + "_" + w.position + ".mp3", "Penggalan " + seg.index));
                    }
                }
                steps.add(Step.imitatePause(pauseMs, "Tirukan penggalan " + seg.index,
                        "giliran_baca.mp3", "Sekarang giliran santri menirukan penggalan ini."));
            }
        }
        String fullUrl = AppConfig.buildEveryAyahUrl(qariIndex, ayah.surahNo, ayah.nomorAyat);
        String fullKey = "q" + qariIndex + "_" + ayah.surahNo + "_" + ayah.nomorAyat + ".mp3";
        steps.add(Step.narrator("giliran_baca.mp3", "Sekarang gabungkan menjadi satu ayat utuh."));
        steps.add(Step.audioUrl(fullUrl, fullKey, "Ayat utuh"));
        return steps;
    }


    // 7. Metode Audio Buka-Tutup (Utuh -> 40% Awal saja -> Mandiri + Cek)
    public List<Step> buildAudioBukaTutupSteps(QuranRepository.AyahItem ayah, int qariIndex, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        if (ayah == null) return steps;
        String url = AppConfig.buildEveryAyahUrl(qariIndex, ayah.surahNo, ayah.nomorAyat);
        String key = "q" + qariIndex + "_" + ayah.surahNo + "_" + ayah.nomorAyat + ".mp3";
        int pauseMs = Math.max(3000, pauseSeconds * 1000);
        steps.add(Step.narrator("metode_buka_tutup.mp3", "Metode Audio Buka-Tutup Surat " + ayah.surahName + " ayat " + ayah.nomorAyat + ". Putaran 1: Terbuka penuh."));
        steps.add(Step.audioUrl(url, key, "Buka-Tutup 1/3 (Terbuka Utuh)"));
        steps.add(Step.narrator("", "Putaran 2: Separuh tertutup. Qori hanya membaca awal ayat, lalu teruskan sendiri bagian akhirnya."));
        steps.add(Step.audioUrlPartial(url, key, "Buka-Tutup 2/3 (Awal Ayat Saja)", 0.42f));
        steps.add(Step.imitatePause(pauseMs + 1500, "Teruskan akhir ayat sendiri", "giliran_baca.mp3", "Teruskan bagian akhir ayatnya sekarang."));
        steps.add(Step.imitatePause(pauseMs + 2500, "Putaran 3: Tertutup penuh, baca mandiri", "giliran_baca.mp3", "Putaran 3: Sekarang baca satu ayat penuh secara mandiri tanpa suara Qori."));
        steps.add(Step.narrator("", "Mari cocokkan dengan bacaan Qori."));
        steps.add(Step.audioUrl(url, key, "Pencocokan Akhir — Ayat " + ayah.nomorAyat));
        steps.add(Step.narrator("salam_penutup.mp3", "Alhamdulillah, Audio Buka-Tutup selesai."));
        return steps;
    }

    // 8. Tikrar Rantai Mundur (Dari Ayat Terakhir ke Awal Blok)
    public List<Step> buildRantaiMundurSteps(List<QuranRepository.AyahItem> ayahs, int startIdx, int count, int qariIndex, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        if (ayahs == null || ayahs.isEmpty()) return steps;
        int safeStart = Math.max(0, Math.min(startIdx, ayahs.size() - 1));
        int endIdx = Math.min(ayahs.size(), safeStart + Math.max(1, count));
        int pauseMs = Math.max(2500, pauseSeconds * 1000);
        steps.add(Step.narrator("metode_rantai_mundur.mp3", "Memulai Tikrar Rantai Mundur dari ayat " + ayahs.get(endIdx - 1).nomorAyat + " mundur ke ayat " + ayahs.get(safeStart).nomorAyat + "."));
        for (int i = endIdx - 1; i >= safeStart; i--) {
            QuranRepository.AyahItem cur = ayahs.get(i);
            String u = AppConfig.buildEveryAyahUrl(qariIndex, cur.surahNo, cur.nomorAyat);
            String k = "q" + qariIndex + "_" + cur.surahNo + "_" + cur.nomorAyat + ".mp3";
            for (int r = 1; r <= 2; r++) {
                steps.add(Step.audioUrl(u, k, "Rantai Mundur Ayat " + cur.nomorAyat + " (" + r + "/2)"));
                steps.add(Step.imitatePause(pauseMs, "Tirukan ayat " + cur.nomorAyat));
            }
            if (i < endIdx - 1) {
                steps.add(Step.narrator("giliran_baca.mp3", "Sambungkan dari ayat " + cur.nomorAyat + " sampai ayat " + ayahs.get(endIdx - 1).nomorAyat + "."));
                for (int g = i; g < endIdx; g++) {
                    QuranRepository.AyahItem ga = ayahs.get(g);
                    steps.add(Step.audioUrl(AppConfig.buildEveryAyahUrl(qariIndex, ga.surahNo, ga.nomorAyat), "q" + qariIndex + "_" + ga.surahNo + "_" + ga.nomorAyat + ".mp3", "Gabung Ayat " + ga.nomorAyat));
                }
                steps.add(Step.imitatePause(pauseMs + 2000, "Tirukan sambungan mundur"));
            }
        }
        steps.add(Step.narrator("salam_penutup.mp3", "Alhamdulillah, Tikrar Rantai Mundur selesai."));
        return steps;
    }

    // 9. Metode Tautan Engsel (Sambungan Ujung Ayat N -> Awal Ayat N+1)
    public List<Step> buildTautanEngselSteps(List<QuranRepository.AyahItem> ayahs, int idx, int qariIndex, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        if (ayahs == null || ayahs.size() < 2) return steps;
        int safe = Math.max(0, Math.min(idx, ayahs.size() - 2));
        QuranRepository.AyahItem a1 = ayahs.get(safe);
        QuranRepository.AyahItem a2 = ayahs.get(safe + 1);
        int pauseMs = Math.max(2500, pauseSeconds * 1000);
        steps.add(Step.narrator("metode_engsel.mp3", "Metode Tautan Engsel: melatih perpindahan dari ayat " + a1.nomorAyat + " langsung ke ayat " + a2.nomorAyat + " sebanyak 3 kali."));
        String u1 = AppConfig.buildEveryAyahUrl(qariIndex, a1.surahNo, a1.nomorAyat);
        String k1 = "q" + qariIndex + "_" + a1.surahNo + "_" + a1.nomorAyat + ".mp3";
        String u2 = AppConfig.buildEveryAyahUrl(qariIndex, a2.surahNo, a2.nomorAyat);
        String k2 = "q" + qariIndex + "_" + a2.surahNo + "_" + a2.nomorAyat + ".mp3";
        for (int r = 1; r <= 3; r++) {
            steps.add(Step.audioUrl(u1, k1, "Engsel " + r + "/3 — Ayat " + a1.nomorAyat));
            steps.add(Step.audioUrl(u2, k2, "Engsel " + r + "/3 — Langsung Ayat " + a2.nomorAyat));
            steps.add(Step.imitatePause(pauseMs + 1500, "Tirukan sambungan ayat " + a1.nomorAyat + " ke " + a2.nomorAyat,
                    "giliran_baca.mp3", "Tirukan sambungan kedua ayat tanpa ragu."));
        }
        steps.add(Step.narrator("salam_penutup.mp3", "Alhamdulillah, latihan Tautan Engsel selesai."));
        return steps;
    }

    // 10. Pelatih Tempo Otomatis (0.80x -> 0.95x -> 1.05x)
    public List<Step> buildPelatihTempoSteps(QuranRepository.AyahItem ayah, int qariIndex, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        if (ayah == null) return steps;
        String url = AppConfig.buildEveryAyahUrl(qariIndex, ayah.surahNo, ayah.nomorAyat);
        String key = "q" + qariIndex + "_" + ayah.surahNo + "_" + ayah.nomorAyat + ".mp3";
        int pauseMs = Math.max(2500, pauseSeconds * 1000);
        steps.add(Step.narrator("metode_tempo.mp3", "Pelatih Tempo Otomatis ayat " + ayah.nomorAyat + ": pelan, sedang, lalu lancar."));
        steps.add(Step.narrator("", "Putaran 1: Tempo pelan 0.80x untuk makhraj."));
        steps.add(Step.audioUrlWithSpeed(url, key, "Tempo Pelan 0.80x", 0.80f));
        steps.add(Step.imitatePause(pauseMs, "Tirukan tempo pelan"));
        steps.add(Step.narrator("", "Putaran 2: Tempo sedang 0.95x."));
        steps.add(Step.audioUrlWithSpeed(url, key, "Tempo Sedang 0.95x", 0.95f));
        steps.add(Step.imitatePause(pauseMs, "Tirukan tempo sedang"));
        steps.add(Step.narrator("", "Putaran 3: Tempo lancar 1.05x."));
        steps.add(Step.audioUrlWithSpeed(url, key, "Tempo Lancar 1.05x", 1.05f));
        steps.add(Step.imitatePause(pauseMs, "Tirukan tempo lancar"));
        steps.add(Step.narrator("salam_penutup.mp3", "Alhamdulillah, Pelatih Tempo selesai."));
        return steps;
    }

    // 11. Mode Estafet Gantian (Qari Ganjil, Santri Genap + Cek Jawaban!)
    public List<Step> buildEstafetGantianSteps(List<QuranRepository.AyahItem> ayahs, int qariIndex, int pauseSeconds, boolean santriGanjil) {
        List<Step> steps = new ArrayList<>();
        if (ayahs == null || ayahs.isEmpty()) return steps;
        int pauseMs = Math.max(3500, pauseSeconds * 1000);
        int limit = Math.min(ayahs.size(), 10);
        steps.add(Step.narrator("metode_estafet.mp3", "Mode Sambung Ayat Estafet! Kita bergantian membaca sampai ayat " + limit + "."));
        for (int i = 0; i < limit; i++) {
            QuranRepository.AyahItem a = ayahs.get(i);
            String u = AppConfig.buildEveryAyahUrl(qariIndex, a.surahNo, a.nomorAyat);
            String k = "q" + qariIndex + "_" + a.surahNo + "_" + a.nomorAyat + ".mp3";
            boolean isSantriTurn = santriGanjil ? (i % 2 == 0) : (i % 2 == 1);
            if (isSantriTurn) {
                steps.add(Step.imitatePause(pauseMs + 1500, "Giliran Santri: Ayat " + a.nomorAyat,
                        "giliran_baca.mp3", "Giliran santri membaca ayat " + a.nomorAyat + "."));
                steps.add(Step.narrator("", "Cocokkan bacaan ayat " + a.nomorAyat + "."));
                steps.add(Step.audioUrl(u, k, "Cek Ayat " + a.nomorAyat));
            } else {
                steps.add(Step.audioUrl(u, k, "Giliran Qari: Ayat " + a.nomorAyat));
            }
        }
        steps.add(Step.narrator("salam_penutup.mp3", "MasyaAllah, Estafet Gantian selesai!"));
        return steps;
    }

    // 12. Paket Penyelamat Lupa Total 60 Detik (Arti -> 0.75x 2x -> Buka-Tutup)
    public List<Step> buildLupaTotalRescueSteps(QuranRepository.AyahItem ayah, int qariIndex, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        if (ayah == null) return steps;
        String u = AppConfig.buildEveryAyahUrl(qariIndex, ayah.surahNo, ayah.nomorAyat);
        String k = "q" + qariIndex + "_" + ayah.surahNo + "_" + ayah.nomorAyat + ".mp3";
        int pauseMs = Math.max(3000, pauseSeconds * 1000);
        steps.add(Step.narrator("metode_rescue.mp3", "Tenang, tidak apa-apa lupa. Mari bangkitkan ingatan Surat " + ayah.surahName + " ayat " + ayah.nomorAyat + "."));
        if (ayah.teksIndonesia != null && !ayah.teksIndonesia.isEmpty()) {
            steps.add(Step.narrator("metode_tadabbur.mp3", "Ingat dulu maknanya: " + ayah.teksIndonesia));
            steps.add(Step.narrator("", ayah.teksIndonesia));
        }
        steps.add(Step.audioUrlWithSpeed(u, k, "Penyelamat 1/2 (Pelan 0.75x)", 0.75f));
        steps.add(Step.audioUrlWithSpeed(u, k, "Penyelamat 2/2 (Pelan 0.75x)", 0.75f));
        steps.add(Step.audioUrlPartial(u, k, "Pancingan Awal Ayat", 0.40f));
        steps.add(Step.imitatePause(pauseMs + 1500, "Teruskan sendiri", "giliran_baca.mp3", "Sekarang coba teruskan sendiri ya."));
        steps.add(Step.narrator("salam_penutup.mp3", "Alhamdulillah, ingatan kembali segar!"));
        return steps;
    }

    // 13. Wirid Sore 17.00 & 6 Surat Pendek Utuh (Al-Kafirun -> An-Nas dengan pengumuman tiap surat)
    public List<Step> buildWiridSore6SuratSteps(int qariIndex) {
        List<Step> steps = new ArrayList<>();
        steps.add(Step.narrator("wirid_sore_pembuka.mp3",
                "Waktunya Wirid Sore menjelang Maghrib. Subhanallah, walhamdulillah, wala ilaha illallah, wallahu akbar. Astaghfirullahal azim. Mari kita simak 6 surat pendek secara utuh mulai Surat Al-Kafirun sampai An-Nas."));
        int[][] surahCounts = {{109, 6}, {110, 3}, {111, 5}, {112, 4}, {113, 5}, {114, 6}};
        String[] surahNames = {"Surat Al-Kafirun", "Surat An-Nasr", "Surat Al-Lahab", "Surat Al-Ikhlas", "Surat Al-Falaq", "Surat An-Nas"};
        for (int sIdx = 0; sIdx < surahCounts.length; sIdx++) {
            int sNo = surahCounts[sIdx][0];
            int totalAyah = surahCounts[sIdx][1];
            String sName = surahNames[sIdx];
            steps.add(Step.narrator("", "Surat ke-" + (sIdx + 1) + ": " + sName + "."));
            for (int a = 1; a <= totalAyah; a++) {
                steps.add(Step.audioUrl(AppConfig.buildEveryAyahUrl(qariIndex, sNo, a),
                        "wirid_q" + qariIndex + "_" + sNo + "_" + a + ".mp3",
                        "Wirid Sore — " + sName + " Ayat " + a + "/" + totalAyah));
            }
        }
        steps.add(Step.narrator("salam_penutup.mp3", "Alhamdulillah, Wirid Sore dan seluruh 6 surat pendek selesai. Semoga sore Anda penuh berkah."));
        return steps;
    }

    private void prefetchUpcomingAudio() {
        for (int i = currentIndex; i < Math.min(queue.size(), currentIndex + 3); i++) {
            Step upcoming = queue.get(i);
            if (upcoming.type == Step.TYPE_AUDIO_URL && upcoming.mp3OrUrl != null) {
                final String url = upcoming.mp3OrUrl;
                final String key = upcoming.cacheKey;
                new Thread(() -> repo.getOrDownloadAudio(url, key)).start();
                break;
            }
        }
    }

    private void playNext() {
        if (!active || paused) return;
        if (currentIndex >= queue.size()) {
            active = false;
            cancelAutoStop();
            notifyStatus("Sesi audio selesai.");
            if (listener != null) mainHandler.post(listener::onSequenceFinished);
            return;
        }
        final Step step = queue.get(currentIndex++);
        notifyStatus(step.textOrLabel != null ? step.textOrLabel : "Memutar...");
        // Prefetch dimatikan demi stabilitas unduhan atomik anti-loncat

        if (step.type == Step.TYPE_NARRATOR) {
            narrator.speakHybrid(step.mp3OrUrl, step.textOrLabel, this::playNext);
        } else if (step.type == Step.TYPE_PAUSE_IMITATE) {
            // Speak voice instruction FIRST (Ardi MP3 or fallback TTS), THEN gentle chime, THEN wait!
            String cMp3 = step.cueMp3 != null ? step.cueMp3 : "giliran_baca.mp3";
            String cTxt = (step.cueText != null && !step.cueText.isEmpty()) ? step.cueText : "Sekarang giliran santri menirukan bacaan.";
            narrator.speakHybrid(cMp3, cTxt, () -> {
                if (!active || paused) return;
                narrator.playImitationBeep();
                pauseRunnable = this::playNext;
                mainHandler.postDelayed(pauseRunnable, Math.max(1500, step.pauseMs));
            });
        } else if (step.type == Step.TYPE_AUDIO_URL) {
            new Thread(() -> {
                File f = repo.getOrDownloadAudio(step.mp3OrUrl, step.cacheKey);
                mainHandler.post(() -> {
                    if (!active || paused) return;
                    if (f != null && f.exists()) {
                        float useSpeed = step.overrideSpeed > 0f ? step.overrideSpeed : speed;
                        playQariFile(f, useSpeed, step.partialPlayRatio, this::playNext);
                    } else {
                        notifyStatus("Audio belum tersedia untuk langkah ini.");
                        playNext();
                    }
                });
            }).start();
        }
    }

    private void playQariFile(File file, float useSpeed, final float partialRatio, Runnable onDone) {
        releaseQariPlayer();
        try {
            narrator.requestAudioFocus();
            qariPlayer = new MediaPlayer();
            qariPlayer.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            qariPlayer.setDataSource(file.getAbsolutePath());
            qariPlayer.setVolume(volume, volume);
            qariPlayer.setOnPreparedListener(mp -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Math.abs(useSpeed - 1.0f) > 0.02f) {
                    try {
                        PlaybackParams pp = mp.getPlaybackParams();
                        pp.setSpeed(useSpeed);
                        mp.setPlaybackParams(pp);
                    } catch (Exception ignored) {}
                }
                mp.start();
                if (partialRatio > 0.1f && partialRatio < 0.95f) {
                    int dur = mp.getDuration();
                    if (dur > 1000) {
                        long cutMs = Math.max(900L, (long) (dur * partialRatio));
                        pauseRunnable = () -> {
                            releaseQariPlayer();
                            if (active) onDone.run();
                        };
                        mainHandler.postDelayed(pauseRunnable, cutMs);
                    }
                }
            });
            qariPlayer.setOnCompletionListener(mp -> {
                releaseQariPlayer();
                if (active) onDone.run();
            });
            qariPlayer.setOnErrorListener((mp, what, extra) -> {
                releaseQariPlayer();
                if (active) onDone.run();
                return true;
            });
            qariPlayer.prepareAsync();
        } catch (Exception e) {
            releaseQariPlayer();
            if (active) onDone.run();
        }
    }

    private void notifyStatus(String msg) {
        if (listener != null) mainHandler.post(() -> listener.onStatusChanged(msg));
    }

    public void stop() {
        active = false;
        paused = false;
        cancelAutoStop();
        if (pauseRunnable != null) {
            mainHandler.removeCallbacks(pauseRunnable);
            pauseRunnable = null;
        }
        releaseQariPlayer();
        narrator.stopSpeaking();
    }

    private void releaseQariPlayer() {
        if (qariPlayer != null) {
            try {
                if (qariPlayer.isPlaying()) qariPlayer.stop();
                qariPlayer.release();
            } catch (Exception ignored) {}
            qariPlayer = null;
        }
    }

    // ================= v4.0 TIERED METHODS (14-20) & AUTO MORNING PRAYERS =================
    public List<Step> buildBlok3AyahSteps(List<QuranRepository.AyahItem> ayahs, int startIdx, int qariIndex, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        int end = Math.min(ayahs.size(), startIdx + 3);
        steps.add(Step.narrator("metode_blok3.mp3", "Metode Blok 3 Ayat Mantap. Simak tiga ayat berturut-turut lalu tirukan bersama."));
        for (int i = startIdx; i < end; i++) {
            QuranRepository.AyahItem a = ayahs.get(i);
            String url = AppConfig.buildEveryAyahUrl(qariIndex, a.surahNo, a.nomorAyat);
            steps.add(Step.audioUrl(url, "q" + qariIndex + "_s" + a.surahNo + "_a" + a.nomorAyat + ".mp3", "Blok Ayat " + a.nomorAyat));
        }
        steps.add(Step.imitatePause(Math.max(4, pauseSeconds) * 1500, "Tirukan 3 ayat beruntun sekarang", "giliran_baca.mp3", "Sekarang giliran kamu menirukan tiga ayat tadi."));
        return steps;
    }

    public List<Step> buildTasmiFullSurahSteps(List<QuranRepository.AyahItem> ayahs, int qariIndex) {
        List<Step> steps = new ArrayList<>();
        steps.add(Step.narrator("metode_tasmi_utuh.mp3", "Metode Tasmi' Satu Surat Utuh tanpa putus. Simak dengan khusyuk dan ikuti dalam hati."));
        int limit = ayahs.size();
        for (int i = 0; i < limit; i++) {
            QuranRepository.AyahItem a = ayahs.get(i);
            String url = AppConfig.buildEveryAyahUrl(qariIndex, a.surahNo, a.nomorAyat);
            steps.add(Step.audioUrl(url, "q" + qariIndex + "_s" + a.surahNo + "_a" + a.nomorAyat + ".mp3", "Tasmi' Ayat " + a.nomorAyat));
        }
        return steps;
    }

    public List<Step> buildTadabburMaknaSteps(QuranRepository.AyahItem ayah, int qariIndex) {
        List<Step> steps = new ArrayList<>();
        String url = AppConfig.buildEveryAyahUrl(qariIndex, ayah.surahNo, ayah.nomorAyat);
        steps.add(Step.narrator("metode_tadabbur.mp3", "Metode Tadabbur Makna. Mari simak lantunan ayat lalu resapi artinya."));
        steps.add(Step.audioUrl(url, "q" + qariIndex + "_s" + ayah.surahNo + "_a" + ayah.nomorAyat + ".mp3", "Tadabbur Ayat " + ayah.nomorAyat));
        String arti = (ayah.teksIndonesia == null || ayah.teksIndonesia.trim().isEmpty())
                ? "Semoga Allah memahamkan kita makna ayat mulia ini."
                : "Artinya: " + ayah.teksIndonesia;
        steps.add(Step.narrator("", arti));
        return steps;
    }

    public List<Step> buildMorningPrayerAutoSteps(List<String> livePrayerNames, String santriName) {
        return buildMorningPrayerAutoSteps(livePrayerNames, santriName, 0);
    }

    public List<Step> buildMorningPrayerAutoSteps(List<String> livePrayerNames, String santriName, int qariIndex) {
        List<Step> steps = new ArrayList<>();
        // 1. Pembuka Suara Ustadz Ardi (MP3 GitHub Releases)
        steps.add(Step.narrator("doa_pagi_pembuka.mp3",
                "Assalamu'alaikum warahmatullahi wabarakatuh, " + santriName + ". Mari awali pagi dengan Dzikir Pagi Suara Qari Asli dan Doa Majelis Pondok."));

        // 2. Suara Qari Manusia Asli (EveryAyah): Ayat Kursi (2:255)
        steps.add(Step.audioUrl(
                AppConfig.buildEveryAyahUrl(qariIndex, 2, 255),
                "pagi_q" + qariIndex + "_kursi.mp3",
                "Dzikir Pagi Qari Asli: Ayat Kursi (Al-Baqarah 255)"));

        // 3. Suara Qari Manusia Asli (EveryAyah): Al-Ikhlas (112), Al-Falaq (113), An-Nas (114)
        int[][] qulSurahs = {{112, 4}, {113, 5}, {114, 6}};
        for (int[] s : qulSurahs) {
            for (int a = 1; a <= s[1]; a++) {
                steps.add(Step.audioUrl(
                        AppConfig.buildEveryAyahUrl(qariIndex, s[0], a),
                        "pagi_q" + qariIndex + "_s" + s[0] + "_a" + a + ".mp3",
                        "Dzikir Pagi Qari Asli: Surat " + s[0] + " Ayat " + a));
            }
        }

        // 4. Audio Arab Asli Dzikir Pagi Hisn al-Muslim (diunduh otomatis ke GitHub Releases materi-latest)
        steps.add(Step.narrator("dzikir_pagi_arab_1.mp3",
                "Allahumma bika ashbahna wa bika amsayna wa bika nahya wa bika namutu wa ilaikan nusyur."));
        steps.add(Step.narrator("dzikir_pagi_arab_2.mp3",
                "Radhitu billahi rabba, wa bil Islami dina, wa bi Muhammadin shallallahu alaihi wa sallama nabiyya."));
        steps.add(Step.narrator("dzikir_pagi_arab_3.mp3",
                "Allahumma inni as'aluka ilman nafi'an, wa rizqan thayyiban, wa amalan mutaqabbalan."));

        // 5. Doa Arwah & Daftar Nama Real-Time dari Server Firebase
        steps.add(Step.narrator("doa_pagi_arwah.mp3",
                "Ya Allah, ampunilah dosa orang tua kami, guru-guru kami, dan seluruh almarhum serta almarhumah yang tercatat di Majelis Doa Pondok."));
        if (livePrayerNames != null && !livePrayerNames.isEmpty()) {
            StringBuilder sb = new StringBuilder("Khususnya kepada: ");
            int limit = Math.min(8, livePrayerNames.size());
            for (int i = 0; i < limit; i++) {
                if (i > 0) sb.append(", ");
                sb.append(livePrayerNames.get(i));
            }
            sb.append(". Semoga Allah mengampuni, merahmati, dan mengabulkan segala hajat kebaikan.");
            steps.add(Step.narrator("", sb.toString()));
        }
        steps.add(Step.narrator("doa_pagi_penutup.mp3",
                "Ya Allah, mudahkanlah hafalan Al-Qur'an kami hari ini, jadikan ilmu kami berkah dan bermanfaat. Aamiin ya Rabbal Alamiin."));
        return steps;
    }

    // ================= v5.1 PAUSE/RESUME, TIKRAR BERTAHAP CUSTOM & QARI MUTASYABIHAT/MAQAMAT =================
    public boolean isPaused() { return paused; }

    public boolean togglePauseResume() {
        if (!active) return false;
        if (!paused) {
            paused = true;
            if (pauseRunnable != null) mainHandler.removeCallbacks(pauseRunnable);
            try {
                if (qariPlayer != null && qariPlayer.isPlaying()) qariPlayer.pause();
            } catch (Exception ignored) {}
            narrator.stopSpeaking();
            notifyStatus("Dijeda sementara. Ketuk Lanjutkan untuk meneruskan.");
            return true;
        } else {
            paused = false;
            notifyStatus("Melanjutkan putaran metode...");
            try {
                if (qariPlayer != null) {
                    qariPlayer.start();
                    return false;
                }
            } catch (Exception ignored) {}
            playNext();
            return false;
        }
    }

    public List<Step> buildTikrarBerantaiCustomSteps(List<QuranRepository.AyahItem> ayahs, int startIdx, int count, int qariIndex, int repeatPerAyah, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        if (ayahs == null || ayahs.isEmpty()) return steps;
        int safeStart = Math.max(0, Math.min(startIdx, ayahs.size() - 1));
        int endIdx = Math.min(ayahs.size(), safeStart + Math.max(1, count));
        int reps = Math.max(1, Math.min(repeatPerAyah, 10));
        int pauseMs = Math.max(2000, pauseSeconds * 1000);

        steps.add(Step.narrator("metode_tikrar_berantai.mp3",
                "Tikrar Bertahap ayat " + ayahs.get(safeStart).nomorAyat + " sampai " + ayahs.get(endIdx - 1).nomorAyat
                        + ", masing-masing " + reps + " ulangan dengan jeda " + pauseSeconds + " detik."));
        for (int i = safeStart; i < endIdx; i++) {
            QuranRepository.AyahItem cur = ayahs.get(i);
            String url = AppConfig.buildEveryAyahUrl(qariIndex, cur.surahNo, cur.nomorAyat);
            String key = "q" + qariIndex + "_" + cur.surahNo + "_" + cur.nomorAyat + ".mp3";
            for (int r = 1; r <= reps; r++) {
                steps.add(Step.audioUrl(url, key, "Tikrar Ayat " + cur.nomorAyat + " (" + r + "/" + reps + ")"));
                steps.add(Step.imitatePause(pauseMs, "Tirukan ayat " + cur.nomorAyat + " (" + pauseSeconds + "d)",
                        "giliran_baca.mp3", "Sekarang giliran kamu menirukan ayat " + cur.nomorAyat + "."));
            }
            if (i > safeStart) {
                steps.add(Step.narrator("metode_sabak_sabqi.mp3",
                        "Bagus! Sekarang sambungkan ayat " + ayahs.get(safeStart).nomorAyat + " sampai ayat " + cur.nomorAyat + "."));
                for (int g = safeStart; g <= i; g++) {
                    QuranRepository.AyahItem ga = ayahs.get(g);
                    steps.add(Step.audioUrl(AppConfig.buildEveryAyahUrl(qariIndex, ga.surahNo, ga.nomorAyat),
                            "q" + qariIndex + "_" + ga.surahNo + "_" + ga.nomorAyat + ".mp3",
                            "Sambung Ayat " + ga.nomorAyat));
                }
                steps.add(Step.imitatePause(pauseMs + 2000, "Tirukan gabungan ayat utuh",
                        "giliran_baca.mp3", "Sekarang tirukan gabungannya tanpa putus."));
            }
        }
        steps.add(Step.narrator("salam_penutup.mp3", "Alhamdulillah, Tikrar Bertahap selesai!"));
        return steps;
    }

    public List<Step> buildMutasyabihatWithQariSteps(QuranRepository.AyahItem ayah, String mutWarning, int qariIndex, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        String msg = (mutWarning == null || mutWarning.trim().isEmpty())
                ? "Ayat " + ayah.nomorAyat + " ini tidak memiliki ayat mirip yang rawan tertukar. Mari simak bacaan Qari lalu tirukan dengan mantap."
                : "Perhatian Mutasyabihat: " + mutWarning + ". Mari simak Qari lalu tirukan agar tidak tertukar.";
        steps.add(Step.narrator("metode_mutasyabihat.mp3", msg));
        steps.add(Step.audioUrl(AppConfig.buildEveryAyahUrl(qariIndex, ayah.surahNo, ayah.nomorAyat),
                "q" + qariIndex + "_" + ayah.surahNo + "_" + ayah.nomorAyat + ".mp3",
                "Latihan Mutasyabihat Ayat " + ayah.nomorAyat));
        steps.add(Step.imitatePause(Math.max(2000, pauseSeconds * 1000), "Tirukan Ayat " + ayah.nomorAyat,
                "giliran_baca.mp3", "Tirukan dengan fokus pada ujung ayatnya."));
        return steps;
    }

    public List<Step> buildMaqamatWithQariSteps(QuranRepository.AyahItem ayah, int qariIndex, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        steps.add(Step.narrator("metode_maqamat.mp3",
                "Latihan Irama Maqamat Dasar: Bayati untuk ketenangan, Nahawand untuk kekhusyukan, Rast untuk ketegasan. Simak irama Qari pada ayat " + ayah.nomorAyat + " lalu tirukan nadanya."));
        steps.add(Step.audioUrl(AppConfig.buildEveryAyahUrl(qariIndex, ayah.surahNo, ayah.nomorAyat),
                "q" + qariIndex + "_" + ayah.surahNo + "_" + ayah.nomorAyat + ".mp3",
                "Irama Maqamat Ayat " + ayah.nomorAyat));
        steps.add(Step.imitatePause(Math.max(2000, pauseSeconds * 1000), "Tirukan Irama Ayat " + ayah.nomorAyat,
                "giliran_baca.mp3", "Tirukan alunan nadanya dengan tenang."));
        return steps;
    }


    // ================= v6.0 SESI BLOK TERPIMPIN (GABUNG BLOK & UJI BLOK UTUH) =================
    public List<Step> buildGuidedBlockCombineSteps(List<QuranRepository.AyahItem> ayahs, int startIdx, int endIdx,
                                                   int qariIndex, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        if (ayahs == null || ayahs.isEmpty()) return steps;
        int s = Math.max(0, Math.min(startIdx, ayahs.size() - 1));
        int e = Math.max(s, Math.min(endIdx, ayahs.size() - 1));
        int pauseMs = Math.max(2500, pauseSeconds * 1000);

        steps.add(Step.narrator("metode_tikrar_berantai.mp3",
                "Tahap Gabung Blok: kita sambungkan ayat " + ayahs.get(s).nomorAyat
                        + " sampai ayat " + ayahs.get(e).nomorAyat + " secara utuh tanpa putus."));
        for (int round = 1; round <= 2; round++) {
            for (int i = s; i <= e; i++) {
                QuranRepository.AyahItem a = ayahs.get(i);
                steps.add(Step.audioUrl(
                        AppConfig.buildEveryAyahUrl(qariIndex, a.surahNo, a.nomorAyat),
                        "q" + qariIndex + "_" + a.surahNo + "_" + a.nomorAyat + ".mp3",
                        "Gabung Blok (" + round + "/2) — Ayat " + a.nomorAyat));
            }
            steps.add(Step.imitatePause(pauseMs + 2500,
                    "Tirukan gabungan ayat " + ayahs.get(s).nomorAyat + "-" + ayahs.get(e).nomorAyat + " (putaran " + round + "/2)",
                    "giliran_baca.mp3",
                    "Sekarang tirukan gabungan ayat " + ayahs.get(s).nomorAyat + " sampai " + ayahs.get(e).nomorAyat + " secara utuh."));
        }
        steps.add(Step.narrator("salam_penutup.mp3",
                "Alhamdulillah, latihan gabungan blok selesai. Sekarang pilih responmu di layar."));
        return steps;
    }

    public List<Step> buildGuidedBlockTestSteps(List<QuranRepository.AyahItem> ayahs, int startIdx, int endIdx,
                                                int qariIndex, int pauseSeconds) {
        List<Step> steps = new ArrayList<>();
        if (ayahs == null || ayahs.isEmpty()) return steps;
        int s = Math.max(0, Math.min(startIdx, ayahs.size() - 1));
        int e = Math.max(s, Math.min(endIdx, ayahs.size() - 1));
        int pauseMs = Math.max(3000, pauseSeconds * 1000);

        steps.add(Step.narrator("metode_buka_tutup.mp3",
                "Uji Buka-Tutup Blok ayat " + ayahs.get(s).nomorAyat + " sampai " + ayahs.get(e).nomorAyat
                        + ". Qari hanya memancing awal setiap ayat, lalu kamu lanjutkan sendiri."));
        for (int i = s; i <= e; i++) {
            QuranRepository.AyahItem a = ayahs.get(i);
            String url = AppConfig.buildEveryAyahUrl(qariIndex, a.surahNo, a.nomorAyat);
            String key = "q" + qariIndex + "_" + a.surahNo + "_" + a.nomorAyat + ".mp3";
            steps.add(Step.audioUrlPartial(url, key, "Pancingan Awal Ayat " + a.nomorAyat, 0.38f));
            steps.add(Step.imitatePause(pauseMs + 1500, "Teruskan Ayat " + a.nomorAyat + " sendiri",
                    "giliran_baca.mp3", "Teruskan ayat " + a.nomorAyat + " sendiri sekarang."));
        }
        steps.add(Step.narrator("salam_penutup.mp3", "Uji Buka-Tutup Blok selesai!"));
        return steps;
    }

}
