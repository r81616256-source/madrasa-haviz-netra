package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Mesin Pendidikan Formal & Jurnal Rumah -> Server TU (v7.0).
 * Mengelola Gedung Sekolah Formal Pondok (MI/SD, MTs/SMP, MA/SMA, Ma'had Aly)
 * berdampingan dengan Pendidikan Non-Formal (Madrasah Tahfidz & Diniyah),
 * serta kotak masuk Jurnal Refleksi / Catatan Tugas Rumah ke Komputer Server TU.
 */
public class FormalSchoolEngine {

    public static final String[] FORMAL_LEVELS = {
            "MI / SD Inklusif",
            "MTs / SMP Inklusif",
            "MA / SMA Inklusif",
            "Ma'had Aly / Kampus"
    };

    public static class FormalLesson {
        public final String id;
        public final String subject;
        public final String teacher;
        public final String topic;
        public final String explanation;
        public final String question;
        public final String[] choices;
        public final int correctIdx;
        public final String homework;

        public FormalLesson(String id, String subject, String teacher, String topic,
                            String explanation, String question, String[] choices,
                            int correctIdx, String homework) {
            this.id = id;
            this.subject = subject;
            this.teacher = teacher;
            this.topic = topic;
            this.explanation = explanation;
            this.question = question;
            this.choices = choices;
            this.correctIdx = correctIdx;
            this.homework = homework;
        }
    }

    private static final String KEY_FORMAL_LEVEL = "v7_formal_level_idx";
    private static final String KEY_FORMAL_COMPLETED = "v7_formal_completed_cnt";
    private static final String KEY_FORMAL_SCORE_AVG = "v7_formal_score_avg";
    private static final String KEY_HOME_JOURNALS = "v7_home_journals_tu";
    private static final String KEY_TU_REPLIES = "v7_tu_journal_replies";

    private final SharedPreferences prefs;

    public FormalSchoolEngine(Context context) {
        this.prefs = context.getApplicationContext().getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
    }

    public int getFormalLevelIndex() {
        return Math.max(0, Math.min(FORMAL_LEVELS.length - 1, prefs.getInt(KEY_FORMAL_LEVEL, 1)));
    }

    public void setFormalLevelIndex(int idx) {
        prefs.edit().putInt(KEY_FORMAL_LEVEL, Math.max(0, Math.min(FORMAL_LEVELS.length - 1, idx))).apply();
    }

    public String getFormalLevelLabel() {
        return FORMAL_LEVELS[getFormalLevelIndex()];
    }

    public int getCompletedFormalSessions() {
        return prefs.getInt(KEY_FORMAL_COMPLETED, 0);
    }

    public int getFormalScoreAverage() {
        return prefs.getInt(KEY_FORMAL_SCORE_AVG, 80);
    }

    public void recordFormalSessionResult(String subject, int scorePct) {
        int done = getCompletedFormalSessions() + 1;
        int prevAvg = getFormalScoreAverage();
        int newAvg = Math.max(0, Math.min(100, (prevAvg * (done - 1) + scorePct) / done));
        prefs.edit()
                .putInt(KEY_FORMAL_COMPLETED, done)
                .putInt(KEY_FORMAL_SCORE_AVG, newAvg)
                .putString("v7_formal_last_subject", subject)
                .apply();
    }

    public List<FormalLesson> getLessonsForCurrentLevel() {
        List<FormalLesson> list = new ArrayList<>();
        String lvl = getFormalLevelLabel();

        list.add(new FormalLesson(
                "bindo",
                "Bahasa Indonesia (" + lvl + ")",
                "Ibu Guru Rahma",
                "Menyusun Ringkasan Lisan & Gagasan Pokok",
                "Gagasan pokok adalah inti utama dalam sebuah paragraf atau tuturan lisan. "
                        + "Bagi pelajar tunanetra, menyimak kalimat pertama dan kalimat penutup sangat membantu menemukan ide utama secara cepat.",
                "Apa fungsi utama gagasan pokok dalam sebuah paragraf?",
                new String[]{
                        "Menjadi inti utama yang menjelaskan arah keseluruhan paragraf",
                        "Menghias kalimat agar terdengar lebih panjang saja",
                        "Menggantikan tanda baca di akhir kalimat",
                        "Memisahkan nama penulis dari judul bacaan"
                },
                0,
                "Ringkas 1 pelajaran hari ini dalam 2 kalimat lisan di Buku Catatan Digital Rumah."
        ));

        list.add(new FormalLesson(
                "matematika",
                "Matematika Audio & Logika (" + lvl + ")",
                "Pak Guru Hasan",
                "Berhitung Cepat & Perbandingan Sehari-hari",
                "Dalam matematika mental tanpa kertas, kita bisa memecah angka puluhan dan satuan. "
                        + "Contoh: 25 ditambah 37 dapat dihitung sebagai (20+30) + (5+7) = 50 + 12 = 62.",
                "Dengan cara memecah puluhan dan satuan, berapakah hasil 38 ditambah 27?",
                new String[]{
                        "65",
                        "55",
                        "63",
                        "75"
                },
                0,
                "Latih 3 soal penjumlahan mental saat membantu di Dapur Rumah."
        ));

        list.add(new FormalLesson(
                "ipa",
                "IPA / Sains Alam (" + lvl + ")",
                "Ibu Guru Salma",
                "Indera Pendengaran, Bunyi & Kesehatan Suara",
                "Bunyi merambat melalui udara, benda cair, dan benda padat. "
                        + "Menjaga kelembapan tenggorokan dengan air hangat dan istirahat cukup membantu pita suara bergetar jernih saat membaca Al-Qur'an.",
                "Mengapa minum air hangat membantu menjaga kejernihan suara saat belajar?",
                new String[]{
                        "Menjaga kelembapan dan kelenturan pita suara agar tidak cepat lelah",
                        "Menghentikan rambatan bunyi di udara",
                        "Membuat telinga tidak perlu mendengar suara",
                        "Menggantikan kebutuhan tidur malam"
                },
                0,
                "Jaga stamina suara dengan air hangat di Dapur Rumah sebelum murajaah malam."
        ));

        list.add(new FormalLesson(
                "ppkn",
                "Pendidikan Pancasila & Kewarganegaraan (" + lvl + ")",
                "Pak Guru Arif",
                "Hak Aksesibilitas & Gotong Royong Inklusif",
                "Setiap warga negara, termasuk penyandang disabilitas netra, memiliki hak yang setara atas pendidikan bermutu, "
                        + "lingkungan yang ramah aksesibilitas, serta kesempatan berkarya bagi bangsa.",
                "Sikap mana yang paling mencerminkan nilai gotong royong inklusif di sekolah?",
                new String[]{
                        "Saling membantu, menghargai perbedaan kebutuhan akses, dan menjaga fasilitas bersama",
                        "Membiarkan teman kesulitan mencari ruangan sendiri",
                        "Menggunakan perangkat bersama tanpa mau merawatnya",
                        "Hanya berteman dengan orang yang satu daerah saja"
                },
                0,
                "Catat 1 contoh sikap saling membantu di pondok pada jurnal refleksi rumah."
        ));

        list.add(new FormalLesson(
                "bahasa",
                "Bahasa Arab & Inggris Dasar (" + lvl + ")",
                "Ustadz Fajar",
                "Kosakata Salam, Kelas & Buku Sehari-hari",
                "Dalam Bahasa Arab, 'Madrasah' berarti sekolah, 'Kitab' berarti buku, dan 'Ustadz' berarti guru. "
                        + "Dalam Bahasa Inggris, 'Classroom' berarti ruang kelas dan 'Library' berarti perpustakaan.",
                "Apa arti kata 'Library' dalam Bahasa Inggris dan padanannya di pondok kita?",
                new String[]{
                        "Perpustakaan tempat membaca dan latihan bebas",
                        "Kantor Tata Usaha tempat mencetak rapor",
                        "Dapur rumah tempat menyiapkan sarapan",
                        "Gerbang depan tempat pos jaga"
                },
                0,
                "Ucapkan 3 kosakata Arab dan Inggris tentang ruangan pondok sebelum tidur."
        ));

        return list;
    }

    // ================= JURNAL REFLEKSI & CATATAN RUMAH -> KOMPUTER SERVER TU =================

    public void sendHomeJournalToTu(String santriName, String category, String content) {
        if (content == null || content.trim().isEmpty()) return;
        String stamp = new SimpleDateFormat("dd/MM HH:mm", Locale.US).format(new Date());
        String entry = stamp + " | " + category + " | " + santriName + ": " + content.trim();
        String old = prefs.getString(KEY_HOME_JOURNALS, "");
        String merged = old.isEmpty() ? entry : (entry + "\n" + old);
        String[] lines = merged.split("\n");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(lines.length, 20); i++) {
            if (i > 0) sb.append("\n");
            sb.append(lines[i]);
        }
        prefs.edit().putString(KEY_HOME_JOURNALS, sb.toString()).apply();
    }

    public List<String> getPendingHomeJournalsForTu() {
        List<String> list = new ArrayList<>();
        String raw = prefs.getString(KEY_HOME_JOURNALS, "");
        if (raw == null || raw.trim().isEmpty()) return list;
        for (String line : raw.split("\n")) {
            if (!line.trim().isEmpty()) list.add(line.trim());
        }
        return list;
    }

    public void saveTuResponseToJournal(String responseText) {
        if (responseText == null || responseText.trim().isEmpty()) return;
        String stamp = new SimpleDateFormat("dd/MM HH:mm", Locale.US).format(new Date());
        String entry = stamp + " • Ustadzah Nur: " + responseText.trim();
        String old = prefs.getString(KEY_TU_REPLIES, "");
        String merged = old.isEmpty() ? entry : (entry + "\n" + old);
        prefs.edit().putString(KEY_TU_REPLIES, merged).apply();
    }

    public String getLatestTuRepliesSummary() {
        String raw = prefs.getString(KEY_TU_REPLIES, "");
        if (raw == null || raw.trim().isEmpty()) {
            return "Belum ada tanggapan baru dari Ustadzah Nur. Kirim catatan atau PR rumah dari Kamar Pribadi lalu cek di Kantor TU.";
        }
        return raw;
    }
}
