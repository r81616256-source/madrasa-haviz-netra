package com.suaramediateknologi.madrasahhafiznetra;

public final class AppConfig {
    public static final String APP_NAME = "Madrasah Hafidz Netra";
    public static final String BRAND_NAME = "Suara Media Teknologi — Nur & Mas Yeni Setiawan";
    public static final String VERSION_LABEL = "v1.4.0 Final (22 November 2026)";
    public static final String CONTACT_WHATSAPP = "0877-8158-6983";
    public static final String CONTACT_WA_URL = "https://wa.me/6287781586983";

    public static final String FIREBASE_RTDB_BASE =
            "https://gen-lang-client-0023395632-default-rtdb.asia-southeast1.firebasedatabase.app/madrasah_hafiz_netra";

    public static final String RELEASE_BASE_URL =
            "https://github.com/" + BuildConfig.GITHUB_REPO + "/releases/download/materi-latest/";
    public static final String KATALOG_URL = RELEASE_BASE_URL + "katalog_materi.json";
    public static final String DOA_WEB_FORM_URL =
            "https://r81616256-source.github.io/madrasa-haviz-netra/";

    public static final String EQURAN_LIST_URL = "https://equran.id/api/v2/surat";
    public static final String EQURAN_SURAH_URL = "https://equran.id/api/v2/surat/";
    public static final String EVERYAYAH_BASE_URL = "https://everyayah.com/data/";
    public static final String QURANCOM_BY_KEY_URL = "https://api.quran.com/api/v4/verses/by_key/";
    public static final String QURANCOM_AUDIO_BASE = "https://audio.qurancdn.com/";

    public static final String GEMINI_API_KEY_URL = "https://aistudio.google.com/app/apikey";
    public static final String GOOGLE_TTS_PACKAGE = "com.google.android.tts";

    public static final String PREF_NAME = "mhn_prefs";
    public static final String KEY_TTS_ENGINE_MODE = "tts_engine_mode";
    public static final String KEY_TTS_VOICE_NAME = "tts_voice_name";
    public static final String KEY_QARI_INDEX = "qari_index";
    public static final String KEY_REPEAT_COUNT = "repeat_count";
    public static final String KEY_PAUSE_SECONDS = "pause_seconds";
    public static final String KEY_PLAYBACK_SPEED = "playback_speed";
    public static final String KEY_GEMINI_API_KEY = "gemini_api_key";
    public static final String KEY_WELCOME_ENABLED = "welcome_enabled";
    public static final String KEY_VOLUME_KEYS_ENABLED = "volume_keys_enabled";
    public static final String KEY_CURRENT_LEVEL = "current_level";
    public static final String KEY_PROGRAM_MODE = "program_mode";
    public static final String KEY_LAST_SURAH = "last_surah";
    public static final String KEY_LAST_AYAH = "last_ayah";
    public static final String KEY_REMINDER_ENABLED = "reminder_enabled";
    public static final String KEY_QUIET_HOURS = "quiet_hours";
    public static final String KEY_LATIN_CLEAN_TTS = "latin_clean_tts";
    public static final String KEY_XP_POINTS = "xp_points";
    public static final String KEY_MISSION_DATE = "mission_date";
    public static final String KEY_MISSION_ZIYADAH = "mission_ziyadah";
    public static final String KEY_MISSION_TASMI = "mission_tasmi";
    public static final String KEY_MISSION_MURAJAAH = "mission_murajaah";

    public static final String KEY_SANTRI_NAME = "santri_name";
    public static final String KEY_SANTRI_CITY = "santri_city";
    public static final String KEY_SANTRI_WALI = "santri_wali";
    public static final String KEY_SANTRI_NIS = "santri_nis";
    public static final String KEY_SANTRI_JOIN_DATE = "santri_join_date";
    public static final String KEY_SANTRI_TRACK = "santri_track"; // 0=Pemula Nol, 1=Pelancaran An-Nas, 2=Lanjutan
    public static final String KEY_RULES_AGREED = "rules_agreed";
    public static final String KEY_CLASS_SLOT = "class_slot"; // 0=Pagi, 1=Siang, 2=Sore, 3=Malam
    public static final String KEY_SP_LEVEL = "sp_level"; // 0=Aman, 1=SP1, 2=SP2+Tazir, 3=Skorsing
    public static final String KEY_TAZIR_PENDING = "tazir_pending";
    public static final String KEY_PIKET_WEEK = "piket_week";
    public static final String KEY_GRADE_KELANCARAN = "grade_kelancaran";
    public static final String KEY_GRADE_DINIYAH = "grade_diniyah";
    public static final String KEY_GRADE_UJIAN = "grade_ujian";
    public static final String KEY_UNLOCKED_MAX_LEVEL = "unlocked_max_level";
    public static final String KEY_JUZ30_UNLOCKED_COUNT = "juz30_unlocked_count";
    public static final String KEY_KITAB_UNLOCKED_COUNT = "kitab_unlocked_count";
    public static final String KEY_PIAGAM_COUNT = "piagam_count";

    public static final String KEY_FOCUS_SURAH = "focus_surah";
    public static final String KEY_FOCUS_START = "focus_start";
    public static final String KEY_FOCUS_END = "focus_end";
    public static final String KEY_FOCUS_STATUS = "focus_status";
    public static final String KEY_FOCUS_START_MS = "focus_start_ms";
    public static final String KEY_FOCUS_ROUNDS = "focus_rounds";
    public static final String KEY_FOCUS_MINUTES = "focus_minutes";
    public static final String KEY_ATTENDANCE_TODAY_STATUS = "att_today_status";
    public static final String KEY_ATTENDANCE_TODAY_DATE = "att_today_date";
    public static final String KEY_ATTENDANCE_LEAVE_REASON = "att_leave_reason";
    public static final String KEY_REFLECTION_TODAY = "reflection_today";
    public static final String KEY_TOTAL_HADIR = "total_hadir";
    public static final String KEY_TOTAL_IZIN = "total_izin";
    public static final String KEY_STREAK_DAYS = "streak_days";
    public static final String KEY_LAST_ACTIVE_MS = "last_active_ms";
    public static final String KEY_CUSTOM_ALARM_URI = "custom_alarm_uri";
    public static final String KEY_ARWAH_LIST_JSON = "arwah_list_json";
    public static final String KEY_DAILY_LOG_JSON = "daily_log_json";
    public static final String KEY_KITAB_COMPLETED = "kitab_completed";

    public static final String TATA_TERTIB_TEXT =
            "PERATURAN & TATA TERTIB RESMI MADRASAH HAFIDZ NETRA:\n" +
            "1. Meluruskan niat ikhlas karena Allah dan menjaga adab terhadap Al-Qur'an.\n" +
            "2. Disiplin hadir sesuai jam kelas tetap yang dipilih saat pendaftaran.\n" +
            "3. Wajib mengisi absen hadir, atau mengajukan Izin Resmi bila sakit/berhalangan.\n" +
            "4. Sanksi tegas berlaku bagi Alfa tanpa izin: 1 hari SP-1, 2 hari SP-2 & Ta'zir Murajaah, 3 hari berturut-turut Skorsing Sementara hingga lulus Sidang Pemulihan.\n" +
            "5. Mengikuti jenjang kelas sesuai hasil Tes Masuk 3 Surat Pendek tanpa melompati tahap.";

    public static final String[] CLASS_SLOTS = {
            "1. Reguler Subuh (05.30 - 07.00)",
            "2. Pagi 1 (07.00 - 08.00)",
            "3. Pagi Dhuha 1 (08.00 - 09.00)",
            "4. Pagi Dhuha 2 (09.00 - 10.00)",
            "5. Pagi Akhir (10.00 - 11.00)",
            "6. Kelas Siang (13.00 - 14.00)",
            "7. Kelas Sore (16.00 - 17.00)",
            "8. Kelas Malam (19.30 - 20.30)",
            "9. Mode Fleksibel (Santri Sibuk)"
    };
    public static final int[][] CLASS_SLOT_TIMES = {
            {5, 30, 7, 0},
            {7, 0, 8, 0},
            {8, 0, 9, 0},
            {9, 0, 10, 0},
            {10, 0, 11, 0},
            {13, 0, 14, 0},
            {16, 0, 17, 0},
            {19, 30, 20, 30},
            {0, 0, 23, 59}
    };
    public static final int[] CLASS_SLOT_START_HOUR = {5, 13, 16, 19};
    public static final int[] CLASS_SLOT_END_HOUR = {7, 15, 18, 21};

    public static final String[] KAMAR_NAMES = {
            "Kamar An-Nas (Jalur Pemula Nol)",
            "Kamar Al-Mulk (Jalur Pelancaran Juz 30)",
            "Kamar Yasin (Jalur Tahap Lanjutan)"
    };
    public static final String[] KAMAR_KEYS = {"kamar_annas", "kamar_almulk", "kamar_yasin"};

    public static final String[] REGISTRATION_TRACKS = {
            "Jalur 1: Pra-BBQ Pemula Nol (28 Hijaiyah & An-Nas)",
            "Jalur 2: Pelancaran Hafalan (Juz 30 Mundur An-Nas -> An-Naba')",
            "Jalur 3: Tahap Lanjutan (Juz 29-30, Gharib, Murajaah & MHQ)"
    };

    // Ruang Curhat & Obat Futur (Ustadzah Nur + Ayat Penenang Qari)
    public static final String[][] CURHAT_OPTIONS = {
            {"Lagi Malas / Futur Menghafal", "94", "5", "Ustadzah Nur berpesan: Wajar sesekali merasa lelah. Jangan berhenti total, cukup ulang 1 ayat saja hari ini. Ingat janji Allah dalam Surat Al-Insyirah: bersama kesulitan selalu ada kemudahan."},
            {"Sering Lupa Ayat yang Sudah Dihafal", "54", "17", "Ustadzah Nur berpesan: Lupa adalah bagian dari proses menghafal, bukan tanda gagal. Setiap kali mengulang, pahala hurufnya berlipat ganda. Simak janji Allah bahwa Al-Qur'an dimudahkan untuk diingat."},
            {"Sedang Sedih / Gelisah Hati", "13", "28", "Ustadzah Nur berpesan: Tarik napas perlahan, lepaskan beban sejenak. Simak Surat Ar-Ra'd ayat 28 berikut ini, hanya dengan mengingat Allah hati menjadi tenteram."},
            {"Susah Membagi Waktu Harian", "103", "1", "Ustadzah Nur berpesan: Cukup luangkan 10 menit tetap di jam kelas pilihan Anda, atau ajukan izin belajar mandiri jika sangat sibuk. Sedikit tapi istiqamah lebih dicintai Allah."}
    };

    public static final int[] JUZ30_REVERSED_NUMS = {
            114, 113, 112, 111, 110, 109, 108, 107, 106, 105,
            104, 103, 102, 101, 100, 99, 98, 97, 96, 95,
            94, 93, 92, 91, 90, 89, 88, 87, 86, 85,
            84, 83, 82, 81, 80, 79, 78
    };

    public static final String[] JUZ30_REVERSED_NAMES = {
            "114. An-Nas", "113. Al-Falaq", "112. Al-Ikhlas", "111. Al-Lahab", "110. An-Nashr",
            "109. Al-Kafirun", "108. Al-Kautsar", "107. Al-Ma'un", "106. Quraisy", "105. Al-Fil",
            "104. Al-Humazah", "103. Al-'Ashr", "102. At-Takatsur", "101. Al-Qari'ah", "100. Al-'Adiyat",
            "99. Az-Zalzalah", "98. Al-Bayyinah", "97. Al-Qadr", "96. Al-'Alaq", "95. At-Tin",
            "94. Al-Insyirah", "93. Ad-Dhuha", "92. Al-Lail", "91. Asy-Syams", "90. Al-Balad",
            "89. Al-Fajr", "88. Al-Ghasyiyah", "87. Al-A'la", "86. Ath-Thariq", "85. Al-Buruj",
            "84. Al-Insyiqaq", "83. Al-Muthaffifin", "82. Al-Infithar", "81. At-Takwir", "80. 'Abasa",
            "79. An-Nazi'at", "78. An-Naba'"
    };

    public static final String[][] DEWAN_GURU = {
            {"Ustadz Yeni Setiawan", "Kepala Madrasah & Penguji Utama (Wisuda & Sidang Terbuka)"},
            {"Ustadzah Nur", "Wali Kelas Harian, Tata Tertib & Pengendali Agen Otomatis"},
            {"Ustadz Ardi Pratama", "Guru Kelas 28 Huruf Hijaiyah & Klinik Makhraj"},
            {"Ustadzah Siti Aminah", "Guru Tahsin Dasar & Bedah Tajwid Lisan"},
            {"Ustadz Ahmad Fauzi", "Guru Tahfidz Juz 30 Mundur (An-Nas s.d. An-Naba')"},
            {"Ustadzah Fatimah Az-Zahra", "Pembimbing Blok Fokus Ayat (1-3 / 1-10) & Tikrar Berantai"},
            {"Ustadz Muhammad Ridwan", "Pembimbing Ruang Murajaah Pintar (Sabaq, Sabqi, Manzil)"},
            {"Ustadz Hasan Basri", "Pengampu Fikih Ibadah Kitab Safinatun Najah"},
            {"Ustadz Abdul Hakim", "Pengampu Tauhid Kitab Aqidatul Awam"},
            {"Ustadzah Khadijah Rahmawati", "Pengampu Adab Tahfidz, Akhlak & Doa Harian"},
            {"Ustadz Zainal Abidin", "Guru Kelas Gharib, Waqaf & Ibtida' serta Irama Murattal"},
            {"Ustadzah Maryam Hidayah", "Pembimbing Kisah Surat (Asbabun Nuzul) & Kelas Sore Akhir Pekan"}
    };

    public static final String[] QARI_NAMES = {
            "Syekh Al-Husary (Tempo Lambat / Talaqqi)",
            "Syekh Mishary Alafasy (Jernih & Populer)",
            "Syekh Abdul Basit Murattal (Tegas)",
            "Syekh As-Sudais (Imam Masjidil Haram)",
            "Syekh Abu Bakr Asy-Syatiri (Lembut)"
    };

    public static final String[] QARI_FOLDERS = {
            "Husary_64kbps",
            "Alafasy_64kbps",
            "Abdul_Basit_Murattal_64kbps",
            "Abdurrahmaan_As-Sudais_64kbps",
            "Abu_Bakr_Ash-Shaatree_64kbps"
    };

    public static final String[] LEVEL_TITLES = {
            "Tingkat 0: Pra-BBQ Pemula Nol (Hijaiyah + An-Nas s.d. Al-Kautsar)",
            "Tingkat 1: Pelancaran Hafalan (An-Nas mundur s.d. Ad-Dhuha)",
            "Tingkat 2: Tahfidz Juz 30 (Al-Lail mundur s.d. An-Naba')",
            "Tingkat 3: Menengah (Juz 29, Juz 28 & Surat Pilihan)",
            "Tingkat 4: Lanjut (Lintas Juz & Mutasyabihat)",
            "Tingkat 5: Mutqin (Simulasi Ujian MHQ 30 Juz)"
    };

    public static final String[] SANTRI_RANKS = {
            "Santri Pra-BBQ",
            "Santri Pelancaran BBQ",
            "Santri Ibtida'i (Juz 30)",
            "Santri Mutawassith",
            "Santri Mutaqaddim",
            "Hafidz Mutqin"
    };

    public static final int[] LEVEL_DEFAULT_SURAHS = {114, 114, 92, 67, 36, 78};

    public static final String[][] HIJAIYAH_28 = {
            {"1. Alif (ا)", "Keluar dari rongga mulut dan tenggorokan, bunyi vokal terbuka A, I, U."},
            {"2. Ba (ب)", "Merapatkan kedua bibir dengan mantap, termasuk huruf Qalqalah bila disukun."},
            {"3. Ta (ت)", "Ujung lidah menempel pada pangkal gigi seri atas, bunyi lembut tanpa desis."},
            {"4. Tsa (ث)", "Ujung lidah sedikit menempel di ujung gigi seri atas, bunyi tipis seperti Tsa."},
            {"5. Jim (ج)", "Tengah lidah menempel ke langit-langit atas dengan tegas, termasuk Qalqalah."},
            {"6. Ha Kecil (ح)", "Keluar dari tengah tenggorokan dengan suara bersih dan halus tanpa serak."},
            {"7. Kha (خ)", "Keluar dari tenggorokan bagian atas dengan getaran lembut."},
            {"8. Dal (د)", "Ujung lidah menempel pada pangkal gigi seri atas, memantul kuat saat disukun."},
            {"9. Dzal (ذ)", "Ujung lidah menempel pada ujung gigi seri atas dengan suara bergetar lembut."},
            {"10. Ra (ر)", "Ujung lidah menyentuh gusi atas dengan satu getaran ringan."},
            {"11. Zai (ز)", "Ujung lidah di balik gigi seri bawah dengan desis bergetar."},
            {"12. Sin (س)", "Ujung lidah di balik gigi seri bawah dengan desis angin tipis dan bersih."},
            {"13. Syin (ش)", "Tengah lidah terangkat ke langit-langit sehingga angin menyebar lembut."},
            {"14. Shad (ص)", "Seperti Sin namun pangkal lidah terangkat sehingga suaranya tebal dan bulat."},
            {"15. Dhad (ض)", "Tepi lidah menempel pada gigi geraham atas, bunyi tebal khas bahasa Arab."},
            {"16. Tha (ط)", "Ujung lidah di pangkal gigi seri atas dengan suara sangat tebal dan Qalqalah."},
            {"17. Zha (ظ)", "Ujung lidah di ujung gigi seri atas seperti Dzal tetapi bersuara tebal."},
            {"18. Ain (ع)", "Keluar dari tengah tenggorokan sedikit ditekan halus."},
            {"19. Ghain (غ)", "Keluar dari tenggorokan atas dengan suara bergetar lembut."},
            {"20. Fa (ف)", "Ujung gigi seri atas menempel lembut di bagian dalam bibir bawah."},
            {"21. Qaf (ق)", "Pangkal lidah menyentuh langit-langit lunak paling belakang, tebal dan Qalqalah."},
            {"22. Kaf (ك)", "Pangkal lidah sedikit lebih maju dari Qaf, bunyi tipis dengan hembusan lembut."},
            {"23. Lam (ل)", "Ujung tepi lidah menyentuh gusi gigi depan atas, bunyi mengalir lancar."},
            {"24. Mim (م)", "Merapatkan kedua bibir dengan aliran dengung lembut dari pangkal hidung."},
            {"25. Nun (ن)", "Ujung lidah menempel pada gusi atas disertai dengung dari rongga hidung."},
            {"26. Waw (و)", "Memonyongkan kedua bibir membentuk bulatan tanpa merapatkannya."},
            {"27. Ha Besar (ه)", "Keluar dari pangkal tenggorokan paling bawah dekat dada dengan hembusan lega."},
            {"28. Ya (ي)", "Tengah lidah terangkat mendekati langit-langit atas, bunyi ringan dan jelas."}
    };

    public static final String[][] KITAB_DASAR = {
            {"Safinatun Najah — Bab 1: Lima Rukun Islam", "Ustadz Hasan Basri", "[Menunggu Tashih Ustadz]", "Kitab Safinatun Najah karya Syekh Salim bin Sumair Al-Hadhrami. Rukun Islam ada lima: syahadat, salat lima waktu, zakat, puasa Ramadan, dan haji bagi yang mampu."},
            {"Safinatun Najah — Bab 2: Enam Rukun Iman", "Ustadz Hasan Basri", "[Menunggu Tashih Ustadz]", "Rukun Iman ada enam: beriman kepada Allah, malaikat, kitab, rasul, hari akhir, serta qadha dan qadar."},
            {"Safinatun Najah — Bab 3: Enam Fardhu Wudhu", "Ustadz Hasan Basri", "[Menunggu Tashih Ustadz]", "Fardhu wudhu ada enam: niat saat membasuh wajah, membasuh wajah, membasuh kedua tangan hingga siku, mengusap sebagian kepala, membasuh kedua kaki hingga mata kaki, dan tertib."},
            {"Safinatun Najah — Bab 4: Empat Pembatal Wudhu", "Ustadz Hasan Basri", "[Menunggu Tashih Ustadz]", "Pembatal wudhu ada empat: keluar sesuatu dari dua jalan selain mani, hilang akal/tidur tidak mantap duduknya, bersentuhan kulit bukan mahram tanpa penghalang, dan menyentuh kemaluan dengan telapak tangan."},
            {"Safinatun Najah — Bab 5: Ringkasan Rukun Shalat", "Ustadz Hasan Basri", "[Menunggu Tashih Ustadz]", "Rukun shalat menurut Safinatun Najah ada tujuh belas dimulai dari niat, takbiratul ihram, Al-Fatihah, rukuk, iktidal, sujud, tasyahud akhir, hingga salam dan tertib."},
            {"Aqidatul Awam — 20 Sifat Wajib Bagi Allah", "Ustadz Abdul Hakim", "[Menunggu Tashih Ustadz]", "Setiap mukallaf wajib mengenal sifat wajib bagi Allah, antara lain Wujud (Ada), Qidam (Terdahulu), Baqa (Kekal), hingga Kalam (Maha Berfirman)."},
            {"Adab & Akhlak Santri — Memuliakan Al-Qur'an", "Ustadzah Khadijah Rahmawati", "[Menunggu Tashih Ustadz]", "Adab utama santri penghafal Al-Qur'an adalah meluruskan niat, menjaga wudhu, hormat pada guru dan orang tua, serta sabar mengulang hafalan."}
    };

    public static String buildEveryAyahUrl(int qariIndex, int surahNo, int ayahNo) {
        int idx = Math.max(0, Math.min(qariIndex, QARI_FOLDERS.length - 1));
        String s = String.format(java.util.Locale.US, "%03d", surahNo);
        String a = String.format(java.util.Locale.US, "%03d", ayahNo);
        return EVERYAYAH_BASE_URL + QARI_FOLDERS[idx] + "/" + s + a + ".mp3";
    }

    public static String buildWordDirectFallbackUrl(int surahNo, int ayahNo, int wordPos) {
        String s = String.format(java.util.Locale.US, "%03d", surahNo);
        String a = String.format(java.util.Locale.US, "%03d", ayahNo);
        String w = String.format(java.util.Locale.US, "%03d", wordPos);
        return QURANCOM_AUDIO_BASE + "wbw/" + s + "_" + a + "_" + w + ".mp3";
    }

    private AppConfig() {}

    // ================= v2.0 ASRAMA PESANTREN HIDUP KEYS & DATA =================
    public static final String KEY_GUEST_MODE = "guest_mode_v2";
    public static final String KEY_SANTRI_GOAL = "santri_goal_v2";
    public static final String KEY_SK_NUMBER = "sk_psb_number_v2";
    public static final String KEY_SLEEP_LOCK_ENABLED = "sleep_lock_enabled_v2";
    public static final String KEY_WIRID_SORE_ENABLED = "wirid_sore_17_enabled_v2";
    public static final String KEY_TALKBACK_DELAY_ENABLED = "talkback_delay_enabled_v2";
    public static final String KEY_KAKAK_ASUH_STYLE = "kakak_asuh_style_v2";
    public static final String KEY_PELINDUNG_SP_COUNT = "pelindung_sp_count_v2";
    public static final String KEY_HONOR_TITLE = "honor_title_v2";
    public static final String KEY_BELL_THEME = "bell_theme_v2";
    public static final String KEY_CUTI_UNTIL_DAY = "cuti_until_day_v2";
    public static final String KEY_AYAH_MASTERY_JSON = "ayah_mastery_json_v2";
    public static final String KEY_SPACED_REP_JSON = "spaced_rep_json_v2";
    public static final String KEY_DIFFICULT_AYAHS_JSON = "difficult_ayahs_json_v2";
    public static final String KEY_PERSONAL_AGENDA_JSON = "personal_agenda_json_v2";
    public static final String KEY_PLAYLIST_JSON = "personal_playlist_json_v2";
    public static final String KEY_SURAT_ARSIP_JSON = "surat_arsip_json_v2";
    public static final String KEY_HISTORY_TIMELINE_JSON = "history_timeline_json_v2";
    public static final String KEY_ATTENDANCE_MONTH_JSON = "attendance_month_json_v2";
    public static final String KEY_KHATAM_TARGET_DAYS = "khatam_target_days_v2";
    public static final String KEY_KHATAM_START_EPOCH = "khatam_start_epoch_v2";
    public static final String KEY_TODAY_PR_TEXT = "today_pr_text_v2";
    public static final String KEY_TODAY_MOOD = "today_mood_v2";
    public static final String KEY_BEL_PULANG_SHOWN_DAY = "bel_pulang_shown_day_v2";
    public static final String KEY_WIRID_SHOWN_DAY = "wirid_shown_day_v2";
    public static final String KEY_FAMILY_STAMP_COUNT = "family_stamp_count_v2";
    public static final String KEY_LAST_TU_MISSION_DAY = "last_tu_mission_day_v2";

    public static final String[] SANTRI_GOALS = {
            "Mulai dari Nol (Kenal Huruf & Baca Lancar)",
            "Hafal & Lancar Juz 30 (An-Nas sampai An-Naba)",
            "Mantapkan Hafalan, Tajwid & Kitab Dasar"
    };

    // Format: MM-DD -> Nama Hari Besar / Tanggal Merah
    public static final String[][] HOLIDAYS_MMDD = {
            {"01-01", "Tahun Baru Masehi"},
            {"05-01", "Hari Buruh Nasional"},
            {"06-01", "Hari Lahir Pancasila"},
            {"08-17", "Hari Kemerdekaan RI"},
            {"10-22", "Hari Santri Nasional"},
            {"12-25", "Hari Libur Nasional"}
    };

    // 6 Mata Pelajaran Dialog Interaktif: {Judul, Penjelasan Singkat, Pertanyaan Kasus, Pilihan A, Pilihan B, JawabanBenar(0/1), Pembahasan}
    public static final String[][] INTERACTIVE_LESSONS = {
            {"Fikih Wudhu (Safinatun Najah)",
             "Wudhu memiliki 6 fardhu: niat, membasuh wajah, kedua tangan sampai siku, mengusap sebagian kepala, membasuh kaki sampai mata kaki, dan tertib.",
             "Studi Kasus: Jika seseorang sudah berwudhu lalu tidur pulas sambil berbaring miring, apakah wudhunya batal?",
             "Ya, batal wudhunya", "Tidak batal", "0",
             "Tepat sekali! Tidur berbaring yang menghilangkan kesadaran membatalkan wudhu, berbeda dengan tidur duduk mantap."},
            {"Fikih Shalat (Safinatun Najah)",
             "Syarat sah shalat antara lain suci dari hadats dan najis, menutup aurat, menghadap kiblat, masuk waktu, dan mengetahui fardhu shalat.",
             "Studi Kasus: Saat shalat berjamaah, makmum lupa membaca Al-Fatihah di rakaat pertama padahal sempat bersama imam sejak awal. Bagaimana hukumnya?",
             "Wajib membaca Al-Fatihah karena rukun", "Tidak apa-apa ditinggalkan", "0",
             "Benar! Al-Fatihah adalah rukun shalat bagi makmum muwafiq yang punya cukup waktu."},
            {"Tajwid Qalqalah & Pantulan",
             "Huruf Qalqalah ada 5: Qaf, Tha, Ba, Jim, Dal (disingkat Baju Di Thoqo). Jika mati di akhir ayat karena waqaf, dibaca memantul kuat (Qalqalah Kubra).",
             "Studi Kasus: Pada akhir Surat Al-Falaq ayat 1 (Qul a'udzu birabbil falaq), huruf Qaf dimatikan saat berhenti. Termasuk Qalqalah apa?",
             "Qalqalah Kubra (pantulan besar)", "Qalqalah Sughra (pantulan kecil)", "0",
             "MasyaAllah tepat! Karena berhenti di akhir ayat, pantulannya kuat (Kubra)."},
            {"Tauhid (Aqidatul Awam)",
             "Allah memiliki 20 sifat wajib, di antaranya Wujud (Ada), Qidam (Terdahulu tanpa awal), Baqa' (Kekal), dan Mukhalafatu lil hawaditsi (Berbeda dengan makhluk).",
             "Studi Kasus: Sifat Allah yang berarti Kekal dan tidak akan pernah binasa disebut sifat apa?",
             "Baqa' (Kekal)", "Qidam (Terdahulu)", "0",
             "Betul! Baqa' artinya Allah Maha Kekal selamanya."},
            {"Adab Penghafal Al-Qur'an",
             "Penghafal Al-Qur'an dianjurkan menjaga keikhlasan niat, berwudhu, membaca dengan tenang, dan mengulang hafalan lama agar tidak lepas seperti unta yang terikat.",
             "Studi Kasus: Mana sikap terbaik saat mendadak lupa satu ayat yang dulu sudah dihafal?",
             "Tetap tenang, ulang pelan & tandai untuk murajaah", "Menyerah dan berhenti menghafal", "0",
             "Luar biasa! Lupa adalah hal manusiawi; obatnya adalah sabar mengulang dan murajaah rutin."},
            {"Asbabun Nuzul & Kisah Surat",
             "Memahami kisah turunnya surat membuat hafalan jauh lebih kuat. Surat Al-Fil mengisahkan pasukan bergajah Abrahah yang gagal menghancurkan Ka'bah.",
             "Studi Kasus: Pasukan burung yang diutus Allah untuk melindungi Ka'bah dalam Surat Al-Fil disebut burung apa?",
             "Burung Ababil", "Burung Hud-hud", "0",
             "Tepat sekali! Burung Ababil melempari pasukan gajah dengan batu dari tanah yang terbakar."}
    };

    // Kamus Audio Tajwid & Gharib: {Istilah, Penjelasan 1 Kalimat, SurahContoh, AyatContoh}
    public static final String[][] TAJWID_DICTIONARY = {
            {"Qalqalah Kubra", "Pantulan kuat pada huruf Qaf, Tha, Ba, Jim, Dal yang dimatikan di akhir ayat.", "113", "1"},
            {"Idgham Bighunnah", "Meleburkan Nun mati atau tanwin ke huruf Ya, Nun, Mim, Wau disertai dengung 2 harakat.", "111", "1"},
            {"Idgham Bilaghunnah", "Meleburkan Nun mati atau tanwin ke huruf Lam atau Ra tanpa dengung.", "112", "4"},
            {"Ikhfa Haqiqi", "Membaca Nun mati atau tanwin samar-samar dengan dengung saat bertemu 15 huruf ikhfa.", "114", "4"},
            {"Izhar Halqi", "Membaca Nun mati atau tanwin jelas tanpa dengung saat bertemu huruf tenggorokan.", "108", "2"},
            {"Ghunnah Musyaddadah", "Dengung jelas selama 2 harakat pada huruf Mim bertasydid atau Nun bertasydid.", "114", "1"},
            {"Mad Wajib Muttashil", "Bacaan panjang 4 sampai 5 harakat karena Mad bertemu Hamzah dalam satu kata.", "110", "1"},
            {"Mad Jaiz Munfashil", "Bacaan panjang 2, 4, atau 5 harakat karena Mad bertemu Hamzah di kata berbeda.", "109", "1"},
            {"Saktah", "Berhenti sejenak sekitar 2 harakat tanpa mengambil napas baru lalu melanjutkan bacaan.", "18", "1"},
            {"Iqlab", "Mengubah bunyi Nun mati atau tanwin menjadi bunyi Mim berdengung saat bertemu huruf Ba.", "104", "4"}
    };

    // Aula Muhadharah (Tema Kultum 3 Menit)
    public static final String[][] KULTUM_THEMES = {
            {"Keutamaan Penghafal Al-Qur'an", "Pembuka: Puji syukur & shalawat. Isi: Penghafal Al-Qur'an adalah keluarga Allah dan akan memakaikan mahkota cahaya untuk kedua orang tuanya. Dalil: Sebaik-baik kalian adalah yang belajar dan mengajarkan Al-Qur'an. Penutup: Ajak istiqamah 1 ayat setiap hari."},
            {"Berbakti kepada Orang Tua", "Pembuka: Salam & syukur. Isi: Ridha Allah ada pada ridha orang tua, terlebih lewat doa dan hafalan Al-Qur'an anak-anaknya. Penutup: Ajak mendoakan orang tua di Majelis Malam Jumat."},
            {"Menjaga Lisan & Akhlak Santri", "Pembuka: Hamdalah. Isi: Lisan yang setiap hari membaca Al-Qur'an hendaknya juga berkata lembut, jujur, dan membawa ketenangan. Penutup: Doa agar lisan selalu terjaga."},
            {"Sabar & Istiqamah Menghadapi Ujian", "Pembuka: Salam hangat. Isi: Amal yang paling dicintai Allah adalah yang terus-menerus walaupun sedikit. Jangan menyerah saat ayat terasa sulit. Penutup: Semangat terus menghafal!"}
    };

    // Dapur Umum — Gizi Iman 30 Detik
    public static final String[] GIZI_IMAN_TIPS = {
            "Doa sebelum makan: Allahumma barik lana fima razaqtana wa qina adzabannar. Makanlah dengan tangan kanan dan mulai dari yang terdekat.",
            "Hadits singkat: Sebaik-baik kalian adalah yang mempelajari Al-Qur'an dan mengajarkannya. (HR. Bukhari)",
            "Adab santri: Tersenyum kepada sesama dan mendoakan teman tanpa sepengetahuannya adalah sedekah yang sangat ringan.",
            "Hadits singkat: Amalan yang paling dicintai Allah adalah yang rutin dilakukan walaupun sedikit. (HR. Bukhari & Muslim)",
            "Adab minum: Minumlah sambil duduk dengan tiga tegukan pelan sambil membaca Bismillah dan ditutup Alhamdulillah."
    };

    // 6 Surat Pendek Wirid Sore 17.00 (Al-Kafirun 109 -> An-Nas 114)
    public static final int[] WIRID_SORE_SURAHS = {109, 110, 111, 112, 113, 114};


    // ================= v3.0 PONDOK RESMI HIDUP CONSTANTS =================
    public static final String INSTITUTION_NAME = "MADRASAH HAFIDZ NETRA";
    public static final String INSTITUTION_SUB = "Lembaga Tahfidz & Diniyah Audio-First — Suara Media Teknologi";
    public static final String ACADEMIC_YEAR = "Tahun Ajaran 2026/2027 — Semester Ganjil";
    public static final String COHORT_NAME = "Angkatan I (2026)";
    public static final String HEADMASTER_NAME = "Ustadz Yeni Setiawan";
    public static final String WALI_TU_NAME = "Ustadzah Nur";

    public static final String KEY_PONDOK_CUSTOM_NAME = "pondok_custom_name_v3";
    public static final String KEY_TEACHER_STYLE = "teacher_style_v3";
    public static final String KEY_TAARUF_DONE = "taaruf_done_v3";
    public static final String KEY_FIRST_JOIN_EPOCH = "first_join_epoch_v3";
    public static final String KEY_MUTABAAH_JSON = "mutabaah_yaumiyah_v3";
    public static final String KEY_GOLDEN_HOUR_JSON = "golden_hour_stats_v3";
    public static final String KEY_ERROR_PATTERN_JSON = "error_pattern_stats_v3";
    public static final String KEY_CLOSENESS_POINTS = "closeness_points_v3";
    public static final String KEY_LAST_ACTIVITY_EPOCH = "last_activity_epoch_v3";
    public static final String KEY_BG_ALERTS_ENABLED = "bg_alerts_enabled_v3";

    public static final String FORMAL_TATA_TERTIB_PASAL =
            "TATA TERTIB RESMI MADRASAH HAFIDZ NETRA\n" +
            "Tahun Ajaran 2026/2027 — Suara Media Teknologi\n\n" +
            "Pasal 1 (Kehadiran): Santri mengikuti jam kelas pilihan (toleransi 15 menit) atau Kelas Susulan pada hari yang sama.\n" +
            "Pasal 2 (Adab Belajar): Memulai dengan doa belajar, menyimak Qari dengan tenang, dan menjaga kejujuran saat uji hafalan.\n" +
            "Pasal 3 (Izin & Cuti): Santri berhalangan wajib menerbitkan Surat Izin/Sakit/Cuti bernomor seri melalui Kantor TU atau UKS agar bebas SP.\n" +
            "Pasal 4 (Sanksi & Pembinaan): Alfa 1 hari SP-1, 2 hari SP-2 + Ta'zir Murajaah, 3 hari Skorsing Sementara yang dapat dipulihkan lewat Meja Banding TU atau Sidang Pemulihan. Hari Ahad & Tanggal Merah otomatis libur.";

    public static final String[] SURAT_EDARAN_RESMI = {
            "SE-01/MHN/2026: Pembukaan Resmi Tahun Ajaran 2026/2027 Angkatan I. Seluruh santri baru mengikuti Masa Ta'aruf Hari ke-1.",
            "SE-02/MHN/2026: Program Wirid Sore & 6 Surat Pendek berjalan otomatis setiap pukul 17.00 WIB menjelang Maghrib.",
            "SE-03/MHN/2026: Hari Ahad (Minggu) dan Tanggal Merah adalah hari libur kelas wajib (bebas SP), diisi Sambangan Keluarga & Kelas Sore santai.",
            "SE-04/MHN/2026: Seluruh dokumen resmi (KTS, SK PSB, Surat Izin, Transkrip Rapor, Syahadah) kini dapat dicetak menjadi Foto PNG ber-kop resmi maupun Teks."
    };

    public static final String[] DAILY_LIVING_EVENTS = {
            "Panggilan Corong Ustadz Yeni: Hari ini ada tantangan Setor Kilat 1 Ayat Berhadiah +30 Poin Berkah!",
            "Inspeksi Ramah Ustadzah Nur: Yuk periksa Buku Mutaba'ah Yaumiyah dan rapikan 1 ayat yang masih kuning.",
            "Kajian Tamu 1 Menit: Kisah ulama & penghafal Al-Qur'an tunanetra dunia yang hafalannya tajam bagai batu karang.",
            "Ajakan Teman Sekamar: Assalamu'alaikum! Teman sekamarmu mengajak setor bareng 2 ayat sebelum kelas dimulai."
    };

    public static final String[] ROOMMATE_MESSAGES = {
            "Salma (Teman Sekamar): Assalamu'alaikum! Aku baru selesai murajaah Al-Falaq nih, yuk setor bareng 1 ayat biar makin semangat!",
            "Fulan (Teman Sekelas): Halo! Tadi aku sempat agak lupa di ayat 4, tapi pakai metode Audio Buka-Tutup langsung nempel lagi!",
            "Kak Bilal (Ketua Kamar): Semangat teman-teman sekamar! Sedikit lagi target ayat kamar pekan ini tercapai!"
    };


    // ================= v4.0 SANTRI DIGITAL — PONDOK HAFIDZ NETRA CONSTANTS =================
    public static final String APP_BRAND_V4 = "Santri Digital — Pondok Hafidz Netra";
    public static final String OFFICIAL_PATENT_BRAND = "Suara Media Teknologi";

    public static final String KEY_GENDER = "v4_gender"; // 0=Putra, 1=Putri
    public static final String KEY_RESIDENCE = "v4_residence"; // 0=Mukim Asrama, 1=Santri Kalong (Rumah)
    public static final String KEY_TRANSPORT = "v4_transport"; // 0=Jalan Kaki, 1=Sepeda, 2=Antar-Jemput
    public static final String KEY_PROVINCE = "v4_province";
    public static final String KEY_JENJANG = "v4_jenjang"; // 0..4 (TPQ -> Ma'had Aly)
    public static final String KEY_JALUR = "v4_jalur"; // 0..4
    public static final String KEY_BIRTHDATE_MMDD = "v4_birthdate_mmdd";
    public static final String KEY_BIRTHYEAR = "v53_birthyear";
    public static final String KEY_TARGET_HARIAN = "v4_target_harian"; // 3, 5, 10, 15
    public static final String KEY_KAS_WAKAF = "v4_kas_wakaf";
    public static final String KEY_LAST_PANEN_EPOCH = "v4_last_panen_epoch";
    public static final String KEY_STAMINA = "v4_stamina";
    public static final String KEY_CURRENT_LOCATION = "v4_current_location";
    public static final String KEY_AUTO_MORNING_DOA = "v4_auto_morning_doa";
    public static final String KEY_LAST_MORNING_DOA_DATE = "v4_last_morning_doa_date";
    public static final String KEY_PANTRY_ITEMS = "v4_pantry_items";
    public static final String KEY_GARDEN_STAGE = "v4_garden_stage";
    public static final String KEY_POND_STAGE = "v4_pond_stage";
    public static final String KEY_BUILDINGS_LEVELS = "v4_buildings_levels";
    public static final String KEY_TOMORROW_RETRY_QUEUE = "v4_tomorrow_retry_queue";
    public static final String KEY_LAST_ULTAH_YEAR = "v4_last_ultah_year";
    public static final String KEY_MAHAD_SKS = "v4_mahad_sks";
    public static final String KEY_DAY1_ADAPTATION_DONE = "v4_day1_adaptation_done";
    public static final String KEY_TOTAL_INFAQ = "v4_total_infaq";
    public static final String KEY_COOKED_COUNT = "v4_cooked_count";

    public static final long INITIAL_KAS_WAKAF = 4000000000L; // Rp 4 Miliar (Simulasi 100% Gratis)
    public static final long PANEN_PASIF_AMOUNT = 500000000L; // Rp 500 Juta (Lima Ratus Juta)

    public static final String[] PROVINCES_LIST = {
            "Jawa Timur", "Jawa Tengah", "Jawa Barat", "DKI Jakarta", "DI Yogyakarta", "Banten",
            "Aceh", "Sumatera Utara", "Sumatera Barat", "Riau", "Kepulauan Riau", "Jambi",
            "Sumatera Selatan", "Kepulauan Bangka Belitung", "Bengkulu", "Lampung",
            "Bali", "Nusa Tenggara Barat", "Nusa Tenggara Timur",
            "Kalimantan Barat", "Kalimantan Tengah", "Kalimantan Selatan", "Kalimantan Timur", "Kalimantan Utara",
            "Sulawesi Utara", "Gorontalo", "Sulawesi Tengah", "Sulawesi Barat", "Sulawesi Selatan", "Sulawesi Tenggara",
            "Maluku", "Maluku Utara",
            "Papua", "Papua Barat", "Papua Selatan", "Papua Tengah", "Papua Pegunungan", "Papua Barat Daya",
            "Mancanegara (Luar Negeri)"
    };

    public static final String[] JENJANG_LABELS = {
            "TPQ / Ula (Dasar Pemula — setara SD/MI)",
            "Wustha (Menengah Pertama — setara SMP/MTs)",
            "Ulya (Menengah Atas — setara SMA/MA)",
            "Ma'had Aly S1 — Ilmu Al-Qur'an & Tafsir (Kuliah Pesantren)",
            "Ma'had Aly S1 — Tahfidz & Qira'at (Kuliah Pesantren)"
    };

    public static final String[] JALUR_LABELS = {
            "Jalur Pemula (I'dad — mulai dari makhraj & surat pendek)",
            "Jalur Reguler Tahfidz (Juz 30 + 6 Surat Pilihan)",
            "Jalur Takhassus 30 Juz (Intensif Target Cepat)",
            "Jalur Santri Pindahan / Lanjutan (Melanjutkan Hafalan)",
            "Jalur Santri Karyawan / Mahasiswa (Fleksibel Subuh & Malam)"
    };

    public static final String[] TRANSPORT_LABELS = {
            "Jalan Kaki dari Rumah Santri",
            "Bersepeda Pagi ke Gerbang Selatan",
            "Antar-Jemput Mobil Pondok"
    };

    public static final String[] PUTRA_ROOMS = {
            "Asrama Putra — Kamar Abu Bakar Ash-Shiddiq",
            "Asrama Putra — Kamar Umar bin Khattab",
            "Asrama Putra — Kamar Utsman bin Affan"
    };

    public static final String[] PUTRI_ROOMS = {
            "Asrama Putri — Kamar Khadijah Al-Kubra",
            "Asrama Putri — Kamar Aisyah binti Abu Bakar",
            "Asrama Putri — Kamar Fatimah Az-Zahra"
    };

    // 6 Surat Pilihan Luar Kelas (Otomatis ke Ruang Pembimbing Khusus di 3 & 10 ayat 100% Hijau)
    public static final int[] SIX_SELECTED_SURAHS = {18, 36, 55, 56, 67, 32};
    public static final String[] SIX_SELECTED_NAMES = {
            "Al-Kahfi (18)", "Yasin (36)", "Ar-Rahman (55)",
            "Al-Waqiah (56)", "Al-Mulk (67)", "As-Sajdah (32)"
    };

    // 20 Metode Belajar Berjenjang (4 Tangga Kemahiran)
    public static final String[] METHOD_LABELS_V4 = {
            "[Tangga 1] 1. Talaqqi Per Ayat (Dengar & Tiru)",
            "[Tangga 1] 2. Talaqqi Per Kata (Word-by-Word)",
            "[Tangga 1] 3. Talaqqi Penggalan Napas (Waqaf/Ibtida)",
            "[Tangga 1] 4. Talaqqi Lambat 0,75x & Makhraj",
            "[Tangga 1] 5. Tikrar Intensif (5x-10x Berirama)",
            "[Tangga 2] 6. Tikrar Berantai (Ayat 1 -> 1-2 -> 1-2-3)",
            "[Tangga 2] 7. Blok 3 Ayat Mantap",
            "[Tangga 2] 8. Metode Gema / Shadowing 3 Tahap",
            "[Tangga 2] 9. Tautan Engsel (Akhir Ayat -> Awal Berikutnya)",
            "[Tangga 2] 10. Rantai Mundur (Akhir -> Awal)",
            "[Tangga 3] 11. Sabak - Sabqi - Manzil (Ala Pondok Asli)",
            "[Tangga 3] 12. Audio Buka-Tutup (Tes Lisan Mandiri)",
            "[Tangga 3] 13. Estafet Gantian Guru & Santri",
            "[Tangga 3] 14. Pelatih Tempo Bertingkat (0,75x -> 1,0x)",
            "[Tangga 3] 15. Penyelamat Lupa Total (Rescue Drill)",
            "[Tangga 3] 16. Dengar Santai Hands-Free (Murajaah)",
            "[Tangga 4] 17. Tasmi' 1 Surat Utuh Tanpa Putus",
            "[Tangga 4] 18. Deteksi Ayat Mutasyabihat (Anti-Tertukar)",
            "[Tangga 4] 19. Pengenalan Irama Maqamat Dasar",
            "[Tangga 4] 20. Tadabbur Makna & Asbabun Nuzul"
    };

    // Perpustakaan Audio & Kitab Kuning
    public static final String[][] PERPUS_AUDIO_ITEMS = {
            {"Ta'lim Muta'allim (Adab Menuntut Ilmu)", "Niatkan belajar ikhlas karena Allah, hormati guru, jaga wudhu sebelum membuka Al-Qur'an, dan ulangi hafalan di waktu subuh serta menjelang tidur."},
            {"Tajwid Praktis: Hukum Nun Mati & Tanwin", "Idzhar dibaca jelas tanpa dengung (6 huruf tenggorokan). Idgham Bighunnah masuk berdengung (ya, nun, mim, wawu). Iqlab berubah bunyi mim samar saat bertemu ba. Ikhfa dibaca samar 2 harakat."},
            {"Fikih Wudhu & Thaharah Lengkap", "Rukun wudhu ada 6: Niat dalam hati, membasuh wajah, membasuh kedua tangan hingga siku, mengusap sebagian kepala, membasuh kedua kaki hingga mata kaki, dan tertib berurutan."},
            {"Hadits Arbain #1: Niat & Keikhlasan", "Innamal a'malu binniyyat. Sesungguhnya setiap amalan tergantung pada niatnya, dan setiap orang mendapat sesuai apa yang ia niatkan. (HR. Bukhari & Muslim)."},
            {"Sirah Nabawiyah: Keteguhan Abdullah bin Ummi Maktum", "Sahabat mulia tunanetra yang menjadi muadzin resmi Masjid Nabawi dan dipercaya Rasulullah memimpin Kota Madinah berkali-kali. Bukti bahwa keterbatasan penglihatan tidak membatasi kemuliaan."}
    };

    // Lab Tajwid & Klinik Makhraj + Napas Panjang
    public static final String[][] LAB_MAKHRAJ_DRILLS = {
            {"Klinik Huruf Tenggorokan (Ha kecil vs Kha vs Ha besar)", "Tarik napas pelan 4 detik. Ucapkan Ha kecil bersih dari tengah tenggorokan (Al-Hamdu), Kha sedikit bergetar di atas tenggorokan (Khaaliq), dan Ha besar lega dari pangkal dada (Ihdina)."},
            {"Klinik Desis Lidah (Sin vs Syin vs Shad)", "Sin tipis dengan ujung lidah menyentuh gigi bawah (Bismi). Syin menyebar lembut di tengah lidah (Syamsi). Shad tebal dengan pangkal lidah terangkat (Shiraathal)."},
            {"Klinik Huruf Ujung Lidah (Dzal vs Zay vs Zha)", "Dzal keluarkan sedikit ujung lidah lembut (Alladzina). Zay bergetar tajam di balik gigi (Zalzalah). Zha tebal dengan ujung lidah sedikit keluar (Az-Zhalimin)."},
            {"Klinik Napas Panjang & Waqaf Sempurna", "Latihan pernapasan diafragma: Tarik napas lewat hidung 4 hitungan, tahan tenang 2 hitungan, hembuskan pelan sambil membaca satu ayat panjang tanpa tergesa."}
    };

    // Balai Musyawarah / Bahtsul Masail
    public static final String[][] BAHTSUL_MASAIL_TOPICS = {
            {"Bolehkah murajaah Al-Qur'an tanpa wudhu bagi santri tunanetra?", "Boleh dan berpahala! Membaca Al-Qur'an lewat hafalan atau menyimak audio tidak wajib berwudhu. Wudhu hanya wajib ketika menyentuh mushaf fisik. Namun berwudhu sebelum belajar tetap sangat utama."},
            {"Bagaimana jika lupa satu kata di tengah shalat?", "Jika lupa di surat selain Al-Fatihah, boleh melompat ke ayat berikutnya atau langsung ruku'. Jika lupa di Al-Fatihah, wajib diingat atau diulang ayatnya agar rukun shalat tetap sah."},
            {"Kapan waktu terbaik menghafal agar paling lengket?", "Para ulama tahfidz sepakat waktu emas adalah ba'da Subuh saat pikiran masih jernih dan ba'da Maghrib/sebelum tidur untuk mengunci memori jangka panjang."}
    };

    // Mata Kuliah Ma'had Aly (Kuliah Pesantren)
    public static final String[][] MAHAD_ALY_COURSES = {
            {"MA-101: Ulumul Qur'an & Sejarah Mushaf (3 SKS)", "Dosen Ustadz Yeni Setiawan: Membahas turunnya wahyu (Nuzulul Qur'an), pengumpulan mushaf di masa Abu Bakar dan Utsman, serta sanad qira'at mutawatir."},
            {"MA-102: Metodologi Tahfidz & Psikologi Memori Audio (3 SKS)", "Dosen Ustadzah Nur: Teknik mengikat hafalan lewat pemetaan bunyi, ritme napas, dan pencegahan lupa jangka panjang berbasis pengulangan terjadwal."},
            {"MA-103: Tafsir Ayat-Ayat Pilihan & Tadabbur (3 SKS)", "Dosen Ustadz Yeni Setiawan: Memahami pesan surat Al-Kahfi, Yasin, Ar-Rahman, Al-Waqiah, Al-Mulk, dan As-Sajdah dalam kehidupan sehari-hari."},
            {"MA-104: Qira'at Sab'ah & Irama Maqamat Dasar (3 SKS)", "Dosen Tamu / Ustadz Yeni: Pengenalan perbedaan bacaan yang sahih serta keindahan nada Bayati, Nahawand, Rast, dan Hijaz."}
    };

    // Lokasi Kampus + Arah Kompas 4 Penjuru dari Gerbang Selatan
    // Format: {id, nama, arah, zona, deskripsiSingkat}
    public static final String[][] CAMPUS_LOCATIONS = {
            {"gerbang", "Gerbang Selatan & Pos Kang Ridho", "Titik Pusat (Selatan)", "Pintu Masuk Utama", "Pos keamanan Kang Ridho, titik awal arah Utara, Timur, Barat, dan keluar ke Selatan."},
            {"masjid", "Masjid Agung & Menara Adzan", "Utara — Lurus dari Gerbang", "Zona Ibadah (Utara)", "Shalat berjamaah, Doa Pagi Otomatis, Wirid Sore 17.00, dan Majelis Malam Jumat."},
            {"kelas", "Gedung Kelas Utama Tahfidz", "Utara — Sebelah Masjid", "Zona Belajar (Utara)", "Ruang kelas 9 jadwal nyata, 20 metode bertingkat, dan Lab Tajwid. Tutup 21.00-04.30."},
            {"kampus", "Kampus Ma'had Aly & Aula Munaqasyah", "Utara — Ujung Lorong Ilmu", "Zona Kuliah & Ujian (Utara)", "Perkuliahan S1 Pesantren, SKS, Sidang Tasmi', dan cetak Syahadah/KTM PNG."},
            {"tu", "Kantor TU, PSB & Papan Edaran", "Timur — Kanan Gerbang", "Zona Layanan (Timur)", "Ustadzah Nur, cetak KTS/SK/Surat Izin PNG, Verifikasi NIS, dan Naik Jenjang."},
            {"ekonomi", "Koperasi Berkah, Warung & Toko Kitab", "Timur — Deretan Niaga", "Zona Ekonomi (Timur)", "Kas Wakaf Rp 4 Miliar, Panen Pasif Rp 500 Juta, Bangun/Upgrade Gedung, Infaq Beasiswa."},
            {"perpus", "Perpustakaan Audio & Balai Musyawarah", "Timur — Belakang Kantor TU", "Zona Pustaka (Timur)", "Kitab Kuning Audio, Lab Makhraj, Bahtsul Masail, Studio Rekaman, dan Mading Suara."},
            {"asrama", "Asrama Putra/Putri (Buka 24 Jam)", "Barat — Kiri Gerbang", "Zona Hunian (Barat)", "Kamar Putra/Putri terpisah, Meja Belajar 24 Jam, Teman Sekamar, dan Istirahat."},
            {"dapur", "Dapur Umum (187.500+ Menu Nyata)", "Barat — Dekat Asrama", "Zona Konsumsi (Barat)", "Generator 187.500+ resep kombinasi nusantara, masak bertahap, dan pulihkan Stamina 100%."},
            {"kebun", "Kebun Organik, Tambak Ikan & UKS Herbal", "Barat — Halaman Hijau", "Zona Agribisnis & Sehat (Barat)", "Tanam-Siram-Panen Kebun & Tambak, serta Klinik UKS + Herbal Sunnah."},
            {"rumah", "Rumah Santri (Meja Belajar 24 Jam)", "Selatan — Luar Gerbang", "Zona Luar Pondok (Selatan)", "Rumah tinggal Santri Kalong. Tetap buka 24 jam penuh saat kelas malam terkunci."},
            {"pasar", "Pasar Pondok & Rihlah Ahad", "Selatan — Seberang Jalan", "Zona Pasar (Selatan)", "Belanja bahan masak nyata untuk Dapur Umum serta titik berangkat Rihlah/Ziarah Ahad."}
    };

    // 187.500+ Menu Dapur Kombinatorial (50 Bahan x 25 Gaya x 15 Lauk/Sambal x 10 Minuman = 187.500)
    public static final String[] KITCHEN_MAINS = {
            "Ayam Kampung", "Ikan Gurame", "Ikan Lele", "Ikan Tongkol", "Ikan Bandeng",
            "Ikan Nila", "Ikan Patin", "Daging Sapi", "Daging Kambing", "Telur Ayam",
            "Telur Bebek", "Tempe Kedelai", "Tahu Putih", "Tahu Sutera", "Udang Segar",
            "Cumi Segar", "Kacang Hijau", "Kacang Merah", "Bayam Kebun", "Kangkung Segar",
            "Daun Singkong", "Nangka Muda", "Labu Siam", "Terong Ungu", "Buncis Organik",
            "Wortel Manis", "Kentang Dieng", "Jamur Tiram", "Jamur Kuping", "Sawi Hijau",
            "Kol Segar", "Brokoli Hijau", "Kembang Kol", "Jagung Manis", "Singkong Empuk",
            "Ubi Ungu", "Pisang Kepok", "Nasi Beras Pandan", "Nasi Merah Organik", "Bihun Jagung",
            "Mie Telur", "Kwetiau", "Soun", "Oatmeal Kurma", "Roti Gandum",
            "Kacang Panjang", "Pare Segar", "Tauge Pendek", "Oyong Segar", "Daun Kelor"
    };
    public static final String[] KITCHEN_STYLES = {
            "Goreng Lengkuas", "Bakar Madu", "Kuah Soto Lamongan", "Kuah Rawon Hitam", "Gulai Santan Rempah",
            "Rendang Padang", "Semur Kecap Manis", "Balado Cabai Merah", "Rica-Rica Kemangi", "Woku Daun Jeruk",
            "Pepes Daun Pisang", "Mangut Asap", "Pindang Kuning", "Asam Manis Nanas", "Lada Hitam Hangat",
            "Saus Tiram Bawang", "Tumis Bawang Putih", "Sayur Asem Segar", "Sayur Lodeh Gurih", "Sayur Bening Kunci",
            "Opor Putih Lebaran", "Kari Rempah Arab", "Nasi Kebuli Kapulaga", "Nasi Briyani Safron", "Tim Jahe Sehat"
    };
    public static final String[] KITCHEN_SIDES = {
            "Sambal Terasi Matang", "Sambal Bawang Geprek", "Sambal Matah Bali", "Sambal Hijau Padang", "Sambal Kacang Pecel",
            "Lalapan Kemangi & Timun", "Kerupuk Udang Renyah", "Emping Melinjo", "Perkedel Kentang", "Bakwan Jagung",
            "Tempe Mendoan Hangat", "Tahu Isi Sayur", "Acar Kuning Segar", "Bawang Goreng Renyah", "Serundeng Kelapa Gurih"
    };
    public static final String[] KITCHEN_DRINKS = {
            "Teh Hangat Madu", "Jahe Merah Serai", "Air Kelapa Muda", "Jus Kurma Susu", "Wedang Uwuh Jogja",
            "Sari Kacang Hijau", "Jeruk Peras Hangat", "Kunyit Asam Segar", "Air Putih Hangat Sunnah", "Susu Almond Kurma"
    };

    public static final String[][] MARKET_GOODS = {
            {"Beras Pandan Wangi 25 Kg", "350000"},
            {"Ayam Kampung & Ikan Segar", "280000"},
            {"Paket Sayur & Bumbu Rempah", "150000"},
            {"Madu Hutan & Kurma Ajwa", "420000"},
            {"Bibit Sayur & Pakan Ikan Tambak", "200000"},
            {"Kitab Tajwid & Audio Braille", "300000"}
    };

    public static final String[][] BUILDING_UPGRADES = {
            {"masjid", "Masjid Agung & Menara Adzan", "250000000"},
            {"kelas", "Gedung Kelas Utama & Lab Tajwid", "200000000"},
            {"kampus", "Kampus Ma'had Aly & Aula Sidang", "300000000"},
            {"asrama", "Gedung Asrama Putra & Putri", "220000000"},
            {"dapur", "Dapur Umum Modern & Ruang Makan", "150000000"},
            {"warung", "Warung Santri & Koperasi Berkah", "120000000"},
            {"toko_kitab", "Toko Kitab & Perpustakaan Audio", "140000000"},
            {"kebun", "Kebun Organik & Tambak Ikan", "180000000"}
    };


    // Daftar Lengkap Kabupaten/Kota Nyata per Provinsi (Selaras 1-ke-1 dengan PROVINCES_LIST)
    public static final String[][] CITIES_BY_PROVINCE = {
            // 0. Jawa Timur (38 Kab/Kota lengkap)
            {"Kab. Situbondo", "Kab. Bondowoso", "Kab. Banyuwangi", "Kab. Jember", "Kab. Lumajang",
             "Kab. Probolinggo", "Kota Probolinggo", "Kab. Pasuruan", "Kota Pasuruan", "Kab. Sidoarjo",
             "Kota Surabaya", "Kab. Gresik", "Kab. Lamongan", "Kab. Tuban", "Kab. Bojonegoro",
             "Kab. Mojokerto", "Kota Mojokerto", "Kab. Jombang", "Kab. Nganjuk", "Kab. Kediri",
             "Kota Kediri", "Kab. Blitar", "Kota Blitar", "Kab. Tulungagung", "Kab. Trenggalek",
             "Kab. Ponorogo", "Kab. Pacitan", "Kab. Magetan", "Kab. Ngawi", "Kab. Madiun",
             "Kota Madiun", "Kab. Malang", "Kota Malang", "Kota Batu", "Kab. Bangkalan",
             "Kab. Sampang", "Kab. Pamekasan", "Kab. Sumenep"},
            // 1. Jawa Tengah (35 Kab/Kota lengkap)
            {"Kota Semarang", "Kab. Semarang", "Kota Surakarta (Solo)", "Kab. Kudus", "Kab. Demak",
             "Kab. Jepara", "Kab. Pati", "Kab. Rembang", "Kab. Blora", "Kab. Grobogan",
             "Kab. Kendal", "Kab. Batang", "Kota Pekalongan", "Kab. Pekalongan", "Kab. Pemalang",
             "Kota Tegal", "Kab. Tegal", "Kab. Brebes", "Kab. Cilacap", "Kab. Banyumas (Purwokerto)",
             "Kab. Purbalingga", "Kab. Banjarnegara", "Kab. Kebumen", "Kab. Purworejo", "Kab. Wonosobo",
             "Kota Magelang", "Kab. Magelang", "Kab. Temanggung", "Kab. Boyolali", "Kab. Klaten",
             "Kab. Sukoharjo", "Kab. Wonogiri", "Kab. Karanganyar", "Kab. Sragen", "Kota Salatiga"},
            // 2. Jawa Barat (27 Kab/Kota lengkap)
            {"Kota Bandung", "Kab. Bandung", "Kab. Bandung Barat", "Kota Cimahi", "Kota Bogor",
             "Kab. Bogor", "Kota Depok", "Kota Bekasi", "Kab. Bekasi", "Kab. Karawang",
             "Kab. Purwakarta", "Kab. Subang", "Kab. Indramayu", "Kota Cirebon", "Kab. Cirebon",
             "Kab. Majalengka", "Kab. Kuningan", "Kab. Sumedang", "Kab. Garut", "Kota Tasikmalaya",
             "Kab. Tasikmalaya", "Kab. Ciamis", "Kota Banjar", "Kab. Pangandaran", "Kota Sukabumi",
             "Kab. Sukabumi", "Kab. Cianjur"},
            // 3. DKI Jakarta (6 Wilayah lengkap)
            {"Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Barat", "Jakarta Utara", "Kepulauan Seribu"},
            // 4. DI Yogyakarta (5 Kab/Kota lengkap)
            {"Kota Yogyakarta", "Kab. Sleman", "Kab. Bantul", "Kab. Kulon Progo", "Kab. Gunungkidul"},
            // 5. Banten (8 Kab/Kota lengkap)
            {"Kota Serang", "Kab. Serang", "Kota Cilegon", "Kota Tangerang", "Kab. Tangerang",
             "Kota Tangerang Selatan", "Kab. Pandeglang", "Kab. Lebak"},
            // 6. Aceh
            {"Kota Banda Aceh", "Kota Lhokseumawe", "Kota Langsa", "Kota Sabang", "Kab. Aceh Besar", "Kab. Pidie", "Kab. Bireuen", "Kab. Aceh Utara", "Kab. Aceh Barat"},
            // 7. Sumatera Utara
            {"Kota Medan", "Kota Binjai", "Kota Tebing Tinggi", "Kota Pematangsiantar", "Kota Padangsidimpuan", "Kab. Deli Serdang", "Kab. Langkat", "Kab. Asahan", "Kab. Mandailing Natal"},
            // 8. Sumatera Barat
            {"Kota Padang", "Kota Bukittinggi", "Kota Payakumbuh", "Kota Pariaman", "Kota Solok", "Kab. Agam", "Kab. Tanah Datar", "Kab. Lima Puluh Kota", "Kab. Pesisir Selatan"},
            // 9. Riau
            {"Kota Pekanbaru", "Kota Dumai", "Kab. Kampar", "Kab. Siak", "Kab. Bengkalis", "Kab. Indragiri Hilir", "Kab. Rokan Hulu"},
            // 10. Kepulauan Riau
            {"Kota Batam", "Kota Tanjungpinang", "Kab. Bintan", "Kab. Karimun", "Kab. Natuna"},
            // 11. Jambi
            {"Kota Jambi", "Kota Sungai Penuh", "Kab. Muaro Jambi", "Kab. Batanghari", "Kab. Bungo", "Kab. Kerinci"},
            // 12. Sumatera Selatan
            {"Kota Palembang", "Kota Lubuklinggau", "Kota Prabumulih", "Kota Pagar Alam", "Kab. Banyuasin", "Kab. Ogan Ilir", "Kab. Muara Enim"},
            // 13. Bangka Belitung
            {"Kota Pangkalpinang", "Kab. Bangka", "Kab. Bangka Tengah", "Kab. Belitung", "Kab. Belitung Timur"},
            // 14. Bengkulu
            {"Kota Bengkulu", "Kab. Rejang Lebong", "Kab. Bengkulu Utara", "Kab. Mukomuko", "Kab. Seluma"},
            // 15. Lampung
            {"Kota Bandar Lampung", "Kota Metro", "Kab. Lampung Selatan", "Kab. Lampung Tengah", "Kab. Lampung Timur", "Kab. Pringsewu", "Kab. Pesawaran"},
            // 16. Bali
            {"Kota Denpasar", "Kab. Badung", "Kab. Gianyar", "Kab. Tabanan", "Kab. Buleleng", "Kab. Jembrana", "Kab. Karangasem", "Kab. Klungkung", "Kab. Bangli"},
            // 17. NTB
            {"Kota Mataram", "Kota Bima", "Kab. Lombok Barat", "Kab. Lombok Tengah", "Kab. Lombok Timur", "Kab. Lombok Utara", "Kab. Sumbawa", "Kab. Dompu"},
            // 18. NTT
            {"Kota Kupang", "Kab. Kupang", "Kab. Ende", "Kab. Sikka", "Kab. Manggarai", "Kab. Flores Timur", "Kab. Sumba Timur"},
            // 19. Kalimantan Barat
            {"Kota Pontianak", "Kota Singkawang", "Kab. Kubu Raya", "Kab. Mempawah", "Kab. Sambas", "Kab. Ketapang", "Kab. Sintang"},
            // 20. Kalimantan Tengah
            {"Kota Palangkaraya", "Kab. Kotawaringin Timur", "Kab. Kotawaringin Barat", "Kab. Kapuas", "Kab. Barito Utara"},
            // 21. Kalimantan Selatan
            {"Kota Banjarmasin", "Kota Banjarbaru", "Kab. Banjar (Martapura)", "Kab. Tanah Laut", "Kab. Hulu Sungai Selatan", "Kab. Tabalong"},
            // 22. Kalimantan Timur
            {"Kota Samarinda", "Kota Balikpapan", "Kota Bontang", "Kab. Kutai Kartanegara", "Kab. Paser", "Kab. Berau"},
            // 23. Kalimantan Utara
            {"Kota Tarakan", "Kab. Bulungan (Tanjung Selor)", "Kab. Nunukan", "Kab. Malinau"},
            // 24. Sulawesi Utara
            {"Kota Manado", "Kota Bitung", "Kota Tomohon", "Kota Kotamobagu", "Kab. Minahasa", "Kab. Bolaang Mongondow"},
            // 25. Gorontalo
            {"Kota Gorontalo", "Kab. Gorontalo", "Kab. Bone Bolango", "Kab. Boalemo", "Kab. Pohuwato"},
            // 26. Sulawesi Tengah
            {"Kota Palu", "Kab. Donggala", "Kab. Sigi", "Kab. Poso", "Kab. Parigi Moutong", "Kab. Banggai"},
            // 27. Sulawesi Barat
            {"Kab. Mamuju", "Kab. Polewali Mandar", "Kab. Majene", "Kab. Mamasa", "Kab. Pasangkayu"},
            // 28. Sulawesi Selatan
            {"Kota Makassar", "Kota Parepare", "Kota Palopo", "Kab. Gowa", "Kab. Maros", "Kab. Bone", "Kab. Bulukumba", "Kab. Wajo", "Kab. Pinrang"},
            // 29. Sulawesi Tenggara
            {"Kota Kendari", "Kota Baubau", "Kab. Konawe", "Kab. Kolaka", "Kab. Muna", "Kab. Buton"},
            // 30. Maluku
            {"Kota Ambon", "Kota Tual", "Kab. Maluku Tengah", "Kab. Seram Bagian Barat", "Kab. Buru"},
            // 31. Maluku Utara
            {"Kota Ternate", "Kota Tidore Kepulauan", "Kab. Halmahera Utara", "Kab. Halmahera Selatan"},
            // 32. Papua
            {"Kota Jayapura", "Kab. Jayapura", "Kab. Biak Numfor", "Kab. Kepulauan Yapen"},
            // 33. Papua Barat
            {"Kab. Manokwari", "Kab. Fakfak", "Kab. Kaimana", "Kab. Teluk Bintuni"},
            // 34. Papua Selatan
            {"Kab. Merauke", "Kab. Boven Digoel", "Kab. Mappi", "Kab. Asmat"},
            // 35. Papua Tengah
            {"Kab. Nabire", "Kab. Mimika (Timika)", "Kab. Paniai", "Kab. Puncak Jaya"},
            // 36. Papua Pegunungan
            {"Kab. Jayawijaya (Wamena)", "Kab. Lanny Jaya", "Kab. Yahukimo"},
            // 37. Papua Barat Daya
            {"Kota Sorong", "Kab. Sorong", "Kab. Raja Ampat", "Kab. Sorong Selatan"},
            // 38. Mancanegara / Luar Negeri
            {"Kuala Lumpur (Malaysia)", "Johor Bahru (Malaysia)", "Singapura", "Bandar Seri Begawan (Brunei)", "Makkah / Madinah (Arab Saudi)", "Kairo (Mesir)", "Negara Lainnya"}
    };


    // ================= v4.1 KECAMATAN NYATA & 16 TOKOH PENGHUNI PONDOK =================
    public static String[] getKecamatanForCity(String cityName) {
        if (cityName == null) return new String[]{"Kecamatan Pusat Kota", "Kecamatan Utara", "Kecamatan Selatan", "Kecamatan Timur", "Kecamatan Barat"};
        String c = cityName.toLowerCase(java.util.Locale.ROOT);
        if (c.contains("situbondo")) {
            return new String[]{
                    "Kec. Situbondo", "Kec. Panji", "Kec. Mangaran", "Kec. Panarukan", "Kec. Kendit",
                    "Kec. Kapongan", "Kec. Arjasa", "Kec. Jangkar", "Kec. Asembagus", "Kec. Banyuputih",
                    "Kec. Bungatan", "Kec. Mlandingan", "Kec. Suboh", "Kec. Besuki", "Kec. Jatibanteng",
                    "Kec. Banyuglugur", "Kec. Sumbermalang"
            };
        }
        if (c.contains("bondowoso")) {
            return new String[]{"Kec. Bondowoso", "Kec. Tenggarang", "Kec. Curahdami", "Kec. Maesan", "Kec. Grujugan", "Kec. Prajekan", "Kec. Tapen", "Kec. Wonosari", "Kec. Cermee", "Kec. Tamanan", "Kec. Pujer", "Kec. Sukosari"};
        }
        if (c.contains("banyuwangi")) {
            return new String[]{"Kec. Banyuwangi", "Kec. Giri", "Kec. Glagah", "Kec. Kalipuro", "Kec. Rogojampi", "Kec. Genteng", "Kec. Muncar", "Kec. Cluring", "Kec. Srono", "Kec. Wongsorejo", "Kec. Songgon", "Kec. Gambiran"};
        }
        if (c.contains("jember")) {
            return new String[]{"Kec. Kaliwates", "Kec. Sumbersari", "Kec. Patrang", "Kec. Rambipuji", "Kec. Tanggul", "Kec. Ambulu", "Kec. Balung", "Kec. Kencong", "Kec. Kalisat", "Kec. Wuluhan", "Kec. Puger", "Kec. Arjasa"};
        }
        if (c.contains("surabaya")) {
            return new String[]{"Kec. Genteng", "Kec. Tegalsari", "Kec. Gubeng", "Kec. Wonokromo", "Kec. Rungkut", "Kec. Sukolilo", "Kec. Mulyorejo", "Kec. Kenjeran", "Kec. Semampir (Ampel)", "Kec. Tambaksari", "Kec. Sawahan", "Kec. Tandes"};
        }
        if (c.contains("malang")) {
            return new String[]{"Kec. Klojen", "Kec. Blimbing", "Kec. Lowokwaru", "Kec. Sukun", "Kec. Kedungkandang", "Kec. Singosari", "Kec. Lawang", "Kec. Kepanjen", "Kec. Turen", "Kec. Gondanglegi", "Kec. Pakis", "Kec. Dau"};
        }
        if (c.contains("sidoarjo")) {
            return new String[]{"Kec. Sidoarjo", "Kec. Waru", "Kec. Taman", "Kec. Buduran", "Kec. Candi", "Kec. Gedangan", "Kec. Krian", "Kec. Porong", "Kec. Sedati", "Kec. Sukodono"};
        }
        if (c.contains("semarang")) {
            return new String[]{"Kec. Semarang Tengah", "Kec. Semarang Barat", "Kec. Semarang Timur", "Kec. Semarang Selatan", "Kec. Semarang Utara", "Kec. Tembalang", "Kec. Banyumanik", "Kec. Pedurungan", "Kec. Ngaliyan", "Kec. Ungaran Barat"};
        }
        if (c.contains("surakarta") || c.contains("solo")) {
            return new String[]{"Kec. Laweyan", "Kec. Serengan", "Kec. Pasar Kliwon", "Kec. Jebres", "Kec. Banjarsari"};
        }
        if (c.contains("kudus")) {
            return new String[]{"Kec. Kota Kudus", "Kec. Jati", "Kec. Bae", "Kec. Kaliwungu", "Kec. Gebog", "Kec. Dawe", "Kec. Mejobo", "Kec. Jekulo", "Kec. Undaan"};
        }
        if (c.contains("yogyakarta")) {
            return new String[]{"Kemantren Gondokusuman", "Kemantren Jetis", "Kemantren Danurejan", "Kemantren Kraton", "Kemantren Kotagede", "Kemantren Umbulharjo", "Kemantren Mergangsan", "Kemantren Wirobrajan"};
        }
        if (c.contains("sleman")) {
            return new String[]{"Kapanewon Depok", "Kapanewon Mlati", "Kapanewon Gamping", "Kapanewon Kalasan", "Kapanewon Ngaglik", "Kapanewon Sleman", "Kapanewon Pakem", "Kapanewon Prambanan"};
        }
        if (c.contains("bantul")) {
            return new String[]{"Kapanewon Bantul", "Kapanewon Sewon", "Kapanewon Kasihan", "Kapanewon Banguntapan", "Kapanewon Imogiri", "Kapanewon Pleret", "Kapanewon Kretek"};
        }
        if (c.contains("bandung")) {
            return new String[]{"Kec. Coblong", "Kec. Sukajadi", "Kec. Cicendo", "Kec. Cibeunying", "Kec. Antapani", "Kec. Buahbatu", "Kec. Soreang", "Kec. Lembang", "Kec. Cileunyi"};
        }
        if (c.contains("jakarta")) {
            return new String[]{"Kec. Menteng", "Kec. Tanah Abang", "Kec. Tebet", "Kec. Kebayoran Baru", "Kec. Jatinegara", "Kec. Cakung", "Kec. Palmerah", "Kec. Kelapa Gading"};
        }
        return new String[]{
                "Kec. " + cityName.replace("Kab. ", "").replace("Kota ", "") + " Pusat",
                "Kec. " + cityName.replace("Kab. ", "").replace("Kota ", "") + " Utara",
                "Kec. " + cityName.replace("Kab. ", "").replace("Kota ", "") + " Selatan",
                "Kec. " + cityName.replace("Kab. ", "").replace("Kota ", "") + " Timur",
                "Kec. " + cityName.replace("Kab. ", "").replace("Kota ", "") + " Barat"
        };
    }

    // 16 Tokoh & Karakter Hidup Pondok Hafidz Netra (Suara Media Teknologi)
    // Format: {nama, jabatan, lokasi, sapaanKhas}
    public static final String[][] PONDOK_CHARACTERS_V41 = {
            {"Ustadz Yeni Setiawan", "Kepala Madrasah & Pengasuh Utama Putra", "Masjid Agung & Kampus Ma'had Aly", "Assalamu'alaikum! Saya Ustadz Yeni Setiawan, Kepala Madrasah Pondok Hafidz Netra. Jaga niat ikhlas, konsisten murajaah, dan jangan pernah menyerah menghafal Al-Qur'an!"},
            {"Ustadzah Nur", "Pengasuh Utama Putri & Kepala Tata Usaha", "Kantor TU & Asrama Putri", "Assalamu'alaikum! Saya Ustadzah Nur dari Suara Media Teknologi. Jika ada kendala belajar, dokumen KTS/SK, atau butuh metode audio khusus, langsung sapa saya ya!"},
            {"Ibu Nyai Aminah", "Pengasuh & Pembimbing Asrama Putri", "Asrama Putri (Kamar Khadijah, Aisyah, Fatimah)", "Selamat datang nak di Asrama Putri. Jaga kebersihan kamar, shalat tepat waktu, dan saling menyemangati dengan teman sekamar."},
            {"Kak Bilal", "Ketua Asrama Putra & Pembimbing Harian", "Asrama Putra (Kamar Abu Bakar, Umar, Utsman)", "Semangat santri putra! Sebelum masuk kelas utama, pastikan wudhu terjaga dan kita murajaah bareng 3 menit di serambi kamar."},
            {"Kang Ridho", "Kepala Keamanan Gerbang Selatan", "Gerbang Selatan & Pos Keamanan", "Assalamu'alaikum! Saya Kang Ridho penjaga Gerbang Selatan. Dari sini ke Utara ada Masjid dan Kelas, ke Timur Kantor TU, ke Barat Asrama, dan keluar ke Selatan ada Rumah Santri serta Pasar."},
            {"Mbak Aisyah", "Pengelola Koperasi Berkah & Warung Santri", "Zona Ekonomi (Timur)", "Halo santri! Di Koperasi Berkah dan Warung Santri kita kelola Kas Wakaf Rp 4 Miliar dan Panen Pasif Rp 500 Juta untuk membangun pondok bersama."},
            {"Bu Nyai Fatimah", "Kepala Dapur Umum Pondok", "Dapur Umum (187.500+ Menu)", "Ayo makan dulu biar kuat menghafal! Dapur Umum hari ini punya lebih dari 187.500 kombinasi menu nusantara bergizi untuk memulihkan staminamu."},
            {"Mang Ujang", "Juru Masak Nusantara Dapur Umum", "Dapur Umum (Barat)", "Siap komandan! Bumbu rempah segar dari Pasar Pondok sudah siap ditumis, tinggal pilih resep favoritmu lalu kita masak bertahap."},
            {"Pak Kiai Mansur", "Pembina Kebun Organik & Agribisnis", "Kebun Organik Pondok (Barat)", "Menanam dan merawat kebun melatih kesabaran seperti menanam hafalan di hati. Ayo siram tanaman dan panen hasilnya!"},
            {"Kang Hasan", "Pengurus Tambak Ikan Pondok", "Tambak Ikan (Barat)", "Ikan gurame dan nila di tambak sudah menunggu diberi pakan. Kalau sudah besar kita panen untuk lauk dapur dan kas pondok!"},
            {"Ustadzah dr. Halimah", "Dokter & Pembina Klinik UKS Herbal", "Klinik UKS & Herbal Sunnah (Barat)", "Kesehatan adalah modal utama penghafal Qur'an. Jika lelah atau suara serak, mampir ke UKS minum madu hutan dan jahe merah hangat."},
            {"Ustadz Fauzan", "Pustakawan Perpustakaan Audio & Kitab Kuning", "Perpustakaan Audio (Timur)", "Di Perpustakaan Audio tersedia Ta'lim Muta'allim, Tajwid Praktis, Fikih Wudhu, Hadits Arbain, hingga Sirah sahabat mulia Abdullah bin Ummi Maktum."},
            {"Ustadz Syafi'i Al-Hafidz", "Guru Lab Tajwid & Klinik Makhraj", "Lab Tajwid & Kelas Utama", "Mari perhalus makhraj huruf dan panjang napas di Lab Tajwid. Bacaan yang tenang dan tepat makhrajnya jauh lebih mudah melekat di ingatan."},
            {"Ustadz Hakim", "Moderator Balai Musyawarah (Bahtsul Masail)", "Balai Musyawarah (Timur)", "Ada pertanyaan fikih ibadah sehari-hari? Diskusikan di Balai Musyawarah supaya ibadah dan hafalan kita berjalan di atas ilmu."},
            {"Salma & Zahra", "Teman Sekamar Asrama Putri", "Asrama Putri", "Assalamu'alaikum! Yuk setor bareng 2 ayat sebelum bel kelas bunyi, nanti sore kita ikut Wirid Sore jam 17.00 bareng-bareng!"},
            {"Ahmad, Farhan & Mang Jafar", "Teman Sekamar Putra & Pemandu Rihlah Ahad", "Asrama Putra & Pasar Pondok", "Semangat terus bro! Hari Ahad nanti kita ikut Rihlah dan Ziarah bareng Mang Jafar setelah belanja kebutuhan di Pasar Pondok!"}
    };


    public static final String KEY_LAST_CORONG_SEEN = "v42_last_corong_seen";
    public static final String KEY_PSB_WAWANCARA = "v42_psb_wawancara";
    public static final String PENGURUS_CORONG_PIN = "0877";


    // ================= v5.0 PONDOK HIDUP NYATA CONSTANTS =================
    public static final String KEY_SIM_CLOCK_ENABLED = "v5_sim_clock_enabled";
    public static final String KEY_SIM_CLOCK_OFFSET_MIN = "v5_sim_clock_offset_min";
    public static final String KEY_SIM_CLOCK_ANCHOR_MS = "v5_sim_clock_anchor_ms";
    public static final String KEY_ADAPT_M1 = "v5_adapt_m1_sapa";
    public static final String KEY_ADAPT_M2 = "v5_adapt_m2_hunian";
    public static final String KEY_ADAPT_M3 = "v5_adapt_m3_talaqqi";
    public static final String KEY_MUTABAAH_DAILY_DATE = "v5_mutabaah_date";
    public static final String KEY_MUTABAAH_DAILY_MASK = "v5_mutabaah_mask";
    public static final String KEY_ENTRY_TEST_SCORE = "v5_entry_test_score";
    public static final String KEY_WALK_MODE_ENABLED = "v5_walk_mode_enabled";
    public static final String KEY_ANTI_OVERLAP_TALKBACK = "v55_anti_overlap_talkback";


    // ================= v5.1 IQRA 1-6, JUZ 1-30, 12 KEJADIAN HIDUP & DIAGNOSTIK JUJUR =================
    public static final String KEY_AUTO_STUDY_LOG = "v51_auto_study_log";
    public static final String KEY_TOTAL_STUDY_SESSIONS = "v51_total_study_sessions";
    public static final String KEY_TOTAL_STUDY_MINUTES = "v51_total_study_minutes";
    public static final String KEY_IQRA_LEVEL = "v51_iqra_level";
    public static final String KEY_IQRA_NEED_REVIEW_JILID = "v56_iqra_need_review_jilid";
    public static final String KEY_LAST_EVENT_MEMORY = "v51_last_event_memory";
    public static final String KEY_DAILY_MISSION_DATE = "v51_daily_mission_date";
    public static final String KEY_DAILY_MISSION_MASK = "v51_daily_mission_mask";

    public static final String[][] IQRA_JILID_LESSONS = {
            {"Iqra' Jilid 1 — Pengenalan 28 Huruf Hijaiyah (Fathah)", "Latihan bunyi huruf berharakat Fathah: A, Ba, Ta, Tsa, Ja, Ha, Kha, Da, Dza, Ra, Za, Sa, Sya, Sha, Dha, Tha, Zha, 'A, Gha, Fa, Qa, Ka, La, Ma, Na, Wa, Ha, Ya. Ucapkan pelan dan jelas dari makhrajnya!"},
            {"Iqra' Jilid 2 — Huruf Sambung & Panjang Mad 2 Harakat", "Latihan membedakan pendek dan panjang 2 harakat (Mad Thabi'i): Ba pendek vs Baa panjang, Ma pendek vs Maa panjang. Contoh: Qaa-la, Kaa-na, Baa-ba. Jangan memanjangkan huruf yang pendek!"},
            {"Iqra' Jilid 3 — Harakat Kasrah (i) & Dhammah (u)", "Latihan vokal Kasrah (bi, ti, mi, ni) dan Dhammah (bu, tu, mu, nu). Contoh: Ku-ti-ba, 'U-li-ma, Ru-zi-qa, Bi-i-dz-ni. Pastikan bibir membulat sempurna saat Dhammah!"},
            {"Iqra' Jilid 4 — Tanwin (an, in, un), Sukun & Qalqalah", "Latihan bunyi akhir Tanwin (ban, bin, bun), huruf mati Sukun, dan pantulan 5 huruf Qalqalah (Ba, Jim, Dal, Tha, Qaf). Contoh: A-ha-dun, Lam ya-lid wa lam yuu-lad."},
            {"Iqra' Jilid 5 — Tasydid, Waqaf & Hukum Nun Mati", "Latihan penekanan huruf bertasydid (In-na, Tsum-ma, Rab-bi) dengan dengung 2 harakat pada Nun/Mim Tasydid, serta berhenti tenang saat waqaf di akhir ayat."},
            {"Iqra' Jilid 6 — Praktik Ayat Al-Qur'an Utuh & Persiapan Tahfidz", "Latihan menyambung bacaan ayat Al-Qur'an secara utuh dengan menjaga mad, dengung ghunnah, dan makhraj. Setelah lulus Jilid 6, santri siap penuh masuk program Tahfidz Juz 30!"}
    };

    // Juz 1..30 -> {label, surahMulai}
    public static final String[][] JUZ_LIST_30 = {
            {"Juz 1 — Al-Fatihah & Al-Baqarah (1-141)", "1"},
            {"Juz 2 — Al-Baqarah (142-252)", "2"},
            {"Juz 3 — Al-Baqarah (253) & Ali 'Imran", "3"},
            {"Juz 4 — Ali 'Imran & An-Nisa", "4"},
            {"Juz 5 — An-Nisa (24-147)", "4"},
            {"Juz 6 — An-Nisa & Al-Ma'idah", "5"},
            {"Juz 7 — Al-Ma'idah & Al-An'am", "6"},
            {"Juz 8 — Al-An'am & Al-A'raf", "7"},
            {"Juz 9 — Al-A'raf & Al-Anfal", "8"},
            {"Juz 10 — Al-Anfal & At-Taubah", "9"},
            {"Juz 11 — At-Taubah, Yunus & Hud", "10"},
            {"Juz 12 — Hud & Yusuf", "12"},
            {"Juz 13 — Yusuf, Ar-Ra'd & Ibrahim", "13"},
            {"Juz 14 — Al-Hijr & An-Nahl", "15"},
            {"Juz 15 — Al-Isra & Al-Kahfi", "18"},
            {"Juz 16 — Al-Kahfi, Maryam & Taha", "19"},
            {"Juz 17 — Al-Anbiya & Al-Hajj", "21"},
            {"Juz 18 — Al-Mu'minun, An-Nur & Al-Furqan", "23"},
            {"Juz 19 — Al-Furqan, Asy-Syu'ara & An-Naml", "26"},
            {"Juz 20 — An-Naml, Al-Qasas & Al-Ankabut", "28"},
            {"Juz 21 — Al-Ankabut, Ar-Rum, Luqman & As-Sajdah", "32"},
            {"Juz 22 — Al-Ahzab, Saba, Fatir & Yasin", "36"},
            {"Juz 23 — Yasin, As-Saffat, Sad & Az-Zumar", "36"},
            {"Juz 24 — Az-Zumar, Ghafir & Fussilat", "40"},
            {"Juz 25 — Fussilat, Asy-Syura, Az-Zukhruf & Al-Jasiyah", "42"},
            {"Juz 26 — Al-Ahqaf, Muhammad, Al-Fath & Qaf", "48"},
            {"Juz 27 — Az-Zariyat, Ar-Rahman & Al-Waqiah", "55"},
            {"Juz 28 — Al-Mujadilah sampai At-Tahrim", "58"},
            {"Juz 29 — Tabarak (Al-Mulk sampai Al-Mursalat)", "67"},
            {"Juz 30 — Juz Amma (An-Naba sampai An-Nas)", "78"}
    };

    // 10 Kejadian Hidup Bercabang Pondok: {judul, cerita, pilihanA, hasilA, pilihanB, hasilB}
    public static final String[][] LIVING_EVENTS_V51 = {
            {"Teman Sekamar Lupa Sambungan Ayat!", "Salma / Ahmad mengetuk mejamu dengan gugup: 'Tolong simak aku 1 menit dong, aku lupa ujung ayat sebelum dipanggil setor!'",
             "Bantu simak hafalannya dengan sabar (+25 XP, +15 Kedekatan)", "Alhamdulillah! Temanmu jadi lancar setor dan mendoakanmu tulus. Kedekatan pondok naik pesat!",
             "Ajak langsung latihan bareng di Ruang Belajar (+15 XP)", "Kalian berdua makin semangat belajar bareng hari ini!"},
            {"Kiriman Paket Orang Tua di Gerbang Selatan!", "Kang Ridho memanggil dari pos gerbang: 'Assalamu'alaikum! Ada kiriman kurma Ajwa dan surat doa dari orang tuamu di rumah!'",
             "Ambil paket & bagikan kurma ke teman sekamar (+30 XP, +20 Stamina)", "MasyaAllah, suasana kamar jadi hangat penuh syukur dan doa bersama!",
             "Simpan untuk bekal muraja'ah Subuh besok (+25 Stamina)", "Bekal sehat siap menemani hafalan Subuh besok!"},
            {"Tantangan Kilat Kepala Madrasah!", "Ustadz Yeni Setiawan mampir di serambi: 'Saya tantang santri yang siap menguji 1 ayat tanpa bantuan hari ini!'",
             "Terima tantangan dengan percaya diri (+35 XP, Nilai Naik)", "Ustadz Yeni tersenyum bangga melihat keberanianmu menghadapi ujian!",
             "Minta waktu 5 menit muraja'ah dulu sebelum maju (+15 XP)", "Ustadz Yeni menghargai kejujuranmu mempersiapkan diri dengan matang."},
            {"Bu Nyai Fatimah Minta Bantuan Cicip Masakan!", "Aroma soto rempah tercium dari Dapur Umum. Bu Nyai Fatimah memanggil: 'Nak, tolong cicipi kuah masakan makan siang santri, sudah pas belum?'",
             "Cicipi & beri saran bumbu dengan ramah (+25 Stamina, +20 XP)", "Bu Nyai Fatimah dan Mang Ujang senang sekali — kamu dapat porsi hangat tambahan!",
             "Bantu rapikan piring bersama santri lain (+25 XP, +10 Kedekatan)", "Kebersamaan di dapur bikin suasana pondok terasa seperti rumah sendiri."},
            {"Tamu Wali Santri Bertanya Arah Kantor TU!", "Seorang ibu wali santri baru tampak bingung di depan Gerbang Selatan mencari lokasi Loket 1 PSB.",
             "Antarkan langsung ke Timur sampai depan pintu TU (+30 XP, +15 Kedekatan)", "Ibu wali sangat terharu dengan akhlak santri Pondok Hafidz Netra dan mendoakanmu!",
             "Tunjukkan arah Timur 40 meter dengan jelas dan sopan (+15 XP)", "Ibu wali berterima kasih dan langsung menemukan Kantor TU."},
            {"Ustadzah Nur Mengecek Buku Mutaba'ah!", "Ustadzah Nur menghampirimu: 'Mari saya cek kejujuran catatan belajarmu pekan ini — sudah istiqamah atau mulai melambat?'",
             "Jawab jujur & perbaiki ayat yang masih kuning (+30 XP)", "Ustadzah Nur memuji kejujuranmu: 'Kejujuran adalah kunci keberkahan hafalan!'",
             "Minta bimbingan metode yang paling cocok (+20 XP)", "Ustadzah Nur menyarankan fokus di Tikrar Bertahap dengan jeda 4 detik."}
    };


    // ================= v5.2 ANTI-BOHONG, BLOK KESULITAN AYAT & 500.000 TEMPLATE SURAT IZIN =================
    public static final String KEY_DIFF_BLOCK_SURAH = "v52_diff_block_surah";
    public static final String KEY_DIFF_BLOCK_NAME = "v52_diff_block_name";
    public static final String KEY_DIFF_BLOCK_START = "v52_diff_block_start";
    public static final String KEY_DIFF_BLOCK_END = "v52_diff_block_end";
    public static final String KEY_SIDANG_PASSED = "v52_sidang_passed";
    public static final String KEY_PANTRY_INIT_V52 = "v52_pantry_init";
    public static final String KEY_TOMORROW_PERMIT_NOTE = "v52_tomorrow_permit_note";

    // 25 x 40 x 25 x 20 = 500.000 Kombinasi Template Surat Izin Formal Pesantren!
    public static final String[] PERMIT_OPENINGS = {
            "Assalamu'alaikum warahmatullahi wabarakatuh. Dengan penuh hormat kepada Ustadzah Nur dan Ustadz Yeni Setiawan,",
            "Assalamu'alaikum warahmatullahi wabarakatuh. Kepada Yth. Pengasuh dan Kepala TU Pondok Hafidz Netra,",
            "Bismillahirrahmanirrahim. Salam takzim saya sampaikan kepada Kepala Madrasah dan jajaran pengurus TU,",
            "Dengan memohon ridha Allah SWT, melalui surat resmi ini saya bermaksud menyampaikan permohonan izin kepada Ustadzah Nur,",
            "Assalamu'alaikum warahmatullahi wabarakatuh. Semoga pengasuh dan seluruh ustadz-ustadzah senantiasa dalam lindungan Allah,",
            "Kepada Yth. Kepala Tata Usaha Santri Digital Pondok Hafidz Netra (Suara Media Teknologi),",
            "Dengan segala kerendahan hati, saya selaku santri memohon izin resmi kepada jajaran pengasuh madrasah,",
            "Assalamu'alaikum. Melalui Loket 2 Perizinan Pondok Hafidz Netra, saya menyampaikan pemberitahuan resmi,",
            "Salam hormat dan doa kebaikan untuk Ustadz Yeni Setiawan serta Ustadzah Nur selaku pengasuh kami,",
            "Bismillah. Izinkan saya mengajukan permohonan izin tertulis sesuai tata tertib resmi pondok,",
            "Assalamu'alaikum warahmatullahi wabarakatuh. Dengan penuh adab saya mengajukan surat permohonan izin,",
            "Kepada Yth. Wali Kelas dan Pengelola Tata Usaha Pondok Hafidz Netra,",
            "Dengan hormat, saya menyampaikan kabar kondisi saya melalui surat resmi berikut,",
            "Assalamu'alaikum. Mohon berkenan Ustadzah Nur menerima permohonan izin kehadiran saya,",
            "Salam silaturahmi dari santri kepada seluruh dewan asatidz Pondok Hafidz Netra,",
            "Dengan mengharap berkah dan kelapangan hati pengasuh, saya sampaikan surat permohonan izin ini,",
            "Assalamu'alaikum warahmatullahi wabarakatuh. Teriring doa semoga seluruh kegiatan pondok berjalan lancar,",
            "Kepada Yth. Pimpinan Madrasah dan Petugas Piket Kantor TU Pondok Hafidz Netra,",
            "Bismillahirrahmanirrahim. Demi menjaga ketertiban presensi madrasah, saya mengajukan izin resmi,",
            "Dengan penuh rasa tanggung jawab sebagai santri, saya melaporkan halangan kehadiran saya,",
            "Assalamu'alaikum. Saya bermohon kiranya pengurus TU berkenan mencatat izin kehadiran saya,",
            "Kepada Yth. Dewan Pengasuh Putra dan Putri Santri Digital Pondok Hafidz Netra,",
            "Salam hormat untuk guru-guru tercinta di Pondok Hafidz Netra Suara Media Teknologi,",
            "Dengan hormat dan penuh harap, saya ajukan pemberitahuan resmi terkait jadwal kelas saya,",
            "Assalamu'alaikum warahmatullahi wabarakatuh. Melalui surat ini saya memohon kelonggaran izin resmi,"
    };

    public static final String[] PERMIT_REASONS = {
            "sedang kurang sehat (demam ringan) sehingga perlu beristirahat di rumah/UKS",
            "sedang mengalami flu dan suara serak sehingga perlu memulihkan tenggorokan",
            "harus mengantar orang tua melakukan pemeriksaan kesehatan ke puskesmas/klinik",
            "ada keperluan mendesak keluarga besar yang tidak dapat ditinggalkan",
            "sedang membantu acara pengajian dan hajatan keluarga di rumah",
            "menghadiri acara silaturahmi dan doa bersama keluarga di luar kota",
            "ada kendala hujan deras dan cuaca ekstrem di perjalanan menuju pondok",
            "diperkirakan terlambat 15-25 menit karena kendala transportasi keberangkatan",
            "sedang mendampingi anggota keluarga yang sedang dirawat",
            "harus menyelesaikan urusan administrasi kependudukan di kelurahan/kecamatan",
            "sedang mengikuti pemeriksaan kesehatan mata/tubuh rutin bersama keluarga",
            "ada agenda kuliah/ujian kampus luar yang berbenturan dengan jam kelas",
            "sedang menjalani jadwal kerja/shift yang belum bisa ditukar hari ini",
            "perlu beristirahat memulihkan kelelahan fisik pasca perjalanan jauh",
            "ada kegiatan sosial kemasyarakatan penting di lingkungan rumah",
            "menghadiri takziah kerabat dekat yang baru saja berpulang ke rahmatullah",
            "menghadiri walimatul ursy (pernikahan) saudara kandung/kerabat dekat",
            "harus memperbaiki perangkat HP/pembaca layar yang sedang mengalami gangguan",
            "ada gangguan listrik dan jaringan internet di wilayah tempat tinggal kami",
            "sedang menemani adik/keluarga mengurus keperluan sekolah",
            "sedang menjalani pemulihan pusing dan masuk angin sejak semalam",
            "diperkirakan datang agak terlambat besok pagi karena urusan rumah tangga",
            "ada panggilan pertemuan wali dan keluarga besar pada jam pelajaran",
            "harus mengambil obat rutin di fasilitas kesehatan setempat",
            "sedang mengikuti pelatihan keterampilan aksesibilitas tunanetra",
            "ada kunjungan tamu keluarga dari luar daerah yang harus disambut",
            "perlu mengurus keperluan surat-menyurat penting di kantor desa",
            "sedang memulihkan stamina karena kurang tidur menjaga orang tua sakit",
            "ada perbaikan rumah/lingkungan yang membutuhkan kehadiran keluarga",
            "mengikuti kegiatan santunan dan bakti sosial di masjid sekitar rumah",
            "ada jadwal kontrol kesehatan gigi/umum yang sudah terjadwal sebelumnya",
            "terkendala kemacetan dan perbaikan jalan di rute menuju pondok",
            "sedang dalam perjalanan pulang dari luar kota menuju rumah/asrama",
            "ada keperluan mendadak membantu usaha keluarga pada pagi/siang hari",
            "mengalami batuk ringan sehingga khawatir mengganggu kekhusyukan kelas",
            "sedang mengurus pendaftaran/berkas pendidikan formal di daerah",
            "menghadiri tasyakuran keberangkatan umrah/haji kerabat dekat",
            "perlu waktu istirahat tambahan sesuai anjuran tenaga kesehatan",
            "ada jadwal wawancara/kegiatan penting yang tidak dapat dijadwalkan ulang",
            "khawatir datang terlambat pada sesi besok sehingga melapor lebih awal malam ini"
    };

    public static final String[] PERMIT_COMMITMENTS = {
            "Saya berjanji akan mengejar ketertinggalan lewat Kelas Susulan atau Meja Belajar 24 Jam.",
            "InsyaAllah saya tetap menjaga muraja'ah mandiri di rumah agar hafalan tidak lupa.",
            "Saya siap menyetorkan ayat yang terlewat segera setelah kondisi kembali normal.",
            "Saya berkomitmen menuntaskan target ayat harian di Rumah Santri malam harinya.",
            "InsyaAllah besok saya akan kembali hadir tepat waktu mengikuti panggilan presensi.",
            "Saya memohon maaf sebesar-besarnya atas ketidakhadiran/keterlambatan ini.",
            "Saya siap mengikuti arahan pembinaan dari Ustadzah Nur dan Ustadz Yeni Setiawan.",
            "Saya akan tetap mengisi Buku Mutaba'ah Yaumiyah dari rumah dengan jujur.",
            "InsyaAllah begitu urusan selesai saya langsung membuka 20 metode hafalan mandiri.",
            "Saya berjanji tidak menyia-nyiakan kelonggaran izin yang diberikan Kantor TU.",
            "Saya siap diuji ulang hafalannya saat kembali masuk Gedung Kelas Utama.",
            "Saya tetap akan menyimak Doa Pagi dan Wirid Sore 17.00 dari rumah.",
            "Mohon kiranya pengasuh berkenan mencatat izin ini agar terbebas dari SP.",
            "Saya akan melaporkan perkembangan hafalan kepada guru pembimbing setelah sesi selesai.",
            "InsyaAllah saya langsung menuntaskan blok ayat yang kemarin masih perlu penguatan.",
            "Saya berkomitmen menjaga kedisiplinan dan adab santri di mana pun berada.",
            "Saya memohon kelapangan hati guru dan teman-teman sekelas atas halangan ini.",
            "Saya siap mengikuti sesi Tikrar Bertahap tambahan untuk mengganti jam kelas.",
            "InsyaAllah saya akan segera menyusul materi di Perpustakaan Audio pondok.",
            "Saya berjanji hadir lebih awal pada jadwal pertemuan berikutnya.",
            "Saya siap menerima koreksi tegas guru pada setoran berikutnya.",
            "Saya tetap menjaga wudhu dan tilawah ringan di sela-sela keperluan saya.",
            "Mohon doa dari para guru agar urusan/kesehatan saya segera dimudahkan Allah.",
            "Saya akan memastikan catatan belajar tetap tercatat aktif di sistem pondok.",
            "Terima kasih banyak atas pengertian dan bimbingan tulus seluruh pengurus TU."
    };

    public static final String[] PERMIT_CLOSINGS = {
            "Jazakumullahu khairan katsiran. Wassalamu'alaikum warahmatullahi wabarakatuh.",
            "Atas perhatian dan izin yang diberikan saya ucapkan terima kasih. Wassalamu'alaikum.",
            "Semoga Allah membalas kebaikan para guru dengan pahala berlipat. Wassalamu'alaikum.",
            "Barakallahu fiikum. Hormat saya, santri Pondok Hafidz Netra. Wassalamu'alaikum.",
            "Demikian surat izin resmi ini saya sampaikan dengan sebenar-benarnya. Wassalamu'alaikum.",
            "Semoga Pondok Hafidz Netra Suara Media Teknologi senantiasa jaya dan berkah. Wassalamu'alaikum.",
            "Mohon doa restu selalu dari Ustadzah Nur dan Ustadz Yeni Setiawan. Wassalamu'alaikum.",
            "Terima kasih atas kebijaksanaan pengurus TU. Wassalamu'alaikum warahmatullahi wabarakatuh.",
            "Semoga Allah memudahkan segala urusan kita bersama. Aamiin. Wassalamu'alaikum.",
            "Hormat dan takzim selalu dari saya. Wassalamu'alaikum warahmatullahi wabarakatuh.",
            "Alhamdulillah atas perhatiannya, semoga kita selalu dalam rahmat Allah. Wassalamu'alaikum.",
            "Demikian permohonan ini saya buat dengan penuh kejujuran. Wassalamu'alaikum.",
            "Terima kasih sebesar-besarnya atas kelonggaran yang diberikan. Wassalamu'alaikum.",
            "Semoga silaturahmi dan semangat menghafal Qur'an tetap terjaga. Wassalamu'alaikum.",
            "Salam hormat untuk seluruh asatidz dan teman-teman santri. Wassalamu'alaikum.",
            "Atas izin dan doanya saya haturkan jazakumullahu khairan. Wassalamu'alaikum.",
            "Semoga kita semua senantiasa diberikan kesehatan dan istiqamah. Wassalamu'alaikum.",
            "Demikian pemberitahuan resmi ini saya ajukan. Wassalamu'alaikum warahmatullahi wabarakatuh.",
            "Terima kasih banyak Ustadzah Nur dan seluruh pengurus Loket 2. Wassalamu'alaikum.",
            "Wallahu waliyyut taufiq. Wassalamu'alaikum warahmatullahi wabarakatuh."
    };

    // Soal Ujian Naik Jilid Iqra' Nyata (3 soal per tes, anti-bohong!)
    // Format: {soal, pilA, pilB, pilC, correctIdx(0/1/2), penjelasanJujur}
    public static final String[][] IQRA_EXAM_BANK = {
            {"Ujian Iqra' (1/3): Harakat baris di atas huruf hijaiyah (berbunyi 'A, Ba, Ta') disebut apa?", "Fathah", "Kasrah", "Dhammah", "0", "Baris di atas adalah Fathah."},
            {"Ujian Iqra' (2/3): Manakah yang termasuk huruf Qalqalah (memantul saat sukun)?", "Ba, Jim, Dal, Tha, Qaf", "Sin, Syin, Shad", "Mim, Nun, Wawu", "0", "Lima huruf Qalqalah disingkat Ba-Ju-Di-To-Qo (Ba, Jim, Dal, Tha, Qaf)."},
            {"Ujian Iqra' (3/3): Berapa harakat panjang bacaan Mad Thabi'i (panjang asli)?", "2 harakat (1 ayunan)", "6 harakat", "Tidak dipanjangkan", "0", "Mad Thabi'i dibaca pas 2 harakat."}
    };

    // Soal Sidang Munaqasyah 5 Soal Nyata (Wajib skor >= 80 / minimal 4 benar untuk buka Syahadah PNG!)
    public static final String[][] SIDANG_EXAM_BANK = {
            {"Lanjutkan ayat setelah 'Qul huwallahu ahad' (Al-Ikhlas: 1):", "Allahush-shamad", "Malikin-nas", "Min syarri ma khalaq", "0"},
            {"Hukum Nun Mati bertemu huruf 'Ba' (seperti Mim ba'di) disebut:", "Iqlab (bunyi mim samar)", "Idzhar Halqi", "Idgham Bilaghunnah", "0"},
            {"Berapa jumlah ayat dalam Surat Al-Fatihah?", "7 ayat", "5 ayat", "6 ayat", "0"},
            {"Surat yang dianjurkan dibaca setiap malam Jumat / hari Jumat untuk cahaya antara dua Jumat adalah:", "Surat Al-Kahfi", "Surat Al-Lahab", "Surat Al-Fil", "0"},
            {"Hukum huruf Nun Bertasydid (Inna) dan Mim Bertasydid (Tsumma) adalah:", "Ghunnah (dengung 2 harakat)", "Qalqalah Kubra", "Idzhar Syafawi", "0"},
            {"Lanjutkan ayat setelah 'Qul a'udzu birabbil falaq' (Al-Falaq: 1):", "Min syarri ma khalaq", "Malikin-nas", "Lam yalid wa lam yulad", "0"},
            {"Huruf Qalqalah yang memantul saat berharakat sukun berjumlah berapa huruf?", "5 huruf (Ba, Jim, Dal, Tha, Qaf)", "3 huruf (Alif, Wawu, Ya)", "4 huruf (Ya, Nun, Mim, Wawu)", "0"},
            {"Mad Thabi'i (seperti Qaa-la, Fii, Yakuu-nu) dibaca panjang berapa harakat?", "2 harakat", "1 harakat pendek", "6 harakat", "0"}
    };


    // Kode Resmi Kemendagri 38 Provinsi + LN (1-ke-1 selaras dengan PROVINCES_LIST)
    public static final String[] PROVINCE_IDS = {
            "35", "33", "32", "31", "34", "36",
            "11", "12", "13", "14", "21", "15",
            "16", "19", "17", "18",
            "51", "52", "53",
            "61", "62", "63", "64", "65",
            "71", "75", "72", "76", "73", "74",
            "81", "82",
            "91", "92", "93", "94", "95", "96",
            "LN"
    };


    // 30 Soal Ujian Nyata Iqra' Khusus per Jilid (Jilid 1 sampai Jilid 6, masing-masing 5 soal diacak!)
    // Format: [jilidIdx 0..5][soalIdx 0..4] = {soal, pilA, pilB, pilC, correctIdx, penjelasan}
    public static final String[][][] IQRA_EXAMS_BY_JILID = {
            // Jilid 1: Huruf Hijaiyah & Fathah
            {
                    {"Harakat baris di atas huruf hijaiyah yang berbunyi 'A, Ba, Ta' disebut apa?", "Fathah", "Kasrah", "Dhammah", "0", "Baris di atas adalah Fathah."},
                    {"Huruf mana yang keluar bersih dari tengah tenggorokan (tipis tanpa getar)?", "Ha kecil (ح)", "Kha (خ)", "Qaf (ق)", "0", "Ha kecil (ح) keluar bersih dari tengah tenggorokan."},
                    {"Berapa jumlah huruf hijaiyah pokok yang dipelajari di Iqra' Jilid 1?", "28 huruf", "15 huruf", "10 huruf", "0", "Ada 28 huruf hijaiyah pokok dari Alif sampai Ya."},
                    {"Huruf 'Tsa' (ث) dan 'Dza' (ذ) diucapkan dengan posisi lidah seperti apa?", "Ujung lidah sedikit menempel di ujung gigi seri atas", "Lidah ditarik jauh ke belakang", "Kedua bibir tertutup rapat", "0", "Tsa dan Dza keluar dari ujung lidah bertemu ujung gigi seri atas."},
                    {"Manakah pasangan huruf yang sama-sama keluar dari kedua bibir?", "Ba dan Mim", "Qaf dan Kaf", "Ha dan Ain", "0", "Ba dan Mim termasuk huruf Syafawiyah (keluar dari dua bibir)."}
            },
            // Jilid 2: Huruf Sambung & Mad Thabi'i
            {
                    {"Jika huruf berharakat Fathah diikuti Alif mati (seperti Qaa-la), dibaca berapa harakat?", "2 harakat (Mad Thabi'i)", "1 harakat pendek", "6 harakat", "0", "Mad Thabi'i dibaca pas 2 harakat (1 ayunan)."},
                    {"Manakah huruf yang TIDAK bisa menyambung ke huruf di sebelah kirinya?", "Dal, Dzal, Ra, Zay, Wawu, Alif", "Ba, Ta, Tsa", "Mim, Nun, Lam", "0", "Enam huruf itu hanya bisa disambung dari kanan."},
                    {"Pada kata 'Baa-ba', suku kata mana yang dibaca panjang 2 harakat?", "Suku pertama (Baa)", "Suku kedua (ba)", "Keduanya pendek", "0", "Suku pertama Baa diikuti Alif sehingga panjang 2 harakat."},
                    {"Kesalahan umum di Iqra' Jilid 2 saat membaca huruf tanpa Alif (pendek) adalah:", "Ikut memanjangkan huruf yang seharusnya pendek", "Membaca jelas 1 harakat", "Menjaga makhraj", "0", "Huruf tanpa tanda mad wajib dibaca pendek pas 1 harakat."},
                    {"Pada kata 'Kaa-na', mengapa 'Kaa' dibaca panjang 2 harakat?", "Karena Fathah diikuti Alif mati", "Karena ada Tasydid", "Karena huruf Qalqalah", "0", "Fathah bertemu Alif mati membentuk Mad Thabi'i 2 harakat."}
            },
            // Jilid 3: Harakat Kasrah (i) & Dhammah (u)
            {
                    {"Harakat baris di bawah huruf yang berbunyi vokal 'i' (Bi, Ti, Mi) disebut apa?", "Kasrah", "Fathah", "Sukun", "0", "Baris di bawah huruf disebut Kasrah."},
                    {"Bagaimana posisi bibir yang benar saat mengucapkan huruf berharakat Dhammah (Bu, Tu, Nu)?", "Membulat / monyong sempurna", "Tertutup rapat", "Melebar datar", "0", "Dhammah harus diucapkan dengan bibir membulat sempurna."},
                    {"Jika huruf berharakat Kasrah bertemu Ya sukun (seperti Fii / Dii-ni), dibaca bagaimana?", "Panjang 2 harakat (Mad Thabi'i)", "Dipantulkan", "Pendek cepat", "0", "Kasrah bertemu Ya sukun dibaca panjang 2 harakat."},
                    {"Jika huruf berharakat Dhammah bertemu Wawu sukun (seperti Yakuu-nu), dibaca berapa harakat?", "2 harakat", "1 harakat saja", "5 harakat", "0", "Dhammah diikuti Wawu sukun adalah Mad Thabi'i 2 harakat."},
                    {"Pada kata 'Ku-ti-ba', urutan harakat ketiga hurufnya adalah:", "Dhammah, Kasrah, Fathah", "Fathah, Fathah, Kasrah", "Kasrah, Dhammah, Fathah", "0", "Ku (Dhammah), ti (Kasrah), ba (Fathah)."}
            },
            // Jilid 4: Tanwin, Sukun & Qalqalah
            {
                    {"Harakat ganda yang menghasilkan bunyi 'an, in, un' di akhir kata disebut apa?", "Tanwin", "Tasydid", "Waqaf", "0", "Fathatain, Kasratain, dan Dhammatain disebut Tanwin."},
                    {"Manakah 5 huruf Qalqalah yang memantul saat berharakat Sukun?", "Ba, Jim, Dal, Tha, Qaf", "Sin, Syin, Shad, Dhad", "Alif, Wawu, Ya", "0", "Lima huruf Qalqalah disingkat Ba-Ju-Di-To-Qo."},
                    {"Pada bacaan 'Lam yalid wa lam yuulad', huruf Dal di akhir dibaca bagaimana?", "Memantul jelas (Qalqalah)", "Dengung 2 harakat", "Samar tanpa pantulan", "0", "Dal sukun adalah huruf Qalqalah sehingga wajib memantul."},
                    {"Tanda baca bulat kecil di atas huruf yang mematikan vokal huruf disebut apa?", "Sukun", "Tasydid", "Fathatain", "0", "Sukun menandakan huruf dibaca mati tanpa vokal."},
                    {"Manakah yang BUKAN termasuk bunyi Tanwin?", "Bunyi akhir 'ar / ir'", "Fathatain (an)", "Kasratain (in) dan Dhammatain (un)", "0", "Tanwin hanya berbunyi an, in, dan un."}
            },
            // Jilid 5: Tasydid, Waqaf & Hukum Nun Mati
            {
                    {"Huruf Nun Bertasydid (Inna) dan Mim Bertasydid (Tsumma) wajib dibaca bagaimana?", "Dengung ditahan 2 harakat (Ghunnah)", "Cepat tanpa dengung", "Memantul keras", "0", "Nun dan Mim bertasydid wajib Ghunnah 2 harakat."},
                    {"Jika Nun Mati bertemu huruf Mim atau Nun (seperti Min-ni'matin), hukum bacaannya adalah:", "Idgham Bighunnah (masuk berdengung)", "Idzhar Halqi", "Qalqalah Sughra", "0", "Nun Mati bertemu Ya, Nun, Mim, Wawu adalah Idgham Bighunnah."},
                    {"Saat berhenti (Waqaf) di akhir ayat yang berakhiran Fathatain (seperti 'Aliiman), bagaimana cara membacanya?", "Dibaca panjang 2 harakat 'Aliimaa (Mad Iwad)", "Tetap dibaca 'Aliiman", "Dimatikan jadi 'Aliim", "0", "Waqaf pada Fathatain dibaca Mad Iwad 2 harakat."},
                    {"Apa fungsi utama tanda Tasydid (bentuk seperti huruf w kecil) di atas suatu huruf?", "Menekan / menggandakan bacaan huruf tersebut", "Memanjangkan 6 harakat", "Menghilangkan hurufnya", "0", "Tasydid berarti huruf ganda: mati dulu lalu berharakat."},
                    {"Jika Nun Mati bertemu huruf Lam atau Ra (seperti Min rabbihim), hukum bacaannya adalah:", "Idgham Bilaghunnah (masuk tanpa dengung)", "Iqlab", "Ikhfa Hakiki", "0", "Nun Mati bertemu Lam dan Ra masuk tanpa dengung."}
            },
            // Jilid 6: Praktik Ayat Utuh & Tajwid Lanjutan
            {
                    {"Hukum Nun Mati bertemu huruf Ba (seperti Mim ba'di) yang mengubah bunyi Nun jadi Mim samar disebut:", "Iqlab", "Idzhar", "Ikhfa Syafawi", "0", "Nun Mati/Tanwin bertemu Ba adalah Iqlab."},
                    {"Hukum Mim Mati bertemu huruf Ba (seperti Tar-miihim bi-hijaarah) disebut:", "Ikhfa Syafawi (samar di bibir)", "Idgham Bilaghunnah", "Mad Aridh", "0", "Mim Mati bertemu Ba dibaca Ikhfa Syafawi 2 harakat."},
                    {"Setelah lulus Iqra' Jilid 6, santri siap penuh melanjutkan ke program utama apa?", "Tahfidz Al-Qur'an Juz 30 & 6 Surat Pilihan", "Kembali ke Jilid 1", "Berhenti belajar", "0", "Lulus Jilid 6 adalah gerbang resmi masuk Tahfidz Al-Qur'an!"},
                    {"Jika Nun Mati bertemu huruf tenggorokan seperti Ha, Kha, Ain, Ghain, hukumnya disebut:", "Idzhar Halqi (dibaca jelas tanpa dengung)", "Ikhfa Hakiki", "Qalqalah Kubra", "0", "Nun Mati bertemu 6 huruf tenggorokan dibaca jelas (Idzhar Halqi)."},
                    {"Jika Mad Thabi'i berada tepat sebelum huruf terakhir yang dimatikan saat waqaf (seperti Al-'Aalamiin), disebut:", "Mad Aridh Lissukun (2, 4, atau 6 harakat)", "Mad Iwad", "Idgham Mitslain", "0", "Mad sebelum huruf akhir yang diwaqafkan adalah Mad Aridh Lissukun."}
            }
    };

}
