package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Generator Dokumen Resmi Pondok Hafidz Netra (Suara Media Teknologi).
 * Menghasilkan seluruh surat resmi (KTS/KTM, SK PSB, Surat Izin/Sakit/Cuti,
 * Transkrip Rapor, Piagam Iqra', dan Syahadah) dalam 2 format sekaligus:
 * 1) Teks Resmi terstruktur (ramah Jieshuo/TalkBack & WhatsApp)
 * 2) Foto PNG ber-kop lembaga, bingkai ganda, stempel verifikasi, dan tanda tangan
 *    Ustadz Yeni Setiawan (Kepala Madrasah) & Ustadzah Nur (Kepala TU & Wali Kelas).
 */
public final class OfficialDocumentGenerator {

    private OfficialDocumentGenerator() {}

    public static final class GeneratedDocument {
        public final String title;
        public final String docNumber;
        public final String officialText;
        public final File pngFile;

        public GeneratedDocument(String title, String docNumber, String officialText, File pngFile) {
            this.title = title;
            this.docNumber = docNumber;
            this.officialText = officialText;
            this.pngFile = pngFile;
        }
    }

    public static GeneratedDocument generateBundle(Context context, String filePrefix, String docTitle,
                                                   String docNumber, List<String> bodyLines) {
        String text = buildOfficialText(docTitle, docNumber, bodyLines);
        File png = generateOfficialPngPhoto(context, filePrefix, docTitle, docNumber, bodyLines);
        return new GeneratedDocument(docTitle, docNumber, text, png);
    }

    public static String buildOfficialText(String docTitle, String docNumber, List<String> bodyLines) {
        String dateStr = new SimpleDateFormat("dd MMMM yyyy", new Locale("id", "ID")).format(new Date());
        StringBuilder sb = new StringBuilder();
        sb.append("========================================\n");
        sb.append(AppConfig.INSTITUTION_NAME).append("\n");
        sb.append(AppConfig.INSTITUTION_SUB).append("\n");
        sb.append(AppConfig.ACADEMIC_YEAR).append(" | ").append(AppConfig.COHORT_NAME).append("\n");
        sb.append("========================================\n\n");
        sb.append(docTitle == null ? "DOKUMEN RESMI PONDOK" : docTitle.toUpperCase(Locale.ROOT)).append("\n");
        sb.append("Nomor: ").append(docNumber == null ? "-" : docNumber).append("\n");
        sb.append("Tanggal: ").append(dateStr).append("\n\n");
        if (bodyLines != null) {
            for (String line : bodyLines) {
                if (line != null) sb.append(line).append("\n");
            }
        }
        sb.append("\nDisahkan secara resmi di Situbondo pada ").append(dateStr).append(":\n");
        sb.append("Kepala Madrasah: ").append(AppConfig.HEADMASTER_NAME).append("\n");
        sb.append("Kepala TU & Wali Kelas: ").append(AppConfig.WALI_TU_NAME).append("\n");
        sb.append("Kontak Lembaga: WA ").append(AppConfig.CONTACT_WHATSAPP);
        return sb.toString();
    }

    public static File generateOfficialPngPhoto(Context context, String filePrefix, String docTitle,
                                                String docNumber, List<String> bodyLines) {
        if (context == null) return null;
        final int width = 1080;
        final int height = 1520;
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);

        // Latar kertas piagam resmi
        c.drawColor(Color.parseColor("#FAF6EC"));

        // Bingkai luar Navy & bingkai dalam Emas
        Paint borderOuter = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderOuter.setStyle(Paint.Style.STROKE);
        borderOuter.setColor(Color.parseColor("#0D253F"));
        borderOuter.setStrokeWidth(14f);
        c.drawRect(28, 28, width - 28, height - 28, borderOuter);

        Paint borderInner = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderInner.setStyle(Paint.Style.STROKE);
        borderInner.setColor(Color.parseColor("#C59B27"));
        borderInner.setStrokeWidth(5f);
        c.drawRect(50, 50, width - 50, height - 50, borderInner);

        // Kop Lembaga
        Paint headerBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        headerBg.setColor(Color.parseColor("#0D253F"));
        c.drawRect(56, 56, width - 56, 268, headerBg);

        Paint pHead = new Paint(Paint.ANTI_ALIAS_FLAG);
        pHead.setColor(Color.parseColor("#FBBF24"));
        pHead.setTextSize(46f);
        pHead.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        pHead.setTextAlign(Paint.Align.CENTER);
        c.drawText(AppConfig.INSTITUTION_NAME, width / 2f, 134, pHead);

        Paint pSub = new Paint(Paint.ANTI_ALIAS_FLAG);
        pSub.setColor(Color.WHITE);
        pSub.setTextSize(25f);
        pSub.setTextAlign(Paint.Align.CENTER);
        c.drawText(AppConfig.INSTITUTION_SUB, width / 2f, 182, pSub);
        c.drawText(AppConfig.ACADEMIC_YEAR + "  |  " + AppConfig.COHORT_NAME, width / 2f, 226, pSub);

        // Judul & Nomor Surat
        String safeTitle = docTitle == null ? "DOKUMEN RESMI PONDOK" : docTitle.toUpperCase(Locale.ROOT);
        Paint pTitle = new Paint(Paint.ANTI_ALIAS_FLAG);
        pTitle.setColor(Color.parseColor("#0D253F"));
        pTitle.setTextSize(36f);
        pTitle.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        pTitle.setTextAlign(Paint.Align.CENTER);
        float titleY = 334f;
        for (String tLine : wrapDocText(safeTitle, pTitle, width - 160f)) {
            c.drawText(tLine, width / 2f, titleY, pTitle);
            titleY += 44f;
        }

        Paint pNum = new Paint(Paint.ANTI_ALIAS_FLAG);
        pNum.setColor(Color.parseColor("#78350F"));
        pNum.setTextSize(26f);
        pNum.setTextAlign(Paint.Align.CENTER);
        c.drawText("Nomor: " + (docNumber == null ? "-" : docNumber), width / 2f, titleY + 6f, pNum);

        Paint pLine = new Paint(Paint.ANTI_ALIAS_FLAG);
        pLine.setColor(Color.parseColor("#C59B27"));
        pLine.setStrokeWidth(4f);
        float lineY = titleY + 30f;
        c.drawLine(110, lineY, width - 110, lineY, pLine);

        // Isi Dokumen
        Paint pBody = new Paint(Paint.ANTI_ALIAS_FLAG);
        pBody.setColor(Color.parseColor("#1E293B"));
        pBody.setTextSize(29f);
        float y = lineY + 54f;
        float maxWidth = width - 180f;
        if (bodyLines != null) {
            for (String raw : bodyLines) {
                if (raw == null) continue;
                for (String wrapped : wrapDocText(raw, pBody, maxWidth)) {
                    if (y > 1150f) break;
                    c.drawText(wrapped, 90f, y, pBody);
                    y += 42f;
                }
                y += 8f;
            }
        }

        // Stempel Bulat Resmi
        Paint pStampOuter = new Paint(Paint.ANTI_ALIAS_FLAG);
        pStampOuter.setStyle(Paint.Style.STROKE);
        pStampOuter.setColor(Color.parseColor("#15803D"));
        pStampOuter.setStrokeWidth(5f);
        c.drawCircle(width / 2f, 1290f, 82f, pStampOuter);

        Paint pStampInner = new Paint(Paint.ANTI_ALIAS_FLAG);
        pStampInner.setStyle(Paint.Style.STROKE);
        pStampInner.setColor(Color.parseColor("#15803D"));
        pStampInner.setStrokeWidth(2f);
        c.drawCircle(width / 2f, 1290f, 70f, pStampInner);

        Paint pStampTxt = new Paint(Paint.ANTI_ALIAS_FLAG);
        pStampTxt.setColor(Color.parseColor("#15803D"));
        pStampTxt.setTextSize(19f);
        pStampTxt.setTypeface(Typeface.DEFAULT_BOLD);
        pStampTxt.setTextAlign(Paint.Align.CENTER);
        c.drawText("STEMPEL RESMI", width / 2f, 1278f, pStampTxt);
        c.drawText("TERVERIFIKASI", width / 2f, 1304f, pStampTxt);
        pStampTxt.setTextSize(15f);
        c.drawText("SUARA MEDIA", width / 2f, 1328f, pStampTxt);

        // Tanda Tangan Ganda (Ustadz Yeni Setiawan & Ustadzah Nur)
        String dateStr = new SimpleDateFormat("dd MMMM yyyy", new Locale("id", "ID")).format(new Date());
        Paint pSig = new Paint(Paint.ANTI_ALIAS_FLAG);
        pSig.setColor(Color.parseColor("#0D253F"));
        pSig.setTextSize(24f);
        pSig.setTextAlign(Paint.Align.CENTER);

        c.drawText("Situbondo, " + dateStr, 250f, 1225f, pSig);
        c.drawText("Kepala Madrasah", 250f, 1260f, pSig);
        pSig.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText(AppConfig.HEADMASTER_NAME, 250f, 1370f, pSig);

        pSig.setTypeface(Typeface.DEFAULT);
        c.drawText("Mengetahui,", width - 250f, 1225f, pSig);
        c.drawText("Kepala TU & Wali Kelas", width - 250f, 1260f, pSig);
        pSig.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText(AppConfig.WALI_TU_NAME, width - 250f, 1370f, pSig);

        // Footer Lembaga
        Paint pFoot = new Paint(Paint.ANTI_ALIAS_FLAG);
        pFoot.setColor(Color.parseColor("#475569"));
        pFoot.setTextSize(22f);
        pFoot.setTextAlign(Paint.Align.CENTER);
        c.drawText("Suara Media Teknologi — WA Lembaga: " + AppConfig.CONTACT_WHATSAPP, width / 2f, 1448f, pFoot);

        String safePrefix = (filePrefix == null || filePrefix.trim().isEmpty())
                ? "DOKUMEN_PONDOK"
                : filePrefix.replaceAll("[^a-zA-Z0-9_-]", "_");
        try {
            File outFile = new File(context.getCacheDir(), safePrefix + "_" + System.currentTimeMillis() + ".png");
            try (FileOutputStream fos = new FileOutputStream(outFile)) {
                bmp.compress(Bitmap.CompressFormat.PNG, 95, fos);
            }
            bmp.recycle();
            return outFile;
        } catch (Exception e) {
            bmp.recycle();
            return null;
        }
    }

    public static Intent buildShareIntent(Context context, GeneratedDocument doc) {
        Intent share = new Intent(Intent.ACTION_SEND);
        if (doc != null && doc.pngFile != null && doc.pngFile.exists()) {
            Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", doc.pngFile);
            share.setType("image/png");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_TEXT, doc.officialText);
            share.putExtra(Intent.EXTRA_SUBJECT, doc.title);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } else {
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, doc != null ? doc.officialText : "");
        }
        return Intent.createChooser(share, "Bagikan " + (doc != null ? doc.title : "Dokumen Resmi") + " (PNG + Teks)");
    }

    private static List<String> wrapDocText(String text, Paint paint, float maxWidth) {
        List<String> lines = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            lines.add("");
            return lines;
        }
        String[] words = text.split("\\s+");
        StringBuilder cur = new StringBuilder();
        for (String w : words) {
            String test = cur.length() == 0 ? w : cur + " " + w;
            if (paint.measureText(test) <= maxWidth) {
                cur = new StringBuilder(test);
            } else {
                if (cur.length() > 0) lines.add(cur.toString());
                cur = new StringBuilder(w);
            }
        }
        if (cur.length() > 0) lines.add(cur.toString());
        return lines;
    }
}
