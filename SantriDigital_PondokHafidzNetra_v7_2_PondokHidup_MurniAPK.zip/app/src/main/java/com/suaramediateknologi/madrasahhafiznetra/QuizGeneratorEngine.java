package com.suaramediateknologi.madrasahhafiznetra;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class QuizGeneratorEngine {
    public static class SambungQuestion {
        public QuranRepository.AyahItem promptAyah;
        public QuranRepository.AyahItem correctNextAyah;
        public List<QuranRepository.AyahItem> options = new ArrayList<>();
        public int correctOptionIndex;
        public String mutasyabihatWarning;
    }

    public static class TajwidEarQuestion {
        public String promptText;
        public int surahNo;
        public int ayahNo;
        public String[] choices;
        public int correctIndex;
        public String explanation;
    }

    public static class KitabQuestion {
        public String question;
        public String[] choices;
        public int correctIndex;
        public String explanation;
    }

    public static class TebakSuratQuestion {
        public int surahNo;
        public int ayahNo;
        public String[] choices;
        public int correctIndex;
    }

    private final Random random = new Random();

    public SambungQuestion generateSambungAyat(List<QuranRepository.AyahItem> surahAyahs, int optionCount) {
        if (surahAyahs == null || surahAyahs.size() < 2) return null;
        int promptIdx = random.nextInt(surahAyahs.size() - 1);
        QuranRepository.AyahItem prompt = surahAyahs.get(promptIdx);
        QuranRepository.AyahItem answer = surahAyahs.get(promptIdx + 1);

        SambungQuestion q = new SambungQuestion();
        q.promptAyah = prompt;
        q.correctNextAyah = answer;
        q.options.add(answer);

        List<QuranRepository.AyahItem> pool = new ArrayList<>();
        for (int i = 0; i < surahAyahs.size(); i++) {
            if (i != promptIdx && i != promptIdx + 1) pool.add(surahAyahs.get(i));
        }
        Collections.shuffle(pool, random);
        int needed = Math.min(Math.max(2, optionCount) - 1, pool.size());
        for (int i = 0; i < needed; i++) q.options.add(pool.get(i));
        Collections.shuffle(q.options, random);
        q.correctOptionIndex = q.options.indexOf(answer);
        q.mutasyabihatWarning = checkMutasyabihatWarning(prompt.surahNo, prompt.nomorAyat);
        return q;
    }

    public TebakSuratQuestion generateTebakSuratQuiz(int unlockedJuz30Count) {
        int maxIdx = Math.max(3, Math.min(unlockedJuz30Count, AppConfig.JUZ30_REVERSED_NUMS.length));
        int pickIdx = random.nextInt(maxIdx);
        TebakSuratQuestion q = new TebakSuratQuestion();
        q.surahNo = AppConfig.JUZ30_REVERSED_NUMS[pickIdx];
        q.ayahNo = 1;

        List<String> opts = new ArrayList<>();
        String correctName = AppConfig.JUZ30_REVERSED_NAMES[pickIdx];
        opts.add(correctName);
        List<String> pool = new ArrayList<>();
        for (int i = 0; i < AppConfig.JUZ30_REVERSED_NAMES.length; i++) {
            if (i != pickIdx) pool.add(AppConfig.JUZ30_REVERSED_NAMES[i]);
        }
        Collections.shuffle(pool, random);
        opts.add(pool.get(0));
        opts.add(pool.get(1));
        Collections.shuffle(opts, random);
        q.choices = opts.toArray(new String[0]);
        q.correctIndex = opts.indexOf(correctName);
        return q;
    }

    public KitabQuestion generateKitabQuiz() {
        List<KitabQuestion> bank = new ArrayList<>();

        KitabQuestion k1 = new KitabQuestion();
        k1.question = "Menurut Kitab Safinatun Najah, berapakah jumlah fardhu (rukun) wudhu?";
        k1.choices = new String[]{"Empat rukun", "Enam rukun", "Tujuh rukun"};
        k1.correctIndex = 1;
        k1.explanation = "Benar! Rukun wudhu ada enam: niat, membasuh wajah, membasuh kedua tangan hingga siku, mengusap sebagian kepala, membasuh kaki hingga mata kaki, dan tertib.";
        bank.add(k1);

        KitabQuestion k2 = new KitabQuestion();
        k2.question = "Manakah di bawah ini yang termasuk perkara membatalkan wudhu menurut Safinatun Najah?";
        k2.choices = new String[]{"Makan makanan manis", "Tidur dengan duduk tidak mantap", "Berbicara setelah wudhu"};
        k2.correctIndex = 1;
        k2.explanation = "Tepat! Hilangnya akal karena tidur yang tidak mantap duduknya membatalkan wudhu.";
        bank.add(k2);

        KitabQuestion k3 = new KitabQuestion();
        k3.question = "Dalam Kitab Aqidatul Awam, apa arti sifat wajib Allah 'Qidam'?";
        k3.choices = new String[]{"Terdahulu tanpa permulaan", "Maha Mendengar", "Kekal selamanya"};
        k3.correctIndex = 0;
        k3.explanation = "MasyaAllah benar! Qidam artinya Allah Maha Terdahulu tanpa ada permulaan.";
        bank.add(k3);

        KitabQuestion k4 = new KitabQuestion();
        k4.question = "Berapakah jumlah rukun shalat menurut matan Kitab Safinatun Najah?";
        k4.choices = new String[]{"Sepuluh rukun", "Tujuh belas rukun", "Dua puluh rukun"};
        k4.correctIndex = 1;
        k4.explanation = "Benar! Rukun shalat dalam Safinatun Najah berjumlah tujuh belas rukun.";
        bank.add(k4);

        return bank.get(random.nextInt(bank.size()));
    }

    public TajwidEarQuestion generateTajwidEarQuiz() {
        List<TajwidEarQuestion> bank = new ArrayList<>();
        TajwidEarQuestion q1 = new TajwidEarQuestion();
        q1.promptText = "Dengarkan akhir Surat Al-Falaq ayat 1. Hukum bacaan apakah pada huruf Qaf di akhir ayat?";
        q1.surahNo = 113; q1.ayahNo = 1;
        q1.choices = new String[]{"Qalqalah Kubra (Pantulan kuat)", "Idzhar Halqi", "Iqlab"};
        q1.correctIndex = 0;
        q1.explanation = "Benar! Huruf Qaf di akhir Al-Falaq dibaca memantul kuat (Qalqalah Kubra).";
        bank.add(q1);

        TajwidEarQuestion q2 = new TajwidEarQuestion();
        q2.promptText = "Dengarkan Surat An-Nas ayat 1 pada kata An-Nas. Hukum dengung apakah pada huruf Nun bertasydid?";
        q2.surahNo = 114; q2.ayahNo = 1;
        q2.choices = new String[]{"Mad Thabi'i", "Ghunnah Musyaddadah (Dengung 2 harakat)", "Qalqalah Sughra"};
        q2.correctIndex = 1;
        q2.explanation = "Tepat! Nun atau Mim bertasydid dibaca mendengung dua harakat (Ghunnah Musyaddadah).";
        bank.add(q2);

        TajwidEarQuestion q3 = new TajwidEarQuestion();
        q3.promptText = "Dengarkan Surat Al-Ikhlas ayat 1 pada kata Ahad. Hukum apakah saat berhenti di huruf Dal?";
        q3.surahNo = 112; q3.ayahNo = 1;
        q3.choices = new String[]{"Ikhfa Haqiqi", "Idgham Bilaghunnah", "Qalqalah Kubra (Pantulan Dal)"};
        q3.correctIndex = 2;
        q3.explanation = "MasyaAllah tepat! Huruf Dal memantul jelas saat berhenti di akhir ayat.";
        bank.add(q3);

        return bank.get(random.nextInt(bank.size()));
    }

    public String getFirstWordHint(QuranRepository.AyahItem ayah) {
        if (ayah == null) return "";
        String clean = QuranRepository.cleanLatinForTts(ayah.teksLatin);
        String[] parts = clean.split("\\s+");
        return parts.length >= 2 ? (parts[0] + " " + parts[1]) : clean;
    }

    public String analyzeTajwidLisan(QuranRepository.AyahItem ayah) {
        if (ayah == null) return "Pilih ayat terlebih dahulu.";
        String arab = ayah.teksArab != null ? ayah.teksArab : "";
        String latin = QuranRepository.cleanLatinForTts(ayah.teksLatin).toLowerCase();
        StringBuilder sb = new StringBuilder();
        sb.append("Bedah Tajwid Lisan Surat ").append(ayah.surahName).append(" ayat ").append(ayah.nomorAyat).append(". ");
        int found = 0;
        if (arab.contains("نّ") || arab.contains("مّ")) {
            sb.append("Terdapat Ghunnah Musyaddadah pada Nun atau Mim bertasydid, tahan dengung dua harakat. ");
            found++;
        }
        if (latin.contains("q") || arab.contains("قْ") || arab.contains("طْ") || arab.contains("بْ") || arab.contains("جْ") || arab.contains("دْ")) {
            sb.append("Perhatikan pantulan Qalqalah pada huruf Qaf, Tha, Ba, Jim, atau Dal yang disukun atau diwakafkan. ");
            found++;
        }
        if (arab.contains("ۤ") || arab.contains("ٓ")) {
            sb.append("Terdapat tanda Mad panjang empat sampai enam harakat. ");
            found++;
        }
        if (found == 0) sb.append("Jaga ketepatan makhraj huruf dan panjang Mad Thabi'i dua harakat.");
        return sb.toString();
    }

    public String checkMutasyabihatWarning(int surahNo, int ayahNo) {
        if (surahNo == 109 && (ayahNo >= 2 && ayahNo <= 5)) return "Radar Mutasyabihat: Perhatikan perbedaan ayat 3 dan ayat 5 Surat Al-Kafirun.";
        if (surahNo == 55) return "Radar Mutasyabihat: Surat Ar-Rahman sering mengulang Fabiayyi ala i rabbikuma tukadziban.";
        if (surahNo == 77) return "Radar Mutasyabihat: Surat Al-Mursalat memiliki pengulangan Wailuy yaumaidzil lil mukadzibin.";
        return "";
    }

    public int calculateSpeechSimilarityPercent(String spokenArabic, String targetArabic) {
        String a = normalizeArabic(spokenArabic);
        String b = normalizeArabic(targetArabic);
        if (a.isEmpty() || b.isEmpty()) return 0;
        String[] wordsA = a.split("\\s+");
        String[] wordsB = b.split("\\s+");
        int matched = 0;
        for (String wb : wordsB) {
            for (String wa : wordsA) {
                if (wa.equals(wb) || (wa.length() > 2 && wb.contains(wa)) || (wb.length() > 2 && wa.contains(wb))) {
                    matched++;
                    break;
                }
            }
        }
        return Math.min(100, (int) Math.round((matched * 100.0) / wordsB.length));
    }

    private String normalizeArabic(String input) {
        if (input == null) return "";
        String noDiacritics = input.replaceAll("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]", "");
        noDiacritics = noDiacritics.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
                .replace("ة", "ه").replace("ى", "ي");
        return noDiacritics.replaceAll("[^\\u0621-\\u064A\\s]", "").replaceAll("\\s+", " ").trim();
    }
}
