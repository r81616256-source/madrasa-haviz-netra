package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Mesin Profil Santri, Tata Tertib, Rapor Otomatis, & Disiplin Nyata (v6.0).
 * - Evaluasi SP menghormati hari Ahad, Tanggal Merah, Cuti Resmi, dan Kartu Pelindung SP.
 * - Ta'zir Nyata: SP tidak bisa hilang 1 klik, wajib menyelesaikan target murajaah/setoran
 *   atau menukar Kartu Pelindung SP di Loket 5 TU.
 */
public class LivingMadrasahEngine {
    public static final String STATUS_BARU = "BARU";
    public static final String STATUS_DILANCARKAN = "DILANCARKAN";
    public static final String STATUS_LANCAR = "LANCAR";
    private static final String KEY_TAZIR_REQUIRED_COUNT = "v6_tazir_req_cnt";
    private static final String KEY_TAZIR_DONE_COUNT = "v6_tazir_done_cnt";

    private final SharedPreferences prefs;
    private final MadrasahDbHelper db;
    private final SchoolScheduleEngine schedule;
    private final PesantrenWorldEngine world;

    public LivingMadrasahEngine(Context context, MadrasahDbHelper db) {
        Context appCtx = context.getApplicationContext();
        this.prefs = appCtx.getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
        this.db = db;
        this.schedule = new SchoolScheduleEngine(appCtx);
        this.world = new PesantrenWorldEngine(appCtx);
        resetDailyIfNewDayAndCheckDiscipline();
    }

    private String todayStr() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    private String nowTimeStr() {
        return new SimpleDateFormat("HH:mm", Locale.US).format(new Date());
    }

    private void resetDailyIfNewDayAndCheckDiscipline() {
        String today = todayStr();
        if (!today.equals(prefs.getString(AppConfig.KEY_MISSION_DATE, ""))) {
            prefs.edit()
                    .putString(AppConfig.KEY_MISSION_DATE, today)
                    .putBoolean(AppConfig.KEY_MISSION_ZIYADAH, false)
                    .putBoolean(AppConfig.KEY_MISSION_TASMI, false)
                    .putBoolean(AppConfig.KEY_MISSION_MURAJAAH, false)
                    .apply();
        }
        if (!today.equals(prefs.getString(AppConfig.KEY_ATTENDANCE_TODAY_DATE, ""))) {
            if (isRegistered() && !schedule.isHolidayToday() && !schedule.isOnCuti()) {
                int missedDays = getDaysSinceLastActive();
                if (missedDays >= 2) {
                    if (world.usePelindungSpIfAvailable()) {
                        appendDailyLog("Kartu Pelindung SP otomatis melindungi statusmu dari SP hari ini.");
                    } else if (missedDays >= 4) {
                        prefs.edit()
                                .putInt(AppConfig.KEY_SP_LEVEL, 3)
                                .putBoolean(AppConfig.KEY_TAZIR_PENDING, true)
                                .putInt(KEY_TAZIR_REQUIRED_COUNT, 3)
                                .putInt(KEY_TAZIR_DONE_COUNT, 0)
                                .apply();
                        schedule.recordAttendanceStatus("ALFA");
                        appendDailyLog("SKORSING SEMENTARA: Alfa " + (missedDays - 1) + " hari tanpa izin resmi. Wajib Ta'zir 3 ayat.");
                    } else if (missedDays == 3) {
                        prefs.edit()
                                .putInt(AppConfig.KEY_SP_LEVEL, 2)
                                .putBoolean(AppConfig.KEY_TAZIR_PENDING, true)
                                .putInt(KEY_TAZIR_REQUIRED_COUNT, 2)
                                .putInt(KEY_TAZIR_DONE_COUNT, 0)
                                .apply();
                        schedule.recordAttendanceStatus("ALFA");
                        appendDailyLog("SP-2 + Ta'zir: Alfa 2 hari berturut-turut. Wajib Ta'zir 2 ayat.");
                    } else {
                        prefs.edit()
                                .putInt(AppConfig.KEY_SP_LEVEL, 1)
                                .putInt(KEY_TAZIR_REQUIRED_COUNT, 1)
                                .putInt(KEY_TAZIR_DONE_COUNT, 0)
                                .apply();
                        schedule.recordAttendanceStatus("ALFA");
                        appendDailyLog("SP-1: Alfa 1 hari tanpa izin. Wajib setor 1 ayat pemulihan.");
                    }
                }
            }
            prefs.edit()
                    .putString(AppConfig.KEY_ATTENDANCE_TODAY_DATE, today)
                    .putString(AppConfig.KEY_ATTENDANCE_TODAY_STATUS, "NONE")
                    .putString(AppConfig.KEY_ATTENDANCE_LEAVE_REASON, "")
                    .apply();
        }
    }

    // ================= TA'ZIR NYATA (TIDAK BISA HAPUS SP 1 KLIK) =================
    public int getTazirRequiredCount() {
        return getSpLevel() <= 0 ? 0 : Math.max(1, prefs.getInt(KEY_TAZIR_REQUIRED_COUNT, getSpLevel()));
    }

    public int getTazirDoneCount() {
        return prefs.getInt(KEY_TAZIR_DONE_COUNT, 0);
    }

    public boolean recordTazirProgress() {
        if (getSpLevel() <= 0) return false;
        int done = getTazirDoneCount() + 1;
        int req = getTazirRequiredCount();
        prefs.edit().putInt(KEY_TAZIR_DONE_COUNT, done).apply();
        if (done >= req) {
            clearSanctionsAfterRecovery();
            return true;
        }
        return false;
    }

    public boolean canClearSanctionNow() {
        return getSpLevel() <= 0 || getTazirDoneCount() >= getTazirRequiredCount();
    }

    public void clearSanctionsAfterRecovery() {
        prefs.edit()
                .putInt(AppConfig.KEY_SP_LEVEL, 0)
                .putBoolean(AppConfig.KEY_TAZIR_PENDING, false)
                .putInt(KEY_TAZIR_REQUIRED_COUNT, 0)
                .putInt(KEY_TAZIR_DONE_COUNT, 0)
                .putLong(AppConfig.KEY_LAST_ACTIVE_MS, System.currentTimeMillis())
                .apply();
        appendDailyLog("Lulus Sidang Pemulihan / Ta'zir! Status Santri AKTIF bersih kembali.");
    }

    // ================= STATUS PENDAFTARAN, BIODATA & GENDER =================
    public boolean isRegistered() { return !getSantriNis().isEmpty(); }
    public String getSantriName() { String n = prefs.getString(AppConfig.KEY_SANTRI_NAME, "").trim(); return n.isEmpty() ? "Calon Santri" : n; }
    public String getSantriCity() { return prefs.getString(AppConfig.KEY_SANTRI_CITY, "Indonesia"); }
    public String getSantriWali() { return prefs.getString(AppConfig.KEY_SANTRI_WALI, "Keluarga / Wali"); }
    public String getSantriNis() { return prefs.getString(AppConfig.KEY_SANTRI_NIS, "").trim(); }
    public int getSantriTrack() { return prefs.getInt(AppConfig.KEY_SANTRI_TRACK, 0); }
    public int getClassSlot() { return prefs.getInt(AppConfig.KEY_CLASS_SLOT, 2); }
    public int getSpLevel() { return prefs.getInt(AppConfig.KEY_SP_LEVEL, 0); }
    public boolean isSuspended() { return getSpLevel() >= 3; }
    public boolean isTazirPending() { return prefs.getBoolean(AppConfig.KEY_TAZIR_PENDING, false); }

    public int getGender() { return prefs.getInt(AppConfig.KEY_GENDER, 1); } // 0=Putra, 1=Putri
    public boolean isPutri() { return getGender() == 1; }
    public String getGenderLabel() { return isPutri() ? "Santri Putri" : "Santri Putra"; }
    public String getPengasuhUtama() { return isPutri() ? "Ustadzah Nur" : "Ustadz Yeni Setiawan"; }
    public String getPembimbingKamar() { return isPutri() ? "Ibu Nyai Aminah" : "Kak Bilal"; }
    public int getResidenceMode() { return prefs.getInt(AppConfig.KEY_RESIDENCE, 0); }
    public boolean isSantriKalong() { return getResidenceMode() == 1; }
    public int getTransportMode() { return prefs.getInt(AppConfig.KEY_TRANSPORT, 0); }
    public String getTransportLabel() {
        int t = Math.max(0, Math.min(getTransportMode(), AppConfig.TRANSPORT_LABELS.length - 1));
        return AppConfig.TRANSPORT_LABELS[t];
    }
    public String getProvince() { return prefs.getString(AppConfig.KEY_PROVINCE, AppConfig.PROVINCES_LIST[0]); }
    public int getJenjangIndex() { return prefs.getInt(AppConfig.KEY_JENJANG, 0); }
    public String getJenjangLabel() {
        int j = Math.max(0, Math.min(getJenjangIndex(), AppConfig.JENJANG_LABELS.length - 1));
        return AppConfig.JENJANG_LABELS[j];
    }
    public boolean isMahadAly() { return getJenjangIndex() >= 3; }
    public int getJalurIndex() { return prefs.getInt(AppConfig.KEY_JALUR, 1); }
    public String getJalurLabel() {
        int j = Math.max(0, Math.min(getJalurIndex(), AppConfig.JALUR_LABELS.length - 1));
        return AppConfig.JALUR_LABELS[j];
    }
    public String getBirthdateMmDd() { return prefs.getString(AppConfig.KEY_BIRTHDATE_MMDD, "").trim(); }
    public boolean isBirthdayToday() {
        String bd = getBirthdateMmDd();
        if (bd.length() != 5 || bd.charAt(2) != '-') return false;
        Calendar cal = Calendar.getInstance();
        String today = String.format(Locale.US, "%02d-%02d",
                cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
        return bd.equals(today);
    }
    public int getTargetHarian() { return prefs.getInt(AppConfig.KEY_TARGET_HARIAN, 5); }
    public int getMahadSks() { return prefs.getInt(AppConfig.KEY_MAHAD_SKS, 0); }
    public void addMahadSks(int delta) { prefs.edit().putInt(AppConfig.KEY_MAHAD_SKS, getMahadSks() + delta).apply(); }
    public boolean isDay1AdaptationDone() { return isAllTaarufDone(); }
    public void markDay1AdaptationDone() { prefs.edit().putBoolean(AppConfig.KEY_DAY1_ADAPTATION_DONE, true).apply(); }
    public String getGenderedRoomName() {
        int idx = Math.abs(getSantriName().hashCode()) % 3;
        return isPutri() ? AppConfig.PUTRI_ROOMS[idx] : AppConfig.PUTRA_ROOMS[idx];
    }

    public void saveSantriRegistration(String name, String city, String wali, String nis, int trackIndex, int classSlot) {
        int safeTrack = Math.max(0, Math.min(trackIndex, AppConfig.REGISTRATION_TRACKS.length - 1));
        int safeSlot = Math.max(0, Math.min(classSlot, AppConfig.CLASS_SLOTS.length - 1));
        int initLevel = (safeTrack == 2) ? 3 : ((safeTrack == 1) ? 1 : 0);
        int initJuz30 = (safeTrack == 2) ? 37 : ((safeTrack == 1) ? 3 : 1);
        int defaultSurah = (safeTrack == 2) ? 67 : 114;
        prefs.edit()
                .putString(AppConfig.KEY_SANTRI_NAME, name.trim())
                .putString(AppConfig.KEY_SANTRI_CITY, city == null ? "" : city.trim())
                .putString(AppConfig.KEY_SANTRI_WALI, (wali == null || wali.trim().isEmpty()) ? "Keluarga" : wali.trim())
                .putString(AppConfig.KEY_SANTRI_NIS, nis.trim())
                .putString(AppConfig.KEY_SANTRI_JOIN_DATE, new SimpleDateFormat("dd MMM yyyy", new Locale("id", "ID")).format(new Date()))
                .putInt(AppConfig.KEY_SANTRI_TRACK, safeTrack)
                .putInt(AppConfig.KEY_CLASS_SLOT, safeSlot)
                .putBoolean(AppConfig.KEY_RULES_AGREED, true)
                .putInt(AppConfig.KEY_SP_LEVEL, 0)
                .putBoolean(AppConfig.KEY_TAZIR_PENDING, false)
                .putInt(AppConfig.KEY_UNLOCKED_MAX_LEVEL, initLevel)
                .putInt(AppConfig.KEY_CURRENT_LEVEL, initLevel)
                .putInt(AppConfig.KEY_JUZ30_UNLOCKED_COUNT, initJuz30)
                .putInt(AppConfig.KEY_KITAB_UNLOCKED_COUNT, 1)
                .putInt(AppConfig.KEY_GRADE_KELANCARAN, 75)
                .putInt(AppConfig.KEY_GRADE_DINIYAH, 75)
                .putInt(AppConfig.KEY_GRADE_UJIAN, 75)
                .putLong(AppConfig.KEY_LAST_ACTIVE_MS, System.currentTimeMillis())
                .apply();
        setFocusBlock(defaultSurah, 1, 3);
        appendDailyLog("Resmi dilantik (" + nis + ") — " + AppConfig.CLASS_SLOTS[safeSlot]);
    }

    public void saveExpandedRegistration(String name, String city, String province, String wali, String nis,
                                         int gender, int residence, int transport, int jenjang, int jalur,
                                         int classSlot, String birthdateMmDd, int targetHarian) {
        saveSantriRegistration(name, city, wali, nis, Math.min(jalur, 2), classSlot);
        prefs.edit()
                .putInt(AppConfig.KEY_GENDER, gender)
                .putInt(AppConfig.KEY_RESIDENCE, residence)
                .putInt(AppConfig.KEY_TRANSPORT, transport)
                .putString(AppConfig.KEY_PROVINCE, province == null ? AppConfig.PROVINCES_LIST[0] : province)
                .putInt(AppConfig.KEY_JENJANG, jenjang)
                .putInt(AppConfig.KEY_JALUR, jalur)
                .putString(AppConfig.KEY_BIRTHDATE_MMDD, birthdateMmDd == null ? "" : birthdateMmDd.trim())
                .putInt(AppConfig.KEY_TARGET_HARIAN, Math.max(3, targetHarian))
                .putBoolean(AppConfig.KEY_DAY1_ADAPTATION_DONE, false)
                .apply();
    }

    // ================= RAPOR OTOMATIS 0-100 =================
    public int getKelancaranScore() { return prefs.getInt(AppConfig.KEY_GRADE_KELANCARAN, 75); }
    public int getDiniyahScore() { return prefs.getInt(AppConfig.KEY_GRADE_DINIYAH, 75); }
    public int getUjianScore() { return prefs.getInt(AppConfig.KEY_GRADE_UJIAN, 75); }

    public int getDisiplinScore() {
        int attPct = schedule.getMonthlyAttendancePercent();
        int spPenalty = getSpLevel() * 15;
        return Math.max(40, Math.min(100, attPct - spPenalty));
    }

    public int getFinalGrade() {
        return (int) Math.round(getKelancaranScore() * 0.40 + getDiniyahScore() * 0.25 + getDisiplinScore() * 0.20 + getUjianScore() * 0.15);
    }

    public String getPredikat() {
        int g = getFinalGrade();
        if (g >= 90) return "Mumtaz";
        if (g >= 80) return "Jayyid Jiddan";
        if (g >= 70) return "Jayyid";
        return "Maqbul (Perlu Bimbingan)";
    }

    public void boostGrade(String key, int delta) {
        int cur = prefs.getInt(key, 75);
        prefs.edit().putInt(key, Math.max(40, Math.min(100, cur + delta))).apply();
    }

    public String getSpStatusText() {
        int sp = getSpLevel();
        if (sp >= 3) return "SKORSING SEMENTARA (Wajib Ta'zir " + getTazirDoneCount() + "/" + getTazirRequiredCount() + " ayat)";
        if (sp == 2) return "SP-2 + Ta'zir (" + getTazirDoneCount() + "/" + getTazirRequiredCount() + " ayat)";
        if (sp == 1) return "SP-1 (Pemulihan " + getTazirDoneCount() + "/" + getTazirRequiredCount() + " ayat)";
        return (prefs.getInt(AppConfig.KEY_STREAK_DAYS, 0) >= 7) ? "SANTRI TELADAN BEBAS SP" : "Aman / Disiplin";
    }

    // ================= PIKET, ABSENSI SINKRON & ARWAH =================
    private String currentWeekId() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.YEAR) + "-W" + c.get(Calendar.WEEK_OF_YEAR);
    }

    public boolean isPiketDoneThisWeek() { return currentWeekId().equals(prefs.getString(AppConfig.KEY_PIKET_WEEK, "")); }

    public void completePiketThisWeek() {
        if (isPiketDoneThisWeek()) return;
        prefs.edit().putString(AppConfig.KEY_PIKET_WEEK, currentWeekId()).apply();
        addXp(40);
        boostGrade(AppConfig.KEY_GRADE_DINIYAH, 5);
        appendDailyLog("Menuntaskan Piket Khidmah Pekanan (+40 XP).");
    }

    public String getAttendanceTodayStatus() { return prefs.getString(AppConfig.KEY_ATTENDANCE_TODAY_STATUS, "NONE"); }

    public void markHadirToday(String reflection) {
        markHadirTodayWithType("HADIR", reflection);
    }

    public void markHadirTodayWithType(String statusType, String reflection) {
        String safeStatus = (statusType == null || statusType.isEmpty()) ? "HADIR" : statusType;
        int totalHadir = prefs.getInt(AppConfig.KEY_TOTAL_HADIR, 0);
        int streak = prefs.getInt(AppConfig.KEY_STREAK_DAYS, 0);
        if ("NONE".equals(getAttendanceTodayStatus())) {
            totalHadir++;
            streak++;
            addXp("HADIR".equals(safeStatus) ? 15 : 10);
        }
        prefs.edit()
                .putString(AppConfig.KEY_ATTENDANCE_TODAY_DATE, todayStr())
                .putString(AppConfig.KEY_ATTENDANCE_TODAY_STATUS, safeStatus)
                .putInt(AppConfig.KEY_TOTAL_HADIR, totalHadir)
                .putInt(AppConfig.KEY_STREAK_DAYS, streak)
                .putLong(AppConfig.KEY_LAST_ACTIVE_MS, System.currentTimeMillis())
                .putString(AppConfig.KEY_REFLECTION_TODAY, reflection == null ? "" : reflection)
                .apply();
        schedule.recordAttendanceStatus(safeStatus);
        db.recordAttendanceToday();
        appendDailyLog("Absen " + safeStatus + " (" + reflection + ").");
    }

    public void markIzinToday(String reason) {
        int totalIzin = prefs.getInt(AppConfig.KEY_TOTAL_IZIN, 0);
        if (!"IZIN".equals(getAttendanceTodayStatus())) totalIzin++;
        prefs.edit()
                .putString(AppConfig.KEY_ATTENDANCE_TODAY_DATE, todayStr())
                .putString(AppConfig.KEY_ATTENDANCE_TODAY_STATUS, "IZIN")
                .putString(AppConfig.KEY_ATTENDANCE_LEAVE_REASON, reason)
                .putInt(AppConfig.KEY_TOTAL_IZIN, totalIzin)
                .putLong(AppConfig.KEY_LAST_ACTIVE_MS, System.currentTimeMillis())
                .apply();
        schedule.recordAttendanceStatus("IZIN");
        appendDailyLog("Izin Resmi (" + reason + "). Aman dari SP.");
    }

    public int getDaysSinceLastActive() {
        long last = prefs.getLong(AppConfig.KEY_LAST_ACTIVE_MS, 0L);
        return last == 0L ? 0 : (int) Math.max(0, (System.currentTimeMillis() - last) / (24L * 60L * 60L * 1000L));
    }

    public int getJuz30UnlockedCount() {
        return Math.max(1, Math.min(AppConfig.JUZ30_REVERSED_NUMS.length, prefs.getInt(AppConfig.KEY_JUZ30_UNLOCKED_COUNT, 1)));
    }

    public boolean unlockNextJuz30Surah() {
        int cur = getJuz30UnlockedCount();
        if (cur < AppConfig.JUZ30_REVERSED_NUMS.length) {
            prefs.edit().putInt(AppConfig.KEY_JUZ30_UNLOCKED_COUNT, cur + 1).apply();
            appendDailyLog("Terbuka surat baru Juz 30: " + AppConfig.JUZ30_REVERSED_NAMES[cur]);
            return true;
        }
        return false;
    }

    public void setFocusBlock(int surahNo, int startAyah, int endAyah) {
        int s = Math.max(1, startAyah);
        int e = Math.max(s, endAyah);
        prefs.edit().putInt(AppConfig.KEY_FOCUS_SURAH, surahNo).putInt(AppConfig.KEY_FOCUS_START, s).putInt(AppConfig.KEY_FOCUS_END, e)
                .putString(AppConfig.KEY_FOCUS_STATUS, STATUS_BARU).putLong(AppConfig.KEY_FOCUS_START_MS, System.currentTimeMillis()).apply();
    }

    public List<String> getLocalArwahList() {
        List<String> list = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString(AppConfig.KEY_ARWAH_LIST_JSON, "[]"));
            for (int i = 0; i < arr.length(); i++) list.add(arr.getString(i));
        } catch (Exception ignored) {}
        return list;
    }

    public void appendDailyLog(String entry) {
        try {
            JSONArray arr = new JSONArray(prefs.getString(AppConfig.KEY_DAILY_LOG_JSON, "[]"));
            arr.put(nowTimeStr() + " WIB — " + entry);
            JSONArray trimmed = new JSONArray();
            for (int i = Math.max(0, arr.length() - 20); i < arr.length(); i++) trimmed.put(arr.getString(i));
            prefs.edit().putString(AppConfig.KEY_DAILY_LOG_JSON, trimmed.toString()).apply();
        } catch (Exception ignored) {}
    }

    public int getXpPoints() { return prefs.getInt(AppConfig.KEY_XP_POINTS, 0); }
    public void addXp(int amount) { prefs.edit().putInt(AppConfig.KEY_XP_POINTS, Math.max(0, getXpPoints() + amount)).apply(); }
    public int getCurrentLevel() { return prefs.getInt(AppConfig.KEY_CURRENT_LEVEL, 0); }
    public int getProgramMode() { return prefs.getInt(AppConfig.KEY_PROGRAM_MODE, 0); }

    public String buildExpandedBiodataSummary() {
        return "Nama: " + getSantriName() + " (" + getGenderLabel() + ")\n"
                + "NIS / NIM: " + (getSantriNis().isEmpty() ? "Belum Terdaftar" : getSantriNis()) + "\n"
                + "Asal Daerah: " + getSantriCity() + " — " + getProvince() + "\n"
                + "Jenjang: " + getJenjangLabel() + (isMahadAly() ? " | SKS: " + getMahadSks() : "") + "\n"
                + "Jalur: " + getJalurLabel() + " | Jam Kelas: " + AppConfig.CLASS_SLOTS[Math.max(0, Math.min(getClassSlot(), AppConfig.CLASS_SLOTS.length - 1))] + "\n"
                + "Hunian: " + (isSantriKalong() ? "Rumah Santri (" + getTransportLabel() + ")" : getGenderedRoomName()) + "\n"
                + "Pengasuh: " + getPengasuhUtama() + " & " + getPembimbingKamar() + "\n"
                + "Disiplin: " + getSpStatusText() + " | Poin Berkah: " + getXpPoints() + " XP";
    }

    // ================= v7.0 MASA TA'ARUF 4 POS NYATA (TANPA TOMBOL INSTAN) =================
    public static final int TAARUF_POS_GERBANG = 1;
    public static final int TAARUF_POS_PSB = 2;
    public static final int TAARUF_POS_ADAB = 3;
    public static final int TAARUF_POS_PELANTIKAN = 4;

    private static final String KEY_V7_TAARUF_PREFIX = "v7_taaruf_pos_";
    private static final String KEY_V7_ADAB_SCORE = "v7_adab_score";
    private static final String KEY_V7_ADAB_LOG = "v7_adab_log";
    private static final String KEY_V7_LAST_SURAH_NO = "v7_last_surah_no";
    private static final String KEY_V7_LAST_SURAH_NAME = "v7_last_surah_name";
    private static final String KEY_V7_LAST_AYAH_NO = "v7_last_ayah_no";
    private static final String KEY_V7_LAST_IQRA_JILID = "v7_last_iqra_jilid";
    private static final String KEY_V7_LAST_STUDY_DATE = "v7_last_study_date";
    private static final String KEY_V7_LAST_STUDY_LOC = "v7_last_study_loc";
    private static final String KEY_V7_LAST_STUDY_NOTE = "v7_last_study_note";
    private static final String KEY_V7_HOME_READY_SCHOOL = "v7_home_ready_school";
    private static final String KEY_V7_HOME_ACTIVITY_LOG = "v7_home_activity_log";

    public boolean isTaarufPosDone(int pos) {
        return prefs.getBoolean(KEY_V7_TAARUF_PREFIX + pos, false);
    }

    public void markTaarufPosDone(int pos) {
        if (pos < 1 || pos > 4) return;
        prefs.edit().putBoolean(KEY_V7_TAARUF_PREFIX + pos, true).apply();
        if (isAllTaarufDone()) {
            prefs.edit()
                    .putBoolean(AppConfig.KEY_DAY1_ADAPTATION_DONE, true)
                    .putBoolean(AppConfig.KEY_TAARUF_DONE, true)
                    .apply();
        }
    }

    public int getTaarufCompletedCount() {
        int c = 0;
        for (int i = 1; i <= 4; i++) {
            if (isTaarufPosDone(i)) c++;
        }
        return c;
    }

    public int getNextTaarufPos() {
        for (int i = 1; i <= 4; i++) {
            if (!isTaarufPosDone(i)) return i;
        }
        return 0;
    }

    public boolean isAllTaarufDone() {
        return isTaarufPosDone(1) && isTaarufPosDone(2) && isTaarufPosDone(3) && isTaarufPosDone(4);
    }

    // ================= v7.0 NILAI ADAB & AKHLAK HIDUP + GELAR KEHORMATAN =================

    public int getAdabScore() {
        return Math.max(0, Math.min(100, prefs.getInt(KEY_V7_ADAB_SCORE, 78)));
    }

    public void recordAdabAction(String code, int delta, String note) {
        int next = Math.max(0, Math.min(100, getAdabScore() + delta));
        String date = new java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.US).format(new java.util.Date());
        String line = date + " • " + (note == null ? code : note) + " (" + (delta >= 0 ? "+" : "") + delta + ")";
        String oldLog = prefs.getString(KEY_V7_ADAB_LOG, "");
        String updated = oldLog.isEmpty() ? line : (line + "\n" + oldLog);
        String[] lines = updated.split("\n");
        StringBuilder trimmed = new StringBuilder();
        for (int i = 0; i < Math.min(lines.length, 15); i++) {
            if (i > 0) trimmed.append("\n");
            trimmed.append(lines[i]);
        }
        prefs.edit()
                .putInt(KEY_V7_ADAB_SCORE, next)
                .putString(KEY_V7_ADAB_LOG, trimmed.toString())
                .apply();
    }

    public String getAdabHistorySummary() {
        String log = prefs.getString(KEY_V7_ADAB_LOG, "");
        if (log.isEmpty()) return "Belum ada catatan adab khusus hari ini. Mulailah dengan salam, izin resmi, dan sapaan hangat.";
        return log;
    }

    public int getFourScoreAverage() {
        return (getKelancaranScore() + getDisiplinScore() + getAdabScore() + getUjianScore()) / 4;
    }

    public String getHonorTitle() {
        int avg = getFourScoreAverage();
        int adab = getAdabScore();
        if (avg >= 92 && adab >= 90) return "Mumtaz Al-Hafidz Utama (Teladan Adab & Hafalan)";
        if (avg >= 85 && adab >= 82) return "Santri Teladan Qur'ani";
        if (avg >= 78) return "Santri Istiqamah Berakhlak Baik";
        if (avg >= 68) return "Santri Pembelajar Tekun";
        return "Santri Perintis Semangat";
    }

    // ================= v7.0 MEMORI LANJUTAN BELAJAR & SINKRON RUMAH -> SEKOLAH (>=75%) =================

    public void saveLastStudyCheckpoint(int surahNo, String surahName, int ayahNo, int iqraJilid,
                                        String location, String note) {
        String today = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date());
        prefs.edit()
                .putInt(KEY_V7_LAST_SURAH_NO, surahNo)
                .putString(KEY_V7_LAST_SURAH_NAME, surahName == null ? "" : surahName)
                .putInt(KEY_V7_LAST_AYAH_NO, Math.max(1, ayahNo))
                .putInt(KEY_V7_LAST_IQRA_JILID, Math.max(1, iqraJilid))
                .putString(KEY_V7_LAST_STUDY_DATE, today)
                .putString(KEY_V7_LAST_STUDY_LOC, location == null ? "Rumah Santri" : location)
                .putString(KEY_V7_LAST_STUDY_NOTE, note == null ? "" : note)
                .apply();
    }

    public int getLastStudySurahNo() { return prefs.getInt(KEY_V7_LAST_SURAH_NO, 114); }
    public String getLastStudySurahName() { return prefs.getString(KEY_V7_LAST_SURAH_NAME, "An-Nas"); }
    public int getLastStudyAyahNo() { return prefs.getInt(KEY_V7_LAST_AYAH_NO, 1); }
    public int getLastStudyIqraJilid() { return prefs.getInt(KEY_V7_LAST_IQRA_JILID, 1); }
    public String getLastStudyDate() { return prefs.getString(KEY_V7_LAST_STUDY_DATE, ""); }
    public String getLastStudyLocation() { return prefs.getString(KEY_V7_LAST_STUDY_LOC, ""); }
    public String getLastStudyNote() { return prefs.getString(KEY_V7_LAST_STUDY_NOTE, ""); }

    /**
     * Mencatat progres belajar mandiri di Rumah Santri.
     * Begitu penguasaan surat/blok mencapai >=75%, surat otomatis masuk daftar
     * pemberitahuan pembimbing di Sekolah agar dijadikan pelajaran/setoran kelas.
     */
    public boolean recordHomeSurahProgress(int surahNo, String surahName, int masteryPct, String activityNote) {
        int clamped = Math.max(0, Math.min(100, masteryPct));
        prefs.edit().putInt("v7_home_surah_pct_" + surahNo, clamped).apply();

        String stamp = new java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.US).format(new java.util.Date());
        String logLine = stamp + " • " + surahName + " (" + clamped + "%) — " + (activityNote == null ? "Latihan Rumah" : activityNote);
        String oldLog = prefs.getString(KEY_V7_HOME_ACTIVITY_LOG, "");
        String mergedLog = oldLog.isEmpty() ? logLine : (logLine + "\n" + oldLog);
        String[] parts = mergedLog.split("\n");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(parts.length, 20); i++) {
            if (i > 0) sb.append("\n");
            sb.append(parts[i]);
        }
        prefs.edit().putString(KEY_V7_HOME_ACTIVITY_LOG, sb.toString()).apply();

        if (clamped >= 75) {
            String raw = prefs.getString(KEY_V7_HOME_READY_SCHOOL, "");
            String token = surahNo + "|" + surahName + "|" + clamped;
            java.util.List<String> items = new java.util.ArrayList<>();
            boolean updated = false;
            if (!raw.isEmpty()) {
                for (String row : raw.split(";;")) {
                    if (row.trim().isEmpty()) continue;
                    if (row.startsWith(surahNo + "|")) {
                        items.add(token);
                        updated = true;
                    } else {
                        items.add(row);
                    }
                }
            }
            if (!updated) items.add(token);
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < items.size(); i++) {
                if (i > 0) out.append(";;");
                out.append(items.get(i));
            }
            prefs.edit().putString(KEY_V7_HOME_READY_SCHOOL, out.toString()).apply();
            return true;
        }
        return false;
    }

    public int getHomeSurahMastery(int surahNo) {
        return prefs.getInt("v7_home_surah_pct_" + surahNo, 0);
    }

    public java.util.List<String> getHomeReadySurahsForSchool() {
        java.util.List<String> list = new java.util.ArrayList<>();
        String raw = prefs.getString(KEY_V7_HOME_READY_SCHOOL, "");
        if (raw == null || raw.trim().isEmpty()) return list;
        for (String row : raw.split(";;")) {
            if (!row.trim().isEmpty()) list.add(row.trim());
        }
        return list;
    }

    public void markHomeSurahSubmittedAtSchool(int surahNo) {
        String raw = prefs.getString(KEY_V7_HOME_READY_SCHOOL, "");
        if (raw == null || raw.trim().isEmpty()) return;
        StringBuilder out = new StringBuilder();
        for (String row : raw.split(";;")) {
            if (row.trim().isEmpty() || row.startsWith(surahNo + "|")) continue;
            if (out.length() > 0) out.append(";;");
            out.append(row.trim());
        }
        prefs.edit().putString(KEY_V7_HOME_READY_SCHOOL, out.toString()).apply();
    }

    public String getHomeActivityLogSummary() {
        String log = prefs.getString(KEY_V7_HOME_ACTIVITY_LOG, "");
        if (log.isEmpty()) return "Belum ada catatan aktivitas belajar rumah.";
        return log;
    }

}
