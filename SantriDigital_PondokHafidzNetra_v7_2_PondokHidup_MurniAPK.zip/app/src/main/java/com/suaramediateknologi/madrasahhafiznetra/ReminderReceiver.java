package com.suaramediateknologi.madrasahhafiznetra;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Penerima Alarm Presisi Pondok Hafidz Netra (v7.0 — 100% Kalender Dunia Nyata).
 * - Mengikuti Hari Minggu/Ahad nyata & hari libur nyata kecuali Mode Simulasi aktif.
 * - Otomatis memicu suara bel + Doa Pagi / Wirid Sore / Bel Kelas / PR Rumah / Majelis Malam Jumat
 *   melalui PondokBackgroundService tanpa perlu klik tombol dulu (hormat mode telepon).
 * - Langsung menjadwalkan ulang alarm untuk esok hari.
 */
public class ReminderReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "santri_digital_pondok_v7";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;

        SharedPreferences prefs = context.getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(AppConfig.KEY_REMINDER_ENABLED, true)
                || !prefs.getBoolean(AppConfig.KEY_BG_ALERTS_ENABLED, true)) {
            return;
        }

        String type = intent.getStringExtra("type");
        if (type == null) type = "BEL_KELAS";

        // Jadwalkan ulang otomatis untuk besok agar alarm tidak pernah putus
        ReminderScheduler.rescheduleForTomorrow(context, type);

        String title = intent.getStringExtra("title");
        String body = intent.getStringExtra("body");
        String santriName = prefs.getString(AppConfig.KEY_SANTRI_NAME, "Santri");
        if (santriName == null || santriName.trim().isEmpty()) santriName = "Santri";

        SchoolScheduleEngine sched = new SchoolScheduleEngine(context);
        InteractiveClassroomEngine cls = new InteractiveClassroomEngine(context);
        SmartLearningEngine smart = cls.getSmartEngine();

        boolean isRealSunday = sched.isRealSundayToday() && !sched.isSimClockEnabled();
        boolean isHoliday = sched.isHolidayToday();
        Calendar cal = Calendar.getInstance();
        int dow = cal.get(Calendar.DAY_OF_WEEK);

        String openAction = "OPEN_DENAH";
        int bellRes = R.raw.bel_masuk_kelas;
        String mp3File = "";
        String spokenText = "";
        int notifId = 5100;

        if ("BEL_KELAS".equals(type)) {
            if (isRealSunday || isHoliday || sched.isOnCuti()) return;
            openAction = "OPEN_KELAS";
            bellRes = R.raw.bel_masuk_kelas;
            mp3File = "pengingat_bel_kelas.mp3";
            title = "Bel Panggilan Kelas — " + santriName;
            body = "Assalamu'alaikum " + santriName + ", 5 menit lagi bel masuk Gedung Kelas berbunyi. Yuk menuju kelas untuk presensi!";
            spokenText = body;
            notifId = 5101;

        } else if ("SUSULAN".equals(type)) {
            if (isRealSunday || isHoliday || sched.isOnCuti()) return;
            String todayKey = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
            String lastAttendDate = prefs.getString(AppConfig.KEY_ATTENDANCE_TODAY_DATE, "");
            String todayStatus = prefs.getString(AppConfig.KEY_ATTENDANCE_TODAY_STATUS, "NONE");
            if (todayKey.equals(lastAttendDate) && !"NONE".equals(todayStatus)) {
                return;
            }
            openAction = "OPEN_KELAS";
            bellRes = R.raw.lonceng_giliran_baca;
            mp3File = "pengingat_susulan.mp3";
            title = "Panggilan Ustadzah Nur — Kelas Susulan";
            body = "Assalamu'alaikum " + santriName + ", kamu belum presensi kelas hari ini. Yuk segera masuk kelas susulan atau ajukan izin resmi di Kantor TU.";
            spokenText = body;
            notifId = 5102;

        } else if ("ANTI_LUPA".equals(type)) {
            openAction = "OPEN_RUMAH";
            bellRes = R.raw.lonceng_giliran_baca;
            mp3File = "pengingat_antilupa.mp3";
            List<String> due = cls.getDueReviewAyahs();
            List<String> retry = smart.getTomorrowRetryItems();
            title = "Pengingat Siang — Murajaah & PR Rumah";
            if (!retry.isEmpty()) {
                body = "Assalamu'alaikum " + santriName + ", ada PR rumah yang menunggu dilancarkan: " + retry.get(0) + ". Yuk buka Kamar Pribadi!";
            } else if (!due.isEmpty()) {
                body = "Assalamu'alaikum " + santriName + ", ada " + due.size() + " ayat rindu diulang di Pohon Hafalan. Yuk murajaah singkat!";
            } else {
                body = "Assalamu'alaikum " + santriName + ", yuk sempatkan murajaah 1 ayat di Kamar Pribadi agar hafalan tetap hijau.";
            }
            spokenText = body;
            notifId = 5103;

        } else if ("WIRID_SORE".equals(type)) {
            openAction = "OPEN_WIRID_SORE";
            bellRes = R.raw.corong_pengumuman;
            mp3File = "wirid_sore_pengantar.mp3";
            title = "Corong Masjid Agung — Wirid Sore 17.00";
            body = "Assalamu'alaikum " + santriName + ", waktunya Wirid Sore dan dzikir petang dari Masjid Agung Pondok Hafidz Netra.";
            spokenText = body;
            notifId = 5104;

        } else if ("DOA_PAGI".equals(type)) {
            openAction = isRealSunday ? "OPEN_RUMAH" : "OPEN_DOA_PAGI";
            bellRes = R.raw.corong_pengumuman;
            mp3File = "doa_pagi_pembuka.mp3";
            String todayMmDd = new SimpleDateFormat("MM-dd", Locale.US).format(new Date());
            String bday = prefs.getString(AppConfig.KEY_BIRTHDATE_MMDD, "");
            if (!bday.isEmpty() && bday.equals(todayMmDd)) {
                title = "Barakallahu Fii Umrik, " + santriName + "!";
                body = "Selamat Milad " + santriName + "! Ustadz Yeni Setiawan, Ustadzah Nur, dan keluarga besar pondok mendoakan keberkahan umur dan hafalanmu.";
                mp3File = "ucapan_milad_santri.mp3";
            } else if (isRealSunday) {
                title = "Doa Pagi Ahad — Hari Libur & Sambangan";
                body = "Assalamu'alaikum " + santriName + ", selamat Hari Ahad! Hari ini sekolah libur resmi. Yuk sapa orang tua di Ruang Tamu atau murajaah santai di Teras Rumah.";
            } else if (dow == Calendar.THURSDAY) {
                title = "Doa Pagi Kamis — Persiapan Malam Jumat";
                body = "Assalamu'alaikum " + santriName + ", selamat pagi Kamis! Jangan lupa nanti malam ada Majelis Yasin, Tahlil, dan Doa Arwah di Masjid Agung.";
            } else if (dow == Calendar.FRIDAY) {
                title = "Doa Pagi Jumat Berkah — Sunnah Al-Kahfi";
                body = "Assalamu'alaikum " + santriName + ", selamat hari Jumat Berkah! Yuk mulai hari dengan doa pagi dan tilawah Surat Al-Kahfi.";
            } else {
                List<String> retry = smart.getTomorrowRetryItems();
                title = "Doa Pagi Otomatis — " + santriName;
                if (!retry.isEmpty()) {
                    body = "Assalamu'alaikum " + santriName + ", selamat pagi! Hari ini kita mulai dengan doa pagi dan melanjutkan PR kemarin: " + retry.get(0) + ".";
                } else {
                    body = "Assalamu'alaikum " + santriName + ", selamat pagi! Bismillah memulai hari dengan doa dan semangat menghafal Al-Qur'an.";
                }
            }
            spokenText = body;
            notifId = 5105;

        } else if ("MALAM_JUMAT".equals(type)) {
            if (dow != Calendar.THURSDAY && !sched.isSimClockEnabled()) {
                return;
            }
            openAction = "OPEN_MALAM_JUMAT";
            bellRes = R.raw.corong_pengumuman;
            mp3File = "majelis_malam_jumat_panggilan.mp3";
            title = "Majelis Malam Jumat — Masjid Agung";
            body = "Assalamu'alaikum " + santriName + ", Malam Jumat telah tiba. Mari berkumpul di Masjid Agung untuk membaca Daftar Arwah, Yasin, dan Tahlil bersama.";
            spokenText = body;
            notifId = 5106;
        }

        // 1. Tampilkan notifikasi yang langsung membuka ruangan tujuan
        showNotification(context, title, body, openAction, notifId);

        // 2. Bunyikan otomatis di latar belakang melalui PondokBackgroundService (hormat mode telepon)
        if (!PondokBackgroundService.isPhoneBusy(context)) {
            PondokBackgroundService.triggerScheduledAudio(context, title, bellRes, mp3File, spokenText);
        }
    }

    private void showNotification(Context context, String title, String body, String openAction, int notifId) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID,
                    "Panggilan Jadwal & Doa Pondok",
                    NotificationManager.IMPORTANCE_HIGH
            );
            ch.setDescription("Bel kelas, Doa Pagi, Wirid Sore, PR Rumah, dan Majelis Malam Jumat");
            nm.createNotificationChannel(ch);
        }

        Intent openIntent = new Intent(context, MainActivity.class);
        openIntent.putExtra("open_action", openAction);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(
                context, notifId, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(title == null ? "Pondok Hafidz Netra" : title)
                .setContentText(body == null ? "Waktunya kegiatan pondok." : body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body == null ? "" : body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(openPi);

        nm.notify(notifId, builder.build());
    }
}
