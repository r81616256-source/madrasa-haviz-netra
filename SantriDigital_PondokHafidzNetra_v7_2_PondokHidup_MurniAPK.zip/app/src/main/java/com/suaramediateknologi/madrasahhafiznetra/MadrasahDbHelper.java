package com.suaramediateknologi.madrasahhafiznetra;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MadrasahDbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "madrasah_hafiz_netra.db";
    private static final int DB_VERSION = 1;

    public static final String BASKET_SABAQ = "SABAQ";
    public static final String BASKET_SABQI = "SABQI";
    public static final String BASKET_MANZIL = "MANZIL";

    public static class AyahProgress {
        public int surah;
        public int ayah;
        public String basket;
        public int errorCount;
        public int masteryScore;
        public long lastReviewed;
        public String note;
    }

    public MadrasahDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS hafalan_progress (" +
                "surah INTEGER NOT NULL, " +
                "ayah INTEGER NOT NULL, " +
                "basket TEXT NOT NULL, " +
                "error_count INTEGER DEFAULT 0, " +
                "mastery_score INTEGER DEFAULT 50, " +
                "last_reviewed INTEGER DEFAULT 0, " +
                "note TEXT DEFAULT '', " +
                "PRIMARY KEY (surah, ayah))");

        db.execSQL("CREATE TABLE IF NOT EXISTS exam_history (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "level INTEGER, " +
                "mode TEXT, " +
                "score INTEGER, " +
                "total INTEGER, " +
                "date_str TEXT)");

        db.execSQL("CREATE TABLE IF NOT EXISTS attendance (" +
                "date_str TEXT PRIMARY KEY, " +
                "sessions_count INTEGER DEFAULT 1)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    public void recordAttendanceToday() {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        SQLiteDatabase db = getWritableDatabase();
        Cursor c = db.rawQuery("SELECT sessions_count FROM attendance WHERE date_str=?", new String[]{today});
        if (c.moveToFirst()) {
            int count = c.getInt(0) + 1;
            ContentValues cv = new ContentValues();
            cv.put("sessions_count", count);
            db.update("attendance", cv, "date_str=?", new String[]{today});
        } else {
            ContentValues cv = new ContentValues();
            cv.put("date_str", today);
            cv.put("sessions_count", 1);
            db.insert("attendance", null, cv);
        }
        c.close();
    }

    public int getTotalAttendanceDays() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT COUNT(*) FROM attendance", null);
        int total = 0;
        if (c.moveToFirst()) total = c.getInt(0);
        c.close();
        return total;
    }

    public void markAyahProgress(int surah, int ayah, boolean correct, String optionalNote) {
        SQLiteDatabase db = getWritableDatabase();
        long now = System.currentTimeMillis();
        Cursor c = db.rawQuery("SELECT basket, error_count, mastery_score, note FROM hafalan_progress WHERE surah=? AND ayah=?",
                new String[]{String.valueOf(surah), String.valueOf(ayah)});
        String basket = BASKET_SABAQ;
        int errors = 0;
        int score = 60;
        String existingNote = "";
        if (c.moveToFirst()) {
            basket = c.getString(0);
            errors = c.getInt(1);
            score = c.getInt(2);
            existingNote = c.getString(3);
        }
        c.close();

        if (correct) {
            score = Math.min(100, score + 15);
            if (score >= 90) {
                basket = BASKET_MANZIL;
            } else if (score >= 75) {
                basket = BASKET_SABQI;
            }
        } else {
            errors++;
            score = Math.max(10, score - 15);
            basket = BASKET_SABAQ;
        }

        ContentValues cv = new ContentValues();
        cv.put("surah", surah);
        cv.put("ayah", ayah);
        cv.put("basket", basket);
        cv.put("error_count", errors);
        cv.put("mastery_score", score);
        cv.put("last_reviewed", now);
        cv.put("note", (optionalNote != null && !optionalNote.isEmpty()) ? optionalNote : existingNote);
        db.insertWithOnConflict("hafalan_progress", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public void saveAyahNote(int surah, int ayah, String note) {
        markAyahProgress(surah, ayah, true, note);
    }

    public String getAyahNote(int surah, int ayah) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT note FROM hafalan_progress WHERE surah=? AND ayah=?",
                new String[]{String.valueOf(surah), String.valueOf(ayah)});
        String note = "";
        if (c.moveToFirst()) note = c.getString(0);
        c.close();
        return note == null ? "" : note;
    }

    public int countByBasket(String basket) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT COUNT(*) FROM hafalan_progress WHERE basket=?", new String[]{basket});
        int count = 0;
        if (c.moveToFirst()) count = c.getInt(0);
        c.close();
        return count;
    }

    public List<AyahProgress> getWeakAyahs(int limit) {
        List<AyahProgress> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT surah, ayah, basket, error_count, mastery_score, last_reviewed, note " +
                        "FROM hafalan_progress WHERE error_count > 0 OR mastery_score < 70 " +
                        "ORDER BY error_count DESC, mastery_score ASC LIMIT " + limit, null);
        while (c.moveToNext()) {
            AyahProgress p = new AyahProgress();
            p.surah = c.getInt(0);
            p.ayah = c.getInt(1);
            p.basket = c.getString(2);
            p.errorCount = c.getInt(3);
            p.masteryScore = c.getInt(4);
            p.lastReviewed = c.getLong(5);
            p.note = c.getString(6);
            list.add(p);
        }
        c.close();
        return list;
    }

    public void recordExam(int level, String mode, int score, int total) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("level", level);
        cv.put("mode", mode);
        cv.put("score", score);
        cv.put("total", total);
        cv.put("date_str", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date()));
        db.insert("exam_history", null, cv);
    }

    public int getTotalExamsPassed() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT COUNT(*) FROM exam_history WHERE total > 0 AND (score * 100 / total) >= 80", null);
        int count = 0;
        if (c.moveToFirst()) count = c.getInt(0);
        c.close();
        return count;
    }

    public String exportBackupJson(int currentLevel, int programMode) {
        try {
            JSONObject root = new JSONObject();
            root.put("app", AppConfig.APP_NAME);
            root.put("exported_at", System.currentTimeMillis());
            root.put("current_level", currentLevel);
            root.put("program_mode", programMode);

            JSONArray arr = new JSONArray();
            SQLiteDatabase db = getReadableDatabase();
            Cursor c = db.rawQuery("SELECT surah, ayah, basket, error_count, mastery_score, last_reviewed, note FROM hafalan_progress", null);
            while (c.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("surah", c.getInt(0));
                o.put("ayah", c.getInt(1));
                o.put("basket", c.getString(2));
                o.put("error_count", c.getInt(3));
                o.put("mastery_score", c.getInt(4));
                o.put("last_reviewed", c.getLong(5));
                o.put("note", c.getString(6));
                arr.put(o);
            }
            c.close();
            root.put("hafalan_progress", arr);
            return root.toString(2);
        } catch (Exception e) {
            return "{}";
        }
    }

    public int importBackupJson(String jsonStr) {
        int restored = 0;
        try {
            JSONObject root = new JSONObject(jsonStr);
            JSONArray arr = root.optJSONArray("hafalan_progress");
            if (arr == null) return 0;
            SQLiteDatabase db = getWritableDatabase();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                ContentValues cv = new ContentValues();
                cv.put("surah", o.getInt("surah"));
                cv.put("ayah", o.getInt("ayah"));
                cv.put("basket", o.optString("basket", BASKET_SABAQ));
                cv.put("error_count", o.optInt("error_count", 0));
                cv.put("mastery_score", o.optInt("mastery_score", 60));
                cv.put("last_reviewed", o.optLong("last_reviewed", System.currentTimeMillis()));
                cv.put("note", o.optString("note", ""));
                db.insertWithOnConflict("hafalan_progress", null, cv, SQLiteDatabase.CONFLICT_REPLACE);
                restored++;
            }
        } catch (Exception ignored) {
        }
        return restored;
    }

    public void deleteAyahNote(int surahNo, int ayahNo) {
        try {
            getWritableDatabase().delete("ayah_notes", "surah_no=? AND ayah_no=?",
                    new String[]{String.valueOf(surahNo), String.valueOf(ayahNo)});
        } catch (Exception ignored) {}
    }
}
