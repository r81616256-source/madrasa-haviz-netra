package com.suaramediateknologi.madrasahhafiznetra;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class FirebaseMadrasahClient {

    public static class SantriRow {
        public String nis;
        public String nama;
        public String kota;
        public String kamar;
        public int nilaiAkhir;
        public String predikat;
        public String statusHariIni;
    }

    public static class HalaqahSummary {
        public int totalSantri;
        public List<SantriRow> leaderboard = new ArrayList<>();
        public List<String> doaSemangat = new ArrayList<>();
        public String latestCorongBroadcast = "";
    }

    public static class KamarKhatamanSummary {
        public int kamarAyatCount;
        public int kamarLombaScore;
        public int khatamanDoneCount;
        public int khatamanRound;
        public List<String> recentKhataman = new ArrayList<>();
        public String juaraKamarSummary = "";
    }

    public String registerSantriOnline(String nama, String kota, String rank, String kamar, int nilaiAkhir, String predikat) {
        String year = new SimpleDateFormat("yyyy", Locale.US).format(new Date());
        int seq = incrementCounterOnline("/counter_nis.json");
        String nis = (seq > 0)
                ? String.format(Locale.US, "MHN-%s-%04d", year, seq)
                : ("MHN-" + year + "-L" + (1000 + new Random().nextInt(8999)));
        try {
            JSONObject obj = new JSONObject();
            obj.put("nis", nis);
            obj.put("nama", nama);
            obj.put("kota", kota == null ? "" : kota);
            obj.put("gelar", rank);
            obj.put("kamar", kamar);
            obj.put("nilai_akhir", nilaiAkhir);
            obj.put("predikat", predikat);
            obj.put("status_hari_ini", "Baru Dilantik");
            obj.put("tanggal_daftar", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date()));
            httpRequest("PUT", AppConfig.FIREBASE_RTDB_BASE + "/santri/" + nis + ".json", obj.toString());
            publishCorongBroadcast("Selamat datang santri baru " + nama + " (" + nis + ") di " + kamar + "!");
        } catch (Exception ignored) {}
        return nis;
    }

    public void syncSantriStatusAndGrade(String nis, String nama, String kamar, int nilaiAkhir, String predikat, String statusToday) {
        if (nis == null || nis.isEmpty()) return;
        try {
            JSONObject obj = new JSONObject();
            obj.put("nama", nama);
            obj.put("kamar", kamar);
            obj.put("nilai_akhir", nilaiAkhir);
            obj.put("predikat", predikat);
            obj.put("status_hari_ini", statusToday);
            obj.put("terakhir_hadir", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date()));
            httpRequest("PATCH", AppConfig.FIREBASE_RTDB_BASE + "/santri/" + nis + ".json", obj.toString());
        } catch (Exception ignored) {}
    }

    public void publishCorongBroadcast(String message) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("pesan", message);
            obj.put("waktu", new SimpleDateFormat("dd/MM HH:mm", Locale.US).format(new Date()));
            httpRequest("PUT", AppConfig.FIREBASE_RTDB_BASE + "/corong_pondok.json", obj.toString());
        } catch (Exception ignored) {}
    }

    public String fetchLatestCorongBroadcast() {
        try {
            String raw = httpRequest("GET", AppConfig.FIREBASE_RTDB_BASE + "/corong_pondok.json", null);
            if (raw != null && raw.trim().startsWith("{")) {
                JSONObject o = new JSONObject(raw);
                String p = o.optString("pesan", "");
                String w = o.optString("waktu", "");
                if (!p.isEmpty()) return "Corong Pondok (" + w + "): " + p;
            }
        } catch (Exception ignored) {}
        return "";
    }

    public void addKamarProgressAndLomba(String kamarKey, int addAyat, int addLombaPts) {
        try {
            if (addAyat > 0) incrementCounterBy("/kamar/" + kamarKey + "/ayat_minggu_ini.json", addAyat);
            if (addLombaPts > 0) incrementCounterBy("/kamar/" + kamarKey + "/skor_lomba.json", addLombaPts);
        } catch (Exception ignored) {}
    }

    public boolean submitKhatamanSurah(int surahNo, String surahName, String santriName, String nis) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("surat_no", surahNo);
            obj.put("surat_nama", surahName);
            obj.put("pembaca", santriName);
            obj.put("nis", nis);
            obj.put("waktu", new SimpleDateFormat("dd/MM HH:mm", Locale.US).format(new Date()));
            String res = httpRequest("PUT", AppConfig.FIREBASE_RTDB_BASE + "/khataman/surat_" + surahNo + ".json", obj.toString());
            publishCorongBroadcast("Santri " + santriName + " baru saja menyumbang " + surahName + " untuk Khataman Bersama Pondok!");
            return res != null;
        } catch (Exception e) {
            return false;
        }
    }

    public KamarKhatamanSummary fetchKamarAndKhataman(String kamarKey) {
        KamarKhatamanSummary sum = new KamarKhatamanSummary();
        sum.khatamanRound = 1;
        try {
            String rawKamar = httpRequest("GET", AppConfig.FIREBASE_RTDB_BASE + "/kamar.json", null);
            if (rawKamar != null && rawKamar.trim().startsWith("{")) {
                JSONObject root = new JSONObject(rawKamar);
                JSONObject mine = root.optJSONObject(kamarKey);
                if (mine != null) {
                    sum.kamarAyatCount = mine.optInt("ayat_minggu_ini", 0);
                    sum.kamarLombaScore = mine.optInt("skor_lomba", 0);
                }
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < AppConfig.KAMAR_KEYS.length; i++) {
                    JSONObject ko = root.optJSONObject(AppConfig.KAMAR_KEYS[i]);
                    int sc = ko != null ? ko.optInt("skor_lomba", 0) : 0;
                    sb.append(AppConfig.KAMAR_NAMES[i]).append(": ").append(sc).append(" poin. ");
                }
                sum.juaraKamarSummary = sb.toString();
            }
            String rawKhatam = httpRequest("GET", AppConfig.FIREBASE_RTDB_BASE + "/khataman.json", null);
            if (rawKhatam != null && rawKhatam.trim().startsWith("{")) {
                JSONObject kr = new JSONObject(rawKhatam);
                sum.khatamanDoneCount = kr.length();
                Iterator<String> it = kr.keys();
                int c = 0;
                while (it.hasNext() && c < 6) {
                    JSONObject o = kr.optJSONObject(it.next());
                    if (o != null) {
                        sum.recentKhataman.add(o.optString("surat_nama", "Surat") + " — oleh " + o.optString("pembaca", "Santri"));
                        c++;
                    }
                }
            }
        } catch (Exception ignored) {}
        return sum;
    }

    public boolean sendDoaSemangatOnline(String nis, String nama, String pesanDoa) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("nis", nis);
            obj.put("nama", nama);
            obj.put("pesan", pesanDoa);
            obj.put("waktu", new SimpleDateFormat("dd/MM HH:mm", Locale.US).format(new Date()));
            return httpRequest("POST", AppConfig.FIREBASE_RTDB_BASE + "/papan_halaqah.json", obj.toString()) != null;
        } catch (Exception e) { return false; }
    }

    public HalaqahSummary fetchHalaqahSummary() {
        HalaqahSummary sum = new HalaqahSummary();
        sum.latestCorongBroadcast = fetchLatestCorongBroadcast();
        try {
            String rawSantri = httpRequest("GET", AppConfig.FIREBASE_RTDB_BASE + "/santri.json", null);
            if (rawSantri != null && rawSantri.trim().startsWith("{")) {
                JSONObject root = new JSONObject(rawSantri);
                sum.totalSantri = root.length();
                Iterator<String> keys = root.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    JSONObject o = root.optJSONObject(k);
                    if (o != null) {
                        SantriRow r = new SantriRow();
                        r.nis = o.optString("nis", k);
                        r.nama = o.optString("nama", "Santri");
                        r.kota = o.optString("kota", "Indonesia");
                        r.kamar = o.optString("kamar", "Kamar Pondok");
                        r.nilaiAkhir = o.optInt("nilai_akhir", 75);
                        r.predikat = o.optString("predikat", "Jayyid");
                        r.statusHariIni = o.optString("status_hari_ini", "Aktif");
                        sum.leaderboard.add(r);
                    }
                }
                Collections.sort(sum.leaderboard, (a, b) -> Integer.compare(b.nilaiAkhir, a.nilaiAkhir));
            }
            String rawDoa = httpRequest("GET", AppConfig.FIREBASE_RTDB_BASE + "/papan_halaqah.json", null);
            if (rawDoa != null && rawDoa.trim().startsWith("{")) {
                JSONObject root = new JSONObject(rawDoa);
                List<String> all = new ArrayList<>();
                Iterator<String> keys = root.keys();
                while (keys.hasNext()) {
                    JSONObject o = root.optJSONObject(keys.next());
                    if (o != null) all.add(o.optString("nama", "Santri") + " (" + o.optString("waktu", "") + "): " + o.optString("pesan", ""));
                }
                for (int i = Math.max(0, all.size() - 5); i < all.size(); i++) sum.doaSemangat.add(all.get(i));
            }
        } catch (Exception ignored) {}
        return sum;
    }

    public boolean pushArwahNameOnline(String namaAlmarhum, String pengirim) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("nama", namaAlmarhum);
            obj.put("pengirim", pengirim);
            obj.put("waktu", new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).format(new Date()));
            return httpRequest("POST", AppConfig.FIREBASE_RTDB_BASE + "/doa_malam_jumat.json", obj.toString()) != null;
        } catch (Exception e) { return false; }
    }

    public List<String> fetchArwahOnlineList() {
        List<String> list = new ArrayList<>();
        try {
            String raw = httpRequest("GET", AppConfig.FIREBASE_RTDB_BASE + "/doa_malam_jumat.json", null);
            if (raw != null && raw.trim().startsWith("{")) {
                JSONObject root = new JSONObject(raw);
                Iterator<String> keys = root.keys();
                while (keys.hasNext()) {
                    JSONObject o = root.optJSONObject(keys.next());
                    if (o != null) {
                        String n = o.optString("nama", "").trim();
                        String p = o.optString("pengirim", "").trim();
                        if (!n.isEmpty()) list.add(p.isEmpty() ? n : (n + " (kiriman " + p + ")"));
                    }
                }
            }
        } catch (Exception ignored) {}
        return list;
    }

    private int incrementCounterOnline(String path) {
        return incrementCounterBy(path, 1);
    }

    private int incrementCounterBy(String path, int delta) {
        try {
            String raw = httpRequest("GET", AppConfig.FIREBASE_RTDB_BASE + path, null);
            int cur = 0;
            if (raw != null && !raw.trim().equals("null") && !raw.trim().isEmpty()) {
                cur = Integer.parseInt(raw.trim());
            }
            int next = cur + delta;
            if (httpRequest("PUT", AppConfig.FIREBASE_RTDB_BASE + path, String.valueOf(next)) != null) return next;
        } catch (Exception ignored) {}
        return -1;
    }


    public static class ArwahEntry {
        public String key;
        public String nama;
        public String pengirim;
        public ArwahEntry(String key, String nama, String pengirim) {
            this.key = key;
            this.nama = nama;
            this.pengirim = pengirim;
        }
    }

    public List<ArwahEntry> fetchArwahEntriesOnline() {
        List<ArwahEntry> out = new ArrayList<>();
        try {
            String resp = httpRequest("GET", AppConfig.FIREBASE_RTDB_BASE + "/doa_malam_jumat.json", null);
            if (resp != null && !resp.equals("null")) {
                JSONObject obj = new JSONObject(resp);
                Iterator<String> keys = obj.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    JSONObject item = obj.optJSONObject(k);
                    if (item != null) {
                        String n = item.optString("nama", "").trim();
                        String p = item.optString("pengirim", "Keluarga").trim();
                        if (!n.isEmpty()) out.add(new ArwahEntry(k, n, p));
                    } else {
                        String n = obj.optString(k, "").trim();
                        if (!n.isEmpty()) out.add(new ArwahEntry(k, n, "Keluarga"));
                    }
                }
            }
        } catch (Exception ignored) {}
        return out;
    }

    public boolean updateArwahNameOnline(String key, String newName) {
        if (key == null || key.isEmpty() || newName == null || newName.trim().isEmpty()) return false;
        try {
            JSONObject body = new JSONObject();
            body.put("nama", newName.trim());
            String resp = httpRequest("PATCH", AppConfig.FIREBASE_RTDB_BASE + "/doa_malam_jumat/" + key + ".json", body.toString());
            return resp != null;
        } catch (Exception ignored) {
            return false;
        }
    }

    public boolean deleteArwahNameOnline(String key) {
        if (key == null || key.isEmpty()) return false;
        try {
            String resp = httpRequest("DELETE", AppConfig.FIREBASE_RTDB_BASE + "/doa_malam_jumat/" + key + ".json", null);
            return resp != null;
        } catch (Exception ignored) {
            return false;
        }
    }


    public static class BoardEntry {
        public String key;
        public String pengirim;
        public String isi;
        public int aamiinCount;
        public BoardEntry(String key, String pengirim, String isi, int aamiinCount) {
            this.key = key;
            this.pengirim = pengirim;
            this.isi = isi;
            this.aamiinCount = aamiinCount;
        }
    }

    public boolean pushBoardEntry(String nodeName, String pengirim, String isi) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("pengirim", pengirim);
            obj.put("isi", isi);
            obj.put("aamiin", 1);
            obj.put("waktu", System.currentTimeMillis());
            return httpRequest("POST", AppConfig.FIREBASE_RTDB_BASE + "/" + nodeName + ".json", obj.toString()) != null;
        } catch (Exception ignored) { return false; }
    }

    public List<BoardEntry> fetchBoardEntries(String nodeName) {
        List<BoardEntry> out = new ArrayList<>();
        try {
            String resp = httpRequest("GET", AppConfig.FIREBASE_RTDB_BASE + "/" + nodeName + ".json", null);
            if (resp != null && !resp.equals("null")) {
                JSONObject obj = new JSONObject(resp);
                Iterator<String> keys = obj.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    JSONObject it = obj.optJSONObject(k);
                    if (it != null) {
                        String p = it.optString("pengirim", "Santri");
                        String i = it.optString("isi", "");
                        int a = it.optInt("aamiin", 1);
                        if (!i.isEmpty()) out.add(new BoardEntry(k, p, i, a));
                    }
                }
            }
        } catch (Exception ignored) {}
        return out;
    }

    public boolean updateBoardEntry(String nodeName, String key, String newIsi) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("isi", newIsi);
            return httpRequest("PATCH", AppConfig.FIREBASE_RTDB_BASE + "/" + nodeName + "/" + key + ".json", obj.toString()) != null;
        } catch (Exception ignored) { return false; }
    }

    public boolean deleteBoardEntry(String nodeName, String key) {
        return httpRequest("DELETE", AppConfig.FIREBASE_RTDB_BASE + "/" + nodeName + "/" + key + ".json", null) != null;
    }

    public boolean incrementBoardAamiin(String nodeName, String key, int newCount) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("aamiin", newCount);
            return httpRequest("PATCH", AppConfig.FIREBASE_RTDB_BASE + "/" + nodeName + "/" + key + ".json", obj.toString()) != null;
        } catch (Exception ignored) { return false; }
    }


    public String verifyNisOrPiagamOnline(String queryCode) {
        if (queryCode == null || queryCode.trim().isEmpty()) return "Masukkan nomor NIS atau kode piagam.";
        String q = queryCode.trim().toUpperCase(java.util.Locale.ROOT);
        try {
            String resp = httpRequest("GET", AppConfig.FIREBASE_RTDB_BASE + "/santri.json", null);
            if (resp != null && !resp.equals("null")) {
                JSONObject obj = new JSONObject(resp);
                Iterator<String> keys = obj.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    JSONObject s = obj.optJSONObject(k);
                    if (s == null) continue;
                    String nis = s.optString("nis", k).toUpperCase(java.util.Locale.ROOT);
                    if (nis.equals(q) || q.contains(nis)) {
                        return "TERVERIFIKASI RESMI ✓\n" +
                                "Lembaga: " + AppConfig.INSTITUTION_NAME + "\n" +
                                "NIS: " + nis + "\n" +
                                "Nama: " + s.optString("nama", "-") + " (" + s.optString("kota", "-") + ")\n" +
                                "Kamar: " + s.optString("kamar", "-") + "\n" +
                                "Nilai Akhir: " + s.optInt("nilai_akhir", 75) + "/100 (" + s.optString("predikat", "Jayyid") + ")";
                    }
                }
            }
        } catch (Exception ignored) {}
        return "Nomor " + q + " belum ditemukan di Buku Induk server online (pastikan koneksi aktif atau NIS sudah terdaftar).";
    }

    private String httpRequest(String method, String urlStr, String jsonBody) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(9000);
            conn.setReadTimeout(10000);
            if ("PATCH".equals(method)) {
                conn.setRequestMethod("POST");
                conn.setRequestProperty("X-HTTP-Method-Override", "PATCH");
            } else {
                conn.setRequestMethod(method);
            }
            if (jsonBody != null) {
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(jsonBody.getBytes(StandardCharsets.UTF_8));
                }
            }
            int code = conn.getResponseCode();
            if (code >= 200 && code < 300) {
                try (InputStream in = new BufferedInputStream(conn.getInputStream());
                     ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[4096];
                    int r;
                    while ((r = in.read(buf)) != -1) baos.write(buf, 0, r);
                    return baos.toString(StandardCharsets.UTF_8.name());
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
        return null;
    }

    // ================= v5.0 OFFICIAL INDONESIA REGION API (PROVINSI -> KAB -> KEC -> DESA) & JADWAL SHALAT =================
    public static class RegionOption {
        public String id;
        public String name;
        public RegionOption(String id, String name) {
            this.id = id;
            this.name = name;
        }
        @Override public String toString() { return name; }
    }

    public List<RegionOption> fetchOfficialRegions(String endpointPath) {
        String[] bases = {
                "https://www.emsifa.com/api-wilayah-indonesia/v2/",
                "https://emsifa.github.io/api-wilayah-indonesia/api/",
                "https://wilayah.id/api/"
        };
        for (String base : bases) {
            List<RegionOption> list = new ArrayList<>();
            try {
                String resp = httpRequest("GET", base + endpointPath, null);
                if (resp == null || resp.trim().isEmpty()) continue;
                String trimmed = resp.trim();
                org.json.JSONArray arr = null;
                if (trimmed.startsWith("[")) {
                    arr = new org.json.JSONArray(trimmed);
                } else if (trimmed.startsWith("{")) {
                    org.json.JSONObject root = new org.json.JSONObject(trimmed);
                    if (root.has("data")) arr = root.getJSONArray("data");
                }
                if (arr != null) {
                    for (int i = 0; i < arr.length(); i++) {
                        org.json.JSONObject o = arr.getJSONObject(i);
                        String id = o.optString("id", o.optString("code", ""));
                        String nm = toTitleCaseRegion(o.optString("name", ""));
                        if (!id.isEmpty() && !nm.isEmpty()) list.add(new RegionOption(id, nm));
                    }
                }
                if (!list.isEmpty()) return list;
            } catch (Exception ignored) {}
        }
        return new ArrayList<>();
    }

    private static String toTitleCaseRegion(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        String[] words = raw.toLowerCase(Locale.ROOT).split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            String w = words[i];
            if (w.isEmpty()) continue;
            if (sb.length() > 0) sb.append(" ");
            if (w.equals("dki") || w.equals("di")) sb.append(w.toUpperCase(Locale.ROOT));
            else sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }

    public String fetchPrayerTimesForCity(String cityName) {
        try {
            String cleanCity = cityName == null ? "Situbondo" : cityName
                    .replace("Kabupaten ", "").replace("Kab. ", "").replace("Kota ", "").trim();
            if (cleanCity.contains(",")) cleanCity = cleanCity.substring(cleanCity.lastIndexOf(',') + 1).trim();
            if (cleanCity.isEmpty()) cleanCity = "Situbondo";
            String encoded = java.net.URLEncoder.encode(cleanCity, "UTF-8");
            String url = "https://api.aladhan.com/v1/timingsByCity?city=" + encoded + "&country=Indonesia&method=20";
            String resp = httpRequest("GET", url, null);
            if (resp != null && resp.contains("timings")) {
                org.json.JSONObject root = new org.json.JSONObject(resp);
                org.json.JSONObject t = root.getJSONObject("data").getJSONObject("timings");
                return "Jadwal Shalat Resmi (" + cleanCity + "):\n"
                        + "Subuh " + t.optString("Fajr", "04:15")
                        + " | Dzuhur " + t.optString("Dhuhr", "11:35")
                        + " | Ashar " + t.optString("Asr", "14:55")
                        + " | Maghrib " + t.optString("Maghrib", "17:45")
                        + " | Isya " + t.optString("Isha", "18:55");
            }
        } catch (Exception ignored) {}
        return "Jadwal Shalat Perkiraan WIB: Subuh 04:15 | Dzuhur 11:35 | Ashar 14:55 | Maghrib 17:45 | Isya 18:55";
    }

}
