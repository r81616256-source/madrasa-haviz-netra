package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class GeminiAiClient {
    private static final String MODEL_ENDPOINT =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=";

    private final SharedPreferences prefs;

    public GeminiAiClient(Context context) {
        this.prefs = context.getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
    }

    public String getSavedApiKey() {
        return prefs.getString(AppConfig.KEY_GEMINI_API_KEY, "").trim();
    }

    public void saveApiKey(String key) {
        prefs.edit().putString(AppConfig.KEY_GEMINI_API_KEY, key == null ? "" : key.trim()).apply();
    }

    public void clearApiKey() {
        prefs.edit().remove(AppConfig.KEY_GEMINI_API_KEY).apply();
    }

    public boolean hasApiKey() {
        return !getSavedApiKey().isEmpty();
    }

    public String askUstadzAi(String userPrompt) {
        String apiKey = getSavedApiKey();
        if (apiKey.isEmpty()) {
            return "Kunci API Gemini belum diisi. Anda tetap bisa memakai semua fitur utama aplikasi, atau tempel kunci API pribadi di Tab Rapor dan Setelan untuk mengaktifkan Ustadz AI.";
        }
        String systemPrompt = "Anda adalah Ustadz pendamping tahfidz Al-Qur'an yang ramah, ringkas, dan jelas untuk santri tunanetra di aplikasi Madrasah Hafidz Netra. Jawab dalam bahasa Indonesia lisan yang nyaman dibacakan narator, maksimal 4 kalimat, tanpa simbol markdown.";
        return callGemini(apiKey, systemPrompt + "\n\nPertanyaan: " + userPrompt);
    }

    public String testApiKey(String candidateKey) {
        if (candidateKey == null || candidateKey.trim().isEmpty()) {
            return "ERROR: Kunci API kosong.";
        }
        String resp = callGemini(candidateKey.trim(), "Jawab singkat satu kalimat dalam bahasa Indonesia: Kunci API Ustadz AI Madrasah Hafidz Netra berhasil terhubung.");
        if (resp.startsWith("ERROR:")) return resp;
        return "OK: " + resp;
    }

    private String callGemini(String apiKey, String promptText) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(MODEL_ENDPOINT + apiKey);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(20000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

            JSONObject part = new JSONObject();
            part.put("text", promptText);
            JSONObject content = new JSONObject();
            content.put("parts", new JSONArray().put(part));
            JSONObject body = new JSONObject();
            body.put("contents", new JSONArray().put(content));

            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }

            int code = conn.getResponseCode();
            InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            String raw = readStream(stream);
            if (code >= 200 && code < 300) {
                JSONObject json = new JSONObject(raw);
                JSONArray candidates = json.optJSONArray("candidates");
                if (candidates != null && candidates.length() > 0) {
                    JSONObject c0 = candidates.getJSONObject(0);
                    JSONObject cContent = c0.optJSONObject("content");
                    if (cContent != null) {
                        JSONArray parts = cContent.optJSONArray("parts");
                        if (parts != null && parts.length() > 0) {
                            return parts.getJSONObject(0).optString("text", "").trim();
                        }
                    }
                }
                return "Ustadz AI tidak mengembalikan jawaban.";
            } else {
                return "ERROR: Gagal menghubungi Gemini API (kode " + code + "). Periksa kembali kunci API Anda.";
            }
        } catch (Exception e) {
            return "ERROR: Koneksi internet tidak tersedia atau kunci API tidak valid.";
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private String readStream(InputStream in) {
        if (in == null) return "";
        try (InputStream bis = new BufferedInputStream(in);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int r;
            while ((r = bis.read(buf)) != -1) baos.write(buf, 0, r);
            return baos.toString(StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            return "";
        }
    }

    public String askHybridContextual(String userSpeech, String contextInfo, String santriName) {
        if (!hasApiKey()) {
            return buildSmartOfflineReply(userSpeech, contextInfo, santriName);
        }
        String enriched = "Anda adalah guru pesantren Madrasah Hafidz Netra yang hangat, ramah, sabar, dan bicara dalam Bahasa Indonesia singkat (maksimal 3 kalimat agar nyaman didengar lewat suara TalkBack). "
                + "Santri bernama " + santriName + ". Konteks pelajaran aktif: " + contextInfo + ". "
                + "Ucapan santri: " + userSpeech;
        String resp = askUstadzAi(enriched);
        if (resp == null || resp.trim().isEmpty() || resp.contains("Belum ada kunci")) {
            return buildSmartOfflineReply(userSpeech, contextInfo, santriName);
        }
        return resp;
    }

    public String buildSmartOfflineReply(String speech, String contextInfo, String santriName) {
        String s = speech == null ? "" : speech.toLowerCase(java.util.Locale.ROOT);
        if (s.contains("capek") || s.contains("lelah") || s.contains("malas") || s.contains("sedih") || s.contains("futur")) {
            return "Tidak apa-apa merasa lelah, " + santriName + ". Tarik napas dulu, istirahat sejenak, dan cukup simak satu ayat pelan saja hari ini. Allah melihat setiap usahamu.";
        }
        if (s.contains("assalam") || s.contains("halo") || s.contains("pagi") || s.contains("siang") || s.contains("sore") || s.contains("malam")) {
            return "Wa alaikum salam warahmatullahi wabarakatuh, " + santriName + "! Alhamdulillah senang mendengar suaramu. Kita sedang di " + contextInfo + ", mau langsung lanjut atau ulang pelan?";
        }
        if (s.contains("doa") || s.contains("doakan")) {
            return "InsyaAllah, Ustadz dan Ustadzah selalu mendoakan semoga " + santriName + " diberikan kesehatan, ketenangan hati, dan kemudahan menghafal Al-Qur'an. Aamiin.";
        }
        if (s.contains("tajwid") || s.contains("dengung") || s.contains("qalqalah") || s.contains("mad")) {
            return "Untuk tajwid yang lebih mantap di " + contextInfo + ", simak Qari pelan di tempo 0.80x atau buka Kamus Audio Tajwid di Maktabah Pak Haji Sholeh ya.";
        }
        return "Terima kasih sudah berbicara, " + santriName + ". Untuk " + contextInfo + ", Anda bisa bilang 'ulangi pelan', 'uji saya', 'artinya apa', atau masukkan Kunci API Gemini gratis di Setelan agar guru bisa menjawab pertanyaan bebas lebih luas.";
    }

}
