package com.suaramediateknologi.madrasahhafiznetra;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/**
 * Penerima Boot & Perubahan Waktu Sistem (v7.0 — Pondok Hidup Sungguhan).
 * Menjadwalkan ulang seluruh alarm presisi (setAlarmClock) dan menyalakan kembali
 * penjaga waktu latar belakang setelah HP dinyalakan ulang, aplikasi diperbarui,
 * atau zona waktu berubah.
 */
public class BootCompletedReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
                || "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED".equals(action)) {

            Context appCtx = context.getApplicationContext();
            SharedPreferences prefs = appCtx.getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
            boolean enabled = prefs.getBoolean(AppConfig.KEY_REMINDER_ENABLED, true)
                    && prefs.getBoolean(AppConfig.KEY_BG_ALERTS_ENABLED, true);
            if (enabled) {
                ReminderScheduler.scheduleAll(appCtx);
                PondokBackgroundService.startTimekeeper(appCtx);
            }
        }
    }
}
