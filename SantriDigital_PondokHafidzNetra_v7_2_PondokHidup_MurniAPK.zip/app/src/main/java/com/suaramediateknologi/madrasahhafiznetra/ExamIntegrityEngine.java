package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Mesin Ujian Anti-Klik-Sembarangan & Mesin Kegiatan Otomatis Harian Pondok (v7.0).
 * - 4 opsi acak netral (jawaban benar selalu diacak posisinya).
 * - Kunci anti-klik-kilat (minimal 3 detik membaca/menyimak sebelum boleh menjawab).
 * - Wajib 2 tahap: Tahap 1 Pemahaman (4 soal) + Tahap 2 Praktik Lisan / Susun Potongan Ayat.
 * - Evaluasi guru rinci per soal.
 * - Remidi nyata yang mengunci ulang ujian sampai santri menyelesaikan materi perbaikan.
 */
public class ExamIntegrityEngine {

    public static final long MIN_READ_MILLIS = 3000L;
    private static final String KEY_REMIDI_REQUIRED = "v7_exam_remidi_required";
    private static final String KEY_REMIDI_TOPICS = "v7_exam_remidi_topics";
    private static final String KEY_DAILY_EVENT_DONE_DATE = "v7_daily_event_done_date";

    public static class ExamQuestion {
        public final String topic;
        public final String prompt;
        public final List<String> shuffledOptions = new ArrayList<>();
        public final int correctIndex;
        public final String explanation;

        public ExamQuestion(String topic, String prompt, String correctAnswer,
                            String wrong1, String wrong2, String wrong3, String explanation) {
            this.topic = topic;
            this.prompt = prompt;
            this.explanation = explanation;
            List<String> pool = new ArrayList<>();
            pool.add(correctAnswer);
            pool.add(wrong1);
            pool.add(wrong2);
            pool.add(wrong3);
            Collections.shuffle(pool);
            this.shuffledOptions.addAll(pool);
            this.correctIndex = this.shuffledOptions.indexOf(correctAnswer);
        }
    }

    public static class ArrangePieceTask {
        public final String title;
        public final String instruction;
        public final String[] correctOrder;
        public final List<String> shuffledPieces = new ArrayList<>();

        public ArrangePieceTask(String title, String instruction, String[] correctOrder) {
            this.title = title;
            this.instruction = instruction;
            this.correctOrder = correctOrder;
            for (String p : correctOrder) shuffledPieces.add(p);
            Collections.shuffle(shuffledPieces);
            // Pastikan tidak kebetulan sama persis jika lebih dari 1 potongan
            if (shuffledPieces.size() > 1 && shuffledPieces.get(0).equals(correctOrder[0])) {
                Collections.rotate(shuffledPieces, 1);
            }
        }
    }

    public static class DailyPondokEvent {
        public final String title;
        public final String host;
        public final String description;
        public final String rewardNote;

        public DailyPondokEvent(String title, String host, String description, String rewardNote) {
            this.title = title;
            this.host = host;
            this.description = description;
            this.rewardNote = rewardNote;
        }
    }

    private final SharedPreferences prefs;

    public ExamIntegrityEngine(Context context) {
        this.prefs = context.getApplicationContext().getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
    }

    public boolean isRemidiRequired() {
        return prefs.getBoolean(KEY_REMIDI_REQUIRED, false);
    }

    public String getRemidiTopics() {
        return prefs.getString(KEY_REMIDI_TOPICS, "Materi Tajwid, Sambung Ayat & Adab Santri");
    }

    public void setRemidiRequired(boolean required, String failedTopicsSummary) {
        prefs.edit()
                .putBoolean(KEY_REMIDI_REQUIRED, required)
                .putString(KEY_REMIDI_TOPICS, failedTopicsSummary == null ? "" : failedTopicsSummary)
                .apply();
    }

    public List<ExamQuestion> generateStage1Questions() {
        List<ExamQuestion> list = new ArrayList<>();
        list.add(new ExamQuestion(
                "Sambung Ayat (Al-Ikhlas)",
                "Lanjutan yang tepat setelah ayat 'Qul huwallahu ahad' adalah...",
                "Allahush shamad",
                "Lam yalid wa lam yulad",
                "Malikin naas",
                "Min syarri maa khalaq",
                "Ayat ke-2 Surat Al-Ikhlas adalah 'Allahush shamad' (Allah tempat meminta segala sesuatu)."
        ));
        list.add(new ExamQuestion(
                "Hukum Tajwid (Idgham Bighunnah)",
                "Apabila Nun Sukun atau Tanwin bertemu huruf Mim, Nun, Wawu, atau Ya maka dibaca...",
                "Idgham Bighunnah (dimasukkan dengan dengung 2 harakat)",
                "Izhar Halqi (dibaca jelas tanpa dengung)",
                "Qalqalah Kubra (dipantulkan kuat di akhir ayat)",
                "Mad Wajib Muttashil (dipanjangkan 5 harakat)",
                "Huruf Ya-Nun-Mim-Wawu (Yanmu) setelah Nun Sukun/Tanwin dibaca Idgham Bighunnah dengan dengung."
        ));
        list.add(new ExamQuestion(
                "Adab Penghafal Al-Qur'an",
                "Jika santri perlu keluar di tengah jam kelas yang sedang berlangsung, sikap adab yang benar adalah...",
                "Meminta izin terlebih dahulu kepada guru pembimbing dengan sopan",
                "Langsung menutup aplikasi tanpa memberi tahu pembimbing",
                "Menunggu sampai pekan depan tanpa mencatat kehadiran",
                "Memindahkan jam kelas tanpa melapor ke Kantor TU",
                "Meminta izin kepada guru menjaga keberkahan ilmu dan tercatat dalam Nilai Adab."
        ));
        list.add(new ExamQuestion(
                "Sambung Ayat (Al-Falaq)",
                "Lanjutan yang tepat setelah 'Qul a'udzu birabbil falaq' adalah...",
                "Min syarri maa khalaq",
                "Wa min syarri hasidin idza hasad",
                "Ilahin naas",
                "Fashalli lirabbika wanhar",
                "Ayat ke-2 Surat Al-Falaq adalah 'Min syarri maa khalaq' (dari kejahatan makhluk yang Dia ciptakan)."
        ));
        Collections.shuffle(list);
        return list;
    }

    public ArrangePieceTask generateStage2ArrangeTask() {
        return new ArrangePieceTask(
                "Tahap 2: Praktik Susun Potongan Ayat (Surat Al-Kautsar)",
                "Susun 3 potongan ayat Surat Al-Kautsar berikut dari ayat 1 sampai ayat 3 secara berurutan:",
                new String[]{
                        "Innaa a'thainaakal kautsar",
                        "Fashalli lirabbika wanhar",
                        "Inna syaani'aka huwal abtar"
                }
        );
    }

    /**
     * Mesin Kegiatan Otomatis Harian Pondok: menghadirkan kegiatan terbaru setiap hari secara nyata.
     */
    public DailyPondokEvent getTodayAutomaticEvent() {
        int dayOfYear = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR);
        int dow = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK);

        if (dow == java.util.Calendar.THURSDAY) {
            return new DailyPondokEvent(
                    "Persiapan & Majelis Malam Jumat (Yasin, Tahlil & Doa Arwah)",
                    "Ustadz Yeni Setiawan",
                    "Kegiatan otomatis hari Kamis: menyimak daftar nama arwah dari Firebase, mendoakan bersama, dan lantunan Yasin di Masjid Agung.",
                    "+4 Nilai Adab & Mutaba'ah Malam Jumat"
            );
        }
        if (dow == java.util.Calendar.SUNDAY) {
            return new DailyPondokEvent(
                    "Hari Ahad: Sambangan Keluarga & Bincang Wali Santri",
                    "Ustadzah Nur & Wali Santri",
                    "Kegiatan otomatis hari Ahad: bincang hangat di Ruang Tamu Rumah, membaca Buku Penghubung Keluarga, dan merawat taman.",
                    "+3 Nilai Adab Berbakti & +15% Stamina"
            );
        }

        DailyPondokEvent[] rotation = {
                new DailyPondokEvent(
                        "Halaqah Perbaikan Makhraj & Tajwid Pagi",
                        "Ustadzah Fatimah Az-Zahra",
                        "Latihan menyimak makhraj huruf-huruf berdekatan dan menjaga panjang mad bersama pembimbing.",
                        "+3 Kelancaran & Catatan Mutaba'ah"
                ),
                new DailyPondokEvent(
                        "Musabaqah Sambung Ayat Antar Santri",
                        "Ustadz Yeni Setiawan",
                        "Tantangan sambung ayat Juz 30 penuh kejujuran untuk melatih ketajaman ingatan hafalan.",
                        "+3 Nilai Ujian & Semangat Halaqah"
                ),
                new DailyPondokEvent(
                        "Kerja Bakti Perawatan Sarana Digital Pondok",
                        "Pengurus Koperasi Pondok",
                        "Mengecek kondisi Smartboard Audio, Printer TU, Sound System Masjid, dan Speaker Rumah agar tetap prima.",
                        "+3 Nilai Adab Peduli Fasilitas"
                ),
                new DailyPondokEvent(
                        "Majelis Doa Semangat & Mading Suara Online",
                        "Ustadzah Khadijah Rahmawati",
                        "Saling mengirim Doa Semangat lewat Firebase untuk sahabat santri tunanetra di seluruh Nusantara.",
                        "+3 Nilai Adab Ukhuwah"
                ),
                new DailyPondokEvent(
                        "Kajian Adab Penghafal Al-Qur'an & Refleksi Jurnal",
                        "Ustadzah Nur",
                        "Menulis refleksi harian di Buku Catatan Digital Rumah dan menyimak nasihat pembimbing di Kantor TU.",
                        "+3 Nilai Adab & Kedisiplinan"
                )
        };
        return rotation[dayOfYear % rotation.length];
    }

    public boolean isTodayEventCompleted() {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        return today.equals(prefs.getString(KEY_DAILY_EVENT_DONE_DATE, ""));
    }

    public void markTodayEventCompleted() {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        prefs.edit().putString(KEY_DAILY_EVENT_DONE_DATE, today).apply();
    }
}
