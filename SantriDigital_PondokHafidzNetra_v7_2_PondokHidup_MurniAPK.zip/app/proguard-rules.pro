# ProGuard rules for Madrasah Hafidz Netra
-keep class com.suaramediateknologi.madrasahhafiznetra.** { *; }
