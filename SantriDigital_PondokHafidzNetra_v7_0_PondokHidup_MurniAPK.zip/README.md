# Santri Digital — Pondok Hafidz Netra v7.0 (Pondok Hidup Sungguhan)

Aplikasi Native Android Java aksesibel penuh untuk pembaca layar **Jieshuo** dan **TalkBack** oleh **Suara Media Teknologi** (Ustadzah Nur & Ustadz Yeni Setiawan).

## Infrastruktur Resmi
- Root Package: `com.suaramediateknologi.madrasahhafiznetra`
- Repository: `r81616256-source/madrasa-haviz-netra` (cabang `main`)
- Firebase RTDB: `madrasah_hafiz_netra`
- BYOK Gemini API lokal per perangkat (tanpa API key tertanam)
- Tanpa `build-apk.yml` (arsip ini adalah proyek Android APK murni)

## Fitur Utama v7.0
1. Penjaga Waktu Otomatis & Alarm Presisi (`AlarmManager.setAlarmClock` + `PondokBackgroundService` + `BootCompletedReceiver`) mengikuti 100% waktu & kalender dunia nyata, hormat mode telepon.
2. Masa Ta'aruf & Adab 4 Pos Nyata (tanpa tombol instan) + Nilai Adab Hidup & Gelar Kehormatan.
3. Pendidikan Non-Formal (Gedung Kelas 4 Babak + Auto-Respon + 100% Hijau otomatis lanjut/tuntas) & Pendidikan Formal (MI/SD, MTs/SMP, MA/SMA, Ma'had Aly).
4. Rumah Santri 4 Ruangan Nyata (Kamar Pribadi, Ruang Tamu, Dapur Rumah, Teras/Taman) dengan sinkronisasi otomatis `>=75%` ke Sekolah & kirim Jurnal ke Server TU.
5. Orientasi Mobilitas Usap 2 Jari (4 arah kompas, rute berbelok multi-tahap, koreksi salah arah, tombol masuk pintu muncul tepat di depan pintu).
6. Kantor TU Hidup, Sistem Ujian Anti-Klik-Sembarangan (2 tahap, kunci 3 detik, remidi nyata), Cetak Rapor & Buku Absensi 5 Status (PNG + Teks).
7. Nuansa Online Firebase nyata, Mesin Kegiatan Otomatis Harian, 12 Sarana Digital Interaktif + Koperasi Pondok, Majelis Malam Jumat Nyata, serta Ekonomi Kemandirian Pondok (Saldo Rp 4 Miliar, Panen Pasif s/d Rp 500 Juta, Dapur Asrama, Kebun & Pasar).
