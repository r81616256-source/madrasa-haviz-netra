package com.suaramediateknologi.madrasahhafiznetra;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MainActivity v7.0 — Pondok Hidup Sungguhan (Clean Rebuild).
 * Bersih, terarah, bebas tombol pajangan, 100% ramah Jieshuo & TalkBack.
 */
public class MainActivity extends AppCompatActivity {

    // Engines inti
    private SharedPreferences prefs;
    private QuranRepository quranRepo;
    private NarratorManager narrator;
    private AudioSequencer sequencer;
    private MadrasahDbHelper dbHelper;
    private SchoolScheduleEngine schedule;
    private LivingMadrasahEngine living;
    private InteractiveClassroomEngine classroom;
    private SmartLearningEngine smart;
    private PesantrenWorldEngine world;
    private FirebaseMadrasahClient firebase;
    private GeminiAiClient gemini;
    private QuizGeneratorEngine quizEngine;
    private FacilityDeviceEngine devices;
    private FormalSchoolEngine formalSchool;
    private ExamIntegrityEngine examEngine;
    private List<ExamIntegrityEngine.ExamQuestion> activeExamQuestions;
    private int activeExamIdx = 0;
    private int activeExamCorrect = 0;
    private long examQuestionShownAtMs = 0L;
    private final StringBuilder examDetailReport = new StringBuilder();
    private final List<String> examWrongTopics = new ArrayList<>();
    private ExamIntegrityEngine.ArrangePieceTask activeArrangeTask;
    private int arrangeStepIdx = 0;
    private List<FirebaseMadrasahClient.ArwahEntry> activeArwahList = new ArrayList<>();
    private int activeArwahIdx = 0;
    private int selectedFreeMethodIdx = 0;
    private int activeIqraJilid = 1;
    private int activeClassStage = 1;

    private final ExecutorService bgExecutor = Executors.newCachedThreadPool();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // Views utama
    private ScrollView mainScrollView;
    private TextView tvHeaderTitle, tvHeaderSubtitle;
    private Button btnTopMicGuru, btnTopStopAudio;

    private LinearLayout viewBeranda, viewOrientasi, viewRuangAktif, viewBelajarTerarah, viewSetelan;
    private TextView tvBerandaGreeting, tvBerandaMemory;
    private Button btnHeroAction;
    private LinearLayout berandaQuickContainer;

    // Orientasi Mobilitas Usap 2 Jari
    private TextView tvOrientasiTitle, tvOrientasiNarasi;
    private MobilityCompassView mobilityCompassView;
    private LinearLayout panelCompassButtons, orientasiDestinationsContainer;
    private Button btnDirUtara, btnDirSelatan, btnDirTimur, btnDirBarat, btnEnterDoor;

    // Panggung Ruang Aktif
    private TextView tvRoomTitle, tvRoomNarrative;
    private LinearLayout roomActionsContainer;
    private Button btnBackFromRoom;

    // Ruang Belajar Terarah
    private TextView tvStudyTitle, tvStudyStatus, tvAyahArab, tvAyahMeaning;
    private LinearLayout studyActionsContainer;
    private Button btnLeaveStudy;

    // Setelan
    private TextView tvSetelanSummary;
    private LinearLayout setelanActionsContainer;

    // 5 Tab Bawah
    private Button tabBeranda, tabJelajah, tabKelas, tabRumah, tabSetelan;

    // State navigasi & sesi
    private String currentView = "BERANDA";
    private long lastBackPressMs = 0L;
    private boolean isInClassSession = false;

    // State Orientasi Usap 2 Jari
    private String activeRouteDest = "";
    private String activeRouteTitle = "";
    private MobilityCompassView.RouteStep[] activeRouteSteps = null;
    private int activeRouteStepIdx = 0;
    private boolean compassPracticeMode = false;
    private int compassPracticeDoneMask = 0;

    // State belajar aktif
    private int currentSurahNo = 114;
    private String currentSurahName = "An-Nas";
    private List<QuranRepository.AyahItem> currentAyahs = new ArrayList<>();
    private int currentAyahIdx = 0;
    private String currentStudyMode = "RUMAH"; // "KELAS" atau "RUMAH" / "PERPUS"
    private int activeBlockRepeatCount = 0;

    // Voice launcher (Bicara ke Guru)
    private ActivityResultLauncher<Intent> speechLauncher;

    private final BroadcastReceiver serviceStopReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (sequencer != null) sequencer.stop();
            if (narrator != null) narrator.stopSpeaking();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initEngines();
        initViews();
        setupListeners();
        setupSpeechLauncher();
        setupBackHandler();
        registerServiceReceiver();

        // Aktifkan Penjaga Waktu & Alarm Presisi (setAlarmClock)
        ReminderScheduler.scheduleAll(this);
        PondokBackgroundService.startTimekeeper(this);

        // Tangani pembukaan dari notifikasi alarm otomatis atau masuk Beranda
        handleStartupIntent(getIntent());
    }

    private void initEngines() {
        prefs = getSharedPreferences(AppConfig.PREF_NAME, MODE_PRIVATE);
        quranRepo = new QuranRepository(this);
        narrator = new NarratorManager(this, quranRepo);
        narrator.initTts();
        sequencer = new AudioSequencer(quranRepo, narrator);
        dbHelper = new MadrasahDbHelper(this);
        schedule = new SchoolScheduleEngine(this);
        living = new LivingMadrasahEngine(this, dbHelper);
        classroom = new InteractiveClassroomEngine(this);
        smart = classroom.getSmartEngine();
        smart.ensureFirstJoinRecorded();
        world = new PesantrenWorldEngine(this);
        firebase = new FirebaseMadrasahClient();
        gemini = new GeminiAiClient(this);
        quizEngine = new QuizGeneratorEngine();
        devices = new FacilityDeviceEngine(this);
        formalSchool = new FormalSchoolEngine(this);
        examEngine = new ExamIntegrityEngine(this);
        activeIqraJilid = living.getLastStudyIqraJilid();

        currentSurahNo = living.getLastStudySurahNo();
        currentSurahName = living.getLastStudySurahName();
        currentAyahIdx = Math.max(0, living.getLastStudyAyahNo() - 1);

        sequencer.setStatusListener(new AudioSequencer.StatusListener() {
            @Override
            public void onStatus(String message) {
                mainHandler.post(() -> {
                    if (tvStudyStatus != null && "BELAJAR".equals(currentView)) {
                        tvStudyStatus.setText(message);
                    }
                });
            }

            @Override
            public void onFinished() {
                mainHandler.post(() -> {
                    PondokBackgroundService.startTimekeeper(MainActivity.this);
                    onStudyAudioFinished();
                });
            }
        });
    }

    private void initViews() {
        mainScrollView = findViewById(R.id.mainScrollView);
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle);
        tvHeaderSubtitle = findViewById(R.id.tvHeaderSubtitle);
        btnTopMicGuru = findViewById(R.id.btnTopMicGuru);
        btnTopStopAudio = findViewById(R.id.btnTopStopAudio);

        viewBeranda = findViewById(R.id.viewBeranda);
        viewOrientasi = findViewById(R.id.viewOrientasi);
        viewRuangAktif = findViewById(R.id.viewRuangAktif);
        viewBelajarTerarah = findViewById(R.id.viewBelajarTerarah);
        viewSetelan = findViewById(R.id.viewSetelan);

        tvBerandaGreeting = findViewById(R.id.tvBerandaGreeting);
        tvBerandaMemory = findViewById(R.id.tvBerandaMemory);
        btnHeroAction = findViewById(R.id.btnHeroAction);
        berandaQuickContainer = findViewById(R.id.berandaQuickContainer);

        tvOrientasiTitle = findViewById(R.id.tvOrientasiTitle);
        tvOrientasiNarasi = findViewById(R.id.tvOrientasiNarasi);
        mobilityCompassView = findViewById(R.id.mobilityCompassView);
        panelCompassButtons = findViewById(R.id.panelCompassButtons);
        orientasiDestinationsContainer = findViewById(R.id.orientasiDestinationsContainer);
        btnDirUtara = findViewById(R.id.btnDirUtara);
        btnDirSelatan = findViewById(R.id.btnDirSelatan);
        btnDirTimur = findViewById(R.id.btnDirTimur);
        btnDirBarat = findViewById(R.id.btnDirBarat);
        btnEnterDoor = findViewById(R.id.btnEnterDoor);

        tvRoomTitle = findViewById(R.id.tvRoomTitle);
        tvRoomNarrative = findViewById(R.id.tvRoomNarrative);
        roomActionsContainer = findViewById(R.id.roomActionsContainer);
        btnBackFromRoom = findViewById(R.id.btnBackFromRoom);

        tvStudyTitle = findViewById(R.id.tvStudyTitle);
        tvStudyStatus = findViewById(R.id.tvStudyStatus);
        tvAyahArab = findViewById(R.id.tvAyahArab);
        tvAyahMeaning = findViewById(R.id.tvAyahMeaning);
        studyActionsContainer = findViewById(R.id.studyActionsContainer);
        btnLeaveStudy = findViewById(R.id.btnLeaveStudy);

        tvSetelanSummary = findViewById(R.id.tvSetelanSummary);
        setelanActionsContainer = findViewById(R.id.setelanActionsContainer);

        tabBeranda = findViewById(R.id.tabBeranda);
        tabJelajah = findViewById(R.id.tabJelajah);
        tabKelas = findViewById(R.id.tabKelas);
        tabRumah = findViewById(R.id.tabRumah);
        tabSetelan = findViewById(R.id.tabSetelan);
    }

    private void setupListeners() {
        btnTopMicGuru.setOnClickListener(v -> openTalkToTeacherScreen());
        btnTopStopAudio.setOnClickListener(v -> stopAllAudioNow());

        tabBeranda.setOnClickListener(v -> openBeranda());
        tabJelajah.setOnClickListener(v -> openOrientasiMenu());
        tabKelas.setOnClickListener(v -> handleEnterKelasTab());
        tabRumah.setOnClickListener(v -> openRumahSantri());
        tabSetelan.setOnClickListener(v -> openSetelan());

        btnBackFromRoom.setOnClickListener(v -> openBeranda());
        btnLeaveStudy.setOnClickListener(v -> handleLeaveStudyRoom());

        mobilityCompassView.setOnCompassSwipeListener(this::handleCompassStepInput);
        btnDirUtara.setOnClickListener(v -> handleCompassStepInput(MobilityCompassView.DIR_UTARA));
        btnDirSelatan.setOnClickListener(v -> handleCompassStepInput(MobilityCompassView.DIR_SELATAN));
        btnDirTimur.setOnClickListener(v -> handleCompassStepInput(MobilityCompassView.DIR_TIMUR));
        btnDirBarat.setOnClickListener(v -> handleCompassStepInput(MobilityCompassView.DIR_BARAT));

        btnEnterDoor.setOnClickListener(v -> enterDestinationDoor(activeRouteDest));
    }

    private void setupSpeechLauncher() {
        speechLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        ArrayList<String> matches = result.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                        if (matches != null && !matches.isEmpty()) {
                            processTeacherVoiceQuery(matches.get(0));
                        }
                    }
                }
        );
    }

    private void setupBackHandler() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if ("BELAJAR".equals(currentView)) {
                    handleLeaveStudyRoom();
                    return;
                }
                if (!"BERANDA".equals(currentView)) {
                    openBeranda();
                    return;
                }
                long now = System.currentTimeMillis();
                if (now - lastBackPressMs < 2200L) {
                    finish();
                } else {
                    lastBackPressMs = now;
                    toast("Tekan kembali sekali lagi untuk keluar dari Pondok Hafidz Netra.");
                    speak("Tekan kembali sekali lagi untuk keluar. Penjaga waktu tetap aktif di latar belakang.");
                }
            }
        });
    }

    private void registerServiceReceiver() {
        IntentFilter filter = new IntentFilter(PondokBackgroundService.BROADCAST_USER_STOPPED);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(serviceStopReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(serviceStopReceiver, filter);
        }
    }

    private void handleStartupIntent(Intent intent) {
        String openAction = intent == null ? null : intent.getStringExtra("open_action");
        if ("OPEN_KELAS".equals(openAction)) {
            handleEnterKelasTab();
        } else if ("OPEN_RUMAH".equals(openAction)) {
            openRumahSantri();
        } else if ("OPEN_WIRID_SORE".equals(openAction)) {
            openMasjidAgung("WIRID_SORE");
        } else if ("OPEN_MALAM_JUMAT".equals(openAction)) {
            openMasjidAgung("MALAM_JUMAT");
        } else if ("OPEN_DOA_PAGI".equals(openAction)) {
            openMasjidAgung("DOA_PAGI");
        } else {
            openBeranda();
        }
    }

    // ================= NAVIGASI PANEL & HEADER =================

    private void showPanel(String name) {
        currentView = name;
        viewBeranda.setVisibility("BERANDA".equals(name) ? View.VISIBLE : View.GONE);
        viewOrientasi.setVisibility("ORIENTASI".equals(name) ? View.VISIBLE : View.GONE);
        viewRuangAktif.setVisibility("RUANG".equals(name) ? View.VISIBLE : View.GONE);
        viewBelajarTerarah.setVisibility("BELAJAR".equals(name) ? View.VISIBLE : View.GONE);
        viewSetelan.setVisibility("SETELAN".equals(name) ? View.VISIBLE : View.GONE);

        highlightTab(tabBeranda, "BERANDA".equals(name));
        highlightTab(tabJelajah, "ORIENTASI".equals(name));
        highlightTab(tabKelas, "BELAJAR".equals(name) && "KELAS".equals(currentStudyMode));
        highlightTab(tabRumah, "RUANG".equals(name) && tvRoomTitle.getText().toString().contains("Rumah"));
        highlightTab(tabSetelan, "SETELAN".equals(name));

        if (mainScrollView != null) mainScrollView.scrollTo(0, 0);
        refreshHeader();
    }

    private void highlightTab(Button tab, boolean active) {
        if (tab == null) return;
        tab.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                Color.parseColor(active ? "#2A9D8F" : "#1D3557")));
    }

    private void refreshHeader() {
        String nama = living.getSantriName();
        int hariKe = smart.getDayNumberAtPondok();
        tvHeaderTitle.setText(nama + " • Hari ke-" + hariKe + " (" + living.getJenjangLabel() + ")");
        tvHeaderSubtitle.setText(schedule.getRealCalendarSummary()
                + " • Adab " + living.getAdabScore() + " • Stamina " + world.getStamina() + "%");
    }

    // ================= 1. BERANDA TERARAH =================

    private void openBeranda() {
        showPanel("BERANDA");
        berandaQuickContainer.removeAllViews();

        List<String> homeReady = living.getHomeReadySurahsForSchool();
        boolean izinYesterday = "IZIN".equalsIgnoreCase(living.getAttendanceTodayStatus())
                || "SAKIT".equalsIgnoreCase(living.getAttendanceTodayStatus());

        String emotionalGreeting = smart.buildTeacherEmotionalResponse(
                living.getPengasuhUtama(),
                living.getSantriName(),
                world.getStamina(),
                activeBlockRepeatCount,
                homeReady.size(),
                izinYesterday
        );

        tvBerandaGreeting.setText(emotionalGreeting);
        tvBerandaMemory.setText(smart.buildDailyContinuationBrief(living)
                + "\n\nPenjaga Waktu Otomatis: " + ReminderScheduler.getNextScheduleHint(this));

        if (!living.isAllTaarufDone()) {
            int nextPos = living.getNextTaarufPos();
            btnHeroAction.setText("Lanjutkan Masa Ta'aruf & Adab — Pos " + nextPos + " dari 4");
            btnHeroAction.setContentDescription("Lanjutkan Masa Ta'aruf dan Adab santri baru, Pos " + nextPos + " dari 4");
            btnHeroAction.setOnClickListener(v -> openTaarufHub());
        } else if (schedule.isRealSundayToday() && !schedule.isSimClockEnabled()) {
            btnHeroAction.setText("Hari Ahad Libur — Masuk Rumah Santri & Sambangan");
            btnHeroAction.setContentDescription("Hari Ahad libur resmi, masuk ke Rumah Santri dan Ruang Tamu");
            btnHeroAction.setOnClickListener(v -> openRumahSantri());
        } else if (schedule.isMalamJumatNow()) {
            btnHeroAction.setText("Malam Jumat — Ikuti Majelis Yasin & Doa Arwah");
            btnHeroAction.setContentDescription("Masuk ke Masjid Agung untuk Majelis Malam Jumat");
            btnHeroAction.setOnClickListener(v -> openMasjidAgung("MALAM_JUMAT"));
        } else if (schedule.isClassActiveNow()) {
            btnHeroAction.setText("Jam Kelas Aktif — Masuk Gedung Kelas Utama");
            btnHeroAction.setContentDescription("Masuk Gedung Kelas Utama untuk mengikuti 4 babak pelajaran");
            btnHeroAction.setOnClickListener(v -> handleEnterKelasTab());
        } else {
            btnHeroAction.setText("Jelajahi Pondok dengan Usap 2 Jari");
            btnHeroAction.setContentDescription("Buka Orientasi Mobilitas Usap 2 Jari menuju gedung pondok");
            btnHeroAction.setOnClickListener(v -> openOrientasiMenu());
        }

        // Hanya 4 akses inti yang bersih & manusiawi di Beranda (tanpa 12 tombol berjejal)
        ExamIntegrityEngine.DailyPondokEvent dailyEv = examEngine.getTodayAutomaticEvent();
        String evBadge = examEngine.isTodayEventCompleted() ? "[Selesai] " : "[Hari Ini] ";
        addDynamicBtn(berandaQuickContainer, evBadge + dailyEv.title, "#F4A261", () -> openDailyAutomaticEvent(dailyEv));
        addDynamicBtn(berandaQuickContainer, "Nuansa Online Firebase (Halaqah, Kehadiran Ruangan & Doa Semangat)", "#21867A", this::openFirebaseOnlineHub);
        addDynamicBtn(berandaQuickContainer, "Masa Ta'aruf & Adab Santri (" + living.getTaarufCompletedCount() + "/4 Pos)",
                "#1B4332", this::openTaarufHub);
        addDynamicBtn(berandaQuickContainer, "Kantor TU Ustadzah Nur & Ujian Resmi",
                "#1D3557", this::openKantorTu);
        addDynamicBtn(berandaQuickContainer, "Masjid Agung (Majelis Malam Jumat, Wirid & Jam Digital)",
                "#264653", () -> openMasjidAgung("NORMAL"));
        addDynamicBtn(berandaQuickContainer, "Koperasi Pondok & Perawatan Sarana Digital (" + devices.countDevicesNeedingCare() + " butuh rawat)",
                "#3A506B", this::openKoperasiSaranaDigital);

        announceForAccessibility(tvBerandaGreeting);
    }

    // ================= 2. ORIENTASI MOBILITAS USAP 2 JARI =================

    private void openOrientasiMenu() {
        showPanel("ORIENTASI");
        compassPracticeMode = false;
        activeRouteDest = "";
        activeRouteSteps = null;
        panelCompassButtons.setVisibility(View.GONE);
        btnEnterDoor.setVisibility(View.GONE);

        tvOrientasiTitle.setText("Orientasi Mobilitas Usap 2 Jari");
        String intro = "Pilih tujuan di bawah untuk berjalan menyusuri kompleks Pondok Hafidz Netra dengan usap 2 jari (4 arah kompas: Utara, Selatan, Timur, Barat). Tombol masuk pintu hanya muncul tepat saat kamu tiba di depan pintu.";
        tvOrientasiNarasi.setText(intro);
        mobilityCompassView.setStatusHint("Pilih tujuan di bawah atau mulai Latihan 4 Arah Kompas.");

        orientasiDestinationsContainer.removeAllViews();
        addDynamicBtn(orientasiDestinationsContainer, "Latihan Usap 2 Jari Mandiri (4 Arah Kompas)", "#F4A261",
                this::startCompassPracticeMode);
        addDynamicBtn(orientasiDestinationsContainer, "Berjalan ke Gedung Kelas Non-Formal Tahfidz/I'dad (3 Belokan)", "#2A9D8F",
                () -> startMobilityRoute("KELAS", "Gedung Kelas Non-Formal"));
        addDynamicBtn(orientasiDestinationsContainer, "Berjalan ke Gedung Sekolah Formal MI/MTs/MA/Ma'had Aly (3 Belokan)", "#21867A",
                () -> startMobilityRoute("SEKOLAH_FORMAL", "Gedung Sekolah Formal Pondok"));
        addDynamicBtn(orientasiDestinationsContainer, "Berjalan ke Kantor TU Ustadzah Nur (2 Belokan)", "#1D3557",
                () -> startMobilityRoute("TU", "Kantor TU Ustadzah Nur"));
        addDynamicBtn(orientasiDestinationsContainer, "Berjalan ke Masjid Agung (2 Belokan)", "#264653",
                () -> startMobilityRoute("MASJID", "Masjid Agung Pondok"));
        addDynamicBtn(orientasiDestinationsContainer, "Berjalan ke Perpustakaan Audio (2 Belokan)", "#457B9D",
                () -> startMobilityRoute("PERPUS", "Perpustakaan Pondok"));
        addDynamicBtn(orientasiDestinationsContainer, "Berjalan ke Koperasi Pondok (2 Belokan)", "#3A506B",
                () -> startMobilityRoute("KOPERASI", "Koperasi Pondok"));
        addDynamicBtn(orientasiDestinationsContainer, "Pulang ke Rumah Santri (2 Belokan)", "#1B4332",
                () -> startMobilityRoute("RUMAH", "Rumah Santri"));

        speak(intro);
    }

    private void startCompassPracticeMode() {
        showPanel("ORIENTASI");
        compassPracticeMode = true;
        compassPracticeDoneMask = 0;
        activeRouteSteps = null;
        panelCompassButtons.setVisibility(View.VISIBLE);
        btnEnterDoor.setVisibility(View.GONE);
        orientasiDestinationsContainer.removeAllViews();

        tvOrientasiTitle.setText("Latihan Usap 2 Jari Mandiri (4 Arah Kompas)");
        String msg = "Mari berlatih 4 arah kompas: Usap 2 jari ke Atas untuk UTARA, ke Bawah untuk SELATAN, ke Kanan untuk TIMUR, dan ke Kiri untuk BARAT. Kamu juga bisa mengetuk tombol arah bantu di bawah area kompas.";
        tvOrientasiNarasi.setText(msg);
        mobilityCompassView.setStatusHint("Coba usap 2 jari ke keempat arah kompas.");
        addDynamicBtn(orientasiDestinationsContainer, "Selesai Latihan & Pilih Tujuan Pondok", "#334E68", this::openOrientasiMenu);
        speak(msg);
    }

    private void startMobilityRoute(String destCode, String destTitle) {
        showPanel("ORIENTASI");
        compassPracticeMode = false;
        activeRouteDest = destCode;
        activeRouteTitle = destTitle;
        activeRouteSteps = MobilityCompassView.buildRouteForDestination(destCode);
        activeRouteStepIdx = 0;

        panelCompassButtons.setVisibility(View.VISIBLE);
        btnEnterDoor.setVisibility(View.GONE);
        orientasiDestinationsContainer.removeAllViews();
        addDynamicBtn(orientasiDestinationsContainer, "Ulangi / Ganti Tujuan Lain", "#334E68", this::openOrientasiMenu);

        tvOrientasiTitle.setText("Menuju: " + destTitle);
        String firstInst = activeRouteSteps[0].instruction;
        tvOrientasiNarasi.setText("Rute aktif menuju " + destTitle + " (" + activeRouteSteps.length + " tahap).\n\n" + firstInst);
        mobilityCompassView.setStatusHint(firstInst);
        speak("Mulai perjalanan menuju " + destTitle + ". " + firstInst);
    }

    private void handleCompassStepInput(String dir) {
        vibrateShort(35);
        if (compassPracticeMode) {
            if (MobilityCompassView.DIR_UTARA.equals(dir)) compassPracticeDoneMask |= 1;
            else if (MobilityCompassView.DIR_SELATAN.equals(dir)) compassPracticeDoneMask |= 2;
            else if (MobilityCompassView.DIR_TIMUR.equals(dir)) compassPracticeDoneMask |= 4;
            else if (MobilityCompassView.DIR_BARAT.equals(dir)) compassPracticeDoneMask |= 8;

            int doneCount = Integer.bitCount(compassPracticeDoneMask);
            String feedback = "Bagus! Kamu berhasil mengusap ke arah " + dir + " (" + doneCount + "/4 arah teruji).";
            if (doneCount == 4) {
                narrator.playCorrectChime();
                feedback += " MasyaAllah, keempat arah kompas sudah kamu kuasai! Sekarang kamu siap berjalan mandiri ke seluruh gedung pondok.";
            }
            tvOrientasiNarasi.setText(feedback);
            speak(feedback);
            return;
        }

        if (activeRouteSteps == null || activeRouteStepIdx >= activeRouteSteps.length) {
            return;
        }

        MobilityCompassView.RouteStep step = activeRouteSteps[activeRouteStepIdx];
        if (step.expectedDir.equals(dir)) {
            narrator.playCorrectChime();
            activeRouteStepIdx++;
            if (activeRouteStepIdx >= activeRouteSteps.length) {
                String arrived = step.arrivalNote + "\n\nTombol Masuk Pintu sekarang muncul tepat di depanmu. Ketuk untuk membuka pintu " + activeRouteTitle + ".";
                tvOrientasiNarasi.setText(arrived);
                mobilityCompassView.setStatusHint("Tiba tepat di depan pintu " + activeRouteTitle + ".");
                btnEnterDoor.setText("Masuk Pintu: " + activeRouteTitle);
                btnEnterDoor.setContentDescription("Kamu sudah di depan pintu. Ketuk untuk masuk ke " + activeRouteTitle);
                btnEnterDoor.setVisibility(View.VISIBLE);
                btnEnterDoor.requestFocus();
                announceForAccessibility(btnEnterDoor);
                speak(arrived);
            } else {
                MobilityCompassView.RouteStep next = activeRouteSteps[activeRouteStepIdx];
                String progress = step.arrivalNote + "\n\n" + next.instruction;
                tvOrientasiNarasi.setText(progress);
                mobilityCompassView.setStatusHint(next.instruction);
                speak(step.arrivalNote + " " + next.instruction);
            }
        } else {
            narrator.playWrongTone();
            vibrateShort(90);
            String correction = "Belum tepat, arah " + dir + " bukan jalur ke " + activeRouteTitle + ". "
                    + "Dari posisi ini, arah yang benar adalah " + MobilityCompassView.getDirectionGuideLabel(step.expectedDir) + ".\n\n"
                    + step.instruction;
            tvOrientasiNarasi.setText(correction);
            speak(correction);
        }
    }

    private void enterDestinationDoor(String destCode) {
        if ("KELAS".equals(destCode)) handleEnterKelasTab();
        else if ("SEKOLAH_FORMAL".equals(destCode)) openGedungSekolahFormal();
        else if ("TU".equals(destCode)) openKantorTu();
        else if ("MASJID".equals(destCode)) openMasjidAgung("NORMAL");
        else if ("PERPUS".equals(destCode)) openPerpustakaan();
        else if ("KOPERASI".equals(destCode)) openKoperasiSaranaDigital();
        else openRumahSantri();
    }

    // ================= 3. MASA TA'ARUF & ADAB 4 POS NYATA (TANPA TOMBOL INSTAN) =================

    private void openTaarufHub() {
        int done = living.getTaarufCompletedCount();
        StringBuilder sb = new StringBuilder();
        sb.append("Seperti di pesantren nyata, santri baru mengikuti Masa Ta'aruf & Pembekalan Adab secara bertahap (4 Pos) sebelum masuk kelas reguler — tidak ada tombol lewati instan.\n\n");
        sb.append("Status Progres (").append(done).append("/4 Pos):\n");
        sb.append(living.isTaarufPosDone(1) ? "[Selesai] " : "[Belum] ").append("Pos 1: Gerbang & Adab Salam (Kang Ridho)\n");
        sb.append(living.isTaarufPosDone(2) ? "[Selesai] " : "[Belum] ").append("Pos 2: Wawancara PSB Mendalam (Ustadzah Nur)\n");
        sb.append(living.isTaarufPosDone(3) ? "[Selesai] " : "[Belum] ").append("Pos 3: Bimbingan Adab & Perangkat Digital (Ustadzah Khadijah)\n");
        sb.append(living.isTaarufPosDone(4) ? "[Selesai] " : "[Belum] ").append("Pos 4: Ikrar Adab & Pelantikan Resmi (Ustadz Yeni Setiawan)");

        openRoomStage("Masa Ta'aruf & Adab Santri Hari ke-1", sb.toString(), "taaruf_gerbang.mp3");

        addDynamicBtn(roomActionsContainer, "Pos 1: Gerbang & Adab Salam (Kang Ridho)", "#2A9D8F", this::runTaarufPos1Gerbang);
        addDynamicBtn(roomActionsContainer, "Pos 2: Wawancara PSB Mendalam (Ustadzah Nur)", "#1D3557", this::runTaarufPos2Psb);
        addDynamicBtn(roomActionsContainer, "Pos 3: Bimbingan Adab & Kenal Sarana Digital (Ustadzah Khadijah)", "#264653", this::runTaarufPos3Adab);
        addDynamicBtn(roomActionsContainer, "Pos 4: Ikrar Adab & Pelantikan Resmi (Ustadz Yeni Setiawan)", "#1B4332", this::runTaarufPos4Pelantikan);
        addDynamicBtn(roomActionsContainer, "Latihan Usap 2 Jari Mandiri (4 Arah Kompas)", "#F4A261", this::startCompassPracticeMode);
    }

    private void runTaarufPos1Gerbang() {
        String nar = "Kang Ridho: Assalamu'alaikum warahmatullahi wabarakatuh! Selamat datang di Gerbang Utama Pondok Hafidz Netra.\n\n"
                + "Adab pertama masuk pondok adalah mengucap salam dengan ramah, menata niat ikhlas, dan mengenal arah jalan pondok. "
                + "Yuk balas salam Kang Ridho terlebih dahulu untuk menuntaskan Pos 1.";
        openRoomStage("Pos 1 Ta'aruf — Gerbang & Adab Salam", nar, "taaruf_gerbang.mp3");
        addDynamicBtn(roomActionsContainer, "Wa'alaikumussalam Kang Ridho, saya siap belajar adab", "#2A9D8F", () -> {
            living.markTaarufPosDone(LivingMadrasahEngine.TAARUF_POS_GERBANG);
            living.recordAdabAction("SALAM_GERBANG", 3, "Membalas salam Kang Ridho di Pos 1 Ta'aruf");
            narrator.playCorrectChime();
            toast("Pos 1 Ta'aruf tuntas! Nilai Adab +3.");
            openTaarufHub();
        });
    }

    private void runTaarufPos2Psb() {
        if (!living.isTaarufPosDone(1)) {
            toast("Selesaikan Pos 1 (Gerbang & Adab Salam) terlebih dahulu ya.");
            openTaarufHub();
            return;
        }
        openRoomStage("Pos 2 Ta'aruf — Wawancara PSB Mendalam (Ustadzah Nur)",
                "Ustadzah Nur: Assalamu'alaikum! Mari kita lengkapi identitas santri dan ikuti wawancara niat & kesiapan belajar (5 tahap) agar penempatan kelasmu tepat.",
                "taaruf_tu.mp3");

        EditText etNama = addInputField(roomActionsContainer, "Nama lengkap santri", living.getSantriName());
        EditText etKota = addInputField(roomActionsContainer, "Kota / Kabupaten asal", living.getSantriCity());
        EditText etWali = addInputField(roomActionsContainer, "Nama Orang Tua / Wali", living.getSantriWali());

        addDynamicBtn(roomActionsContainer, "Simpan Biodata & Lanjut Wawancara Niat (Tahap 1/3)", "#2A9D8F", () -> {
            String nm = etNama.getText().toString().trim();
            String kt = etKota.getText().toString().trim();
            String wl = etWali.getText().toString().trim();
            if (nm.isEmpty()) nm = "Santri Baru";
            if (kt.isEmpty()) kt = "Indonesia";
            if (wl.isEmpty()) wl = "Keluarga / Wali";
            String nis = living.getSantriNis().isEmpty()
                    ? "MHN-" + new SimpleDateFormat("yyMMdd", Locale.US).format(new Date())
                    : living.getSantriNis();
            living.saveSantriRegistration(nm, kt, wl, nis, living.getSantriTrack(), living.getClassSlot());
            runPsbInterviewStep(1, nm);
        });
    }

    private void runPsbInterviewStep(int step, String nama) {
        if (step == 1) {
            openRoomStage("Wawancara PSB (1/3) — Ustadzah Nur",
                    "Ustadzah Nur: Terima kasih " + nama + ". Apa niat utama kamu bergabung di Pondok Hafidz Netra?",
                    "taaruf_tu.mp3");
            addDynamicBtn(roomActionsContainer, "Menghafal Al-Qur'an bertahap dengan adab dan murajaah rutin", "#2A9D8F",
                    () -> runPsbInterviewStep(2, nama));
            addDynamicBtn(roomActionsContainer, "Memperbaiki bacaan Iqra', makhraj, dan tajwid dari dasar", "#1D3557",
                    () -> {
                        prefs.edit().putInt(AppConfig.KEY_JENJANG, 0).apply();
                        runPsbInterviewStep(2, nama);
                    });
        } else if (step == 2) {
            openRoomStage("Wawancara PSB (2/3) — Ustadzah Nur",
                    "Ustadzah Nur: Jika di tengah jam kelas ada keperluan mendesak, bagaimana adab santri yang benar?",
                    "");
            addDynamicBtn(roomActionsContainer, "Meminta izin terlebih dahulu kepada guru sebelum keluar kelas", "#2A9D8F",
                    () -> {
                        living.recordAdabAction("PSB_ADAB_IZIN", 3, "Memahami adab meminta izin keluar kelas");
                        runPsbInterviewStep(3, nama);
                    });
            addDynamicBtn(roomActionsContainer, "Langsung keluar diam-diam tanpa pamit", "#C1121F",
                    () -> {
                        String corr = "Ustadzah Nur: Kurang tepat ya " + nama + ". Di pondok, kita selalu membiasakan pamit dan izin kepada guru agar ilmu semakin berkah. Yuk pilih jawaban yang benar.";
                        tvRoomNarrative.setText(corr);
                        speak(corr);
                    });
        } else {
            openRoomStage("Wawancara PSB (3/3) — Penempatan Jenjang & Jam Kelas",
                    "Ustadzah Nur: MasyaAllah jawabanmu tepat! Sekarang pilih jenjang belajarmu agar kurikulum kelas otomatis menyesuaikan:",
                    "");
            addDynamicBtn(roomActionsContainer, "Jenjang I'dad (Fokus Iqra' Jilid Aktif)", "#2A9D8F", () -> {
                prefs.edit().putInt(AppConfig.KEY_JENJANG, 0).apply();
                finishTaarufPos2();
            });
            addDynamicBtn(roomActionsContainer, "Jenjang Tahfidz Reguler (Fokus 3 Langkah Hafalan)", "#1D3557", () -> {
                prefs.edit().putInt(AppConfig.KEY_JENJANG, 1).apply();
                finishTaarufPos2();
            });
        }
    }

    private void finishTaarufPos2() {
        living.markTaarufPosDone(LivingMadrasahEngine.TAARUF_POS_PSB);
        narrator.playCorrectChime();
        toast("Pos 2 (Wawancara PSB Mendalam) tuntas! Lanjut ke Pos 3 Bimbingan Adab.");
        openTaarufHub();
    }

    private void runTaarufPos3Adab() {
        if (!living.isTaarufPosDone(2)) {
            toast("Selesaikan Pos 2 (Wawancara PSB) terlebih dahulu ya.");
            openTaarufHub();
            return;
        }
        String nar = "Ustadzah Khadijah Rahmawati: Assalamu'alaikum " + living.getSantriName() + ". Di Pos 3 ini kita belajar 4 Adab Inti Penghafal Al-Qur'an:\n\n"
                + "1. Menjaga wudhu, niat ikhlas, dan ketenangan saat menyimak Qari.\n"
                + "2. Menghormati guru dan selalu meminta izin bila harus keluar di tengah jam kelas.\n"
                + "3. Menjaga adab di Masjid Agung & rutin mendoakan sesama di Majelis Malam Jumat.\n"
                + "4. Berbakti kepada orang tua/wali di Ruang Tamu Rumah serta merawat perangkat digital pondok melalui Koperasi.\n\n"
                + devices.buildLocationDevicesSummary("KELAS");
        openRoomStage("Pos 3 Ta'aruf — Bimbingan Adab & Sarana Digital", nar, "taaruf_asrama.mp3");
        addDynamicBtn(roomActionsContainer, "Saya memahami 4 Adab Inti & siap merawat sarana pondok", "#2A9D8F", () -> {
            living.markTaarufPosDone(LivingMadrasahEngine.TAARUF_POS_ADAB);
            living.recordAdabAction("ADAB_TAARUF_POS3", 4, "Menuntaskan Bimbingan 4 Adab Inti bersama Ustadzah Khadijah");
            narrator.playCorrectChime();
            toast("Pos 3 (Bimbingan Adab) tuntas! Lanjut ke Pos 4 Pelantikan.");
            openTaarufHub();
        });
    }

    private void runTaarufPos4Pelantikan() {
        if (!living.isTaarufPosDone(3)) {
            toast("Selesaikan Pos 3 (Bimbingan Adab) terlebih dahulu ya.");
            openTaarufHub();
            return;
        }
        String nar = "Ustadz Yeni Setiawan: Bismillahirrahmanirrahim. Selamat " + living.getSantriName()
                + ", kamu telah menempuh 3 Pos Ta'aruf dengan tertib.\n\n"
                + "Ikrar Adab Santri Pondok Hafidz Netra:\n"
                + "\"Saya berikrar menjaga adab terhadap Al-Qur'an, menghormati guru dan orang tua, jujur dalam setoran dan ujian, serta istiqamah murajaah di kelas maupun di rumah.\"\n\n"
                + "Ketuk tombol di bawah untuk mengikrarkan dan menerima Pelantikan Resmi.";
        openRoomStage("Pos 4 Ta'aruf — Ikrar Adab & Pelantikan Resmi", nar, "taaruf_pelantikan.mp3");
        addDynamicBtn(roomActionsContainer, "Bismillah, Saya Berikrar & Siap Dilantik Resmi", "#1B4332", () -> {
            living.markTaarufPosDone(LivingMadrasahEngine.TAARUF_POS_PELANTIKAN);
            living.recordAdabAction("IKRAR_PELANTIKAN", 5, "Mengucapkan Ikrar Adab & Dilantik Ustadz Yeni Setiawan");
            narrator.playCorrectChime();
            toast("Alhamdulillah! Masa Ta'aruf 4 Pos tuntas. Selamat menjadi Santri Resmi!");
            openBeranda();
        });
    }

    // ================= 4. KOPERASI PONDOK & 12 SARANA DIGITAL INTERAKTIF =================


    // ================= TAHAP 5: EKONOMI KEMANDIRIAN, PANEN PASIF, ASRAMA, DAPUR, KEBUN & PASAR =================

    private void openEkonomiAsramaHub() {
        syncPresenceRoom("Kompleks Asrama, Kebun & Pasar Pondok");
        long saldo = economy.getSaldoPondok();
        long pending = economy.getPendingPassiveIncome();
        long cap = economy.getTotalCycleIncomeCapacity();
        String nar = "PUSAT EKONOMI KEMANDIRIAN & KOMPLEKS ASRAMA PONDOK\n\n"
                + "• Saldo Kas Pondok: " + PondokEconomyEngine.formatRupiah(saldo) + "\n"
                + "• Kapasitas Penghasilan Pasif Aktif: " + PondokEconomyEngine.formatRupiah(cap)
                + " / " + PondokEconomyEngine.formatRupiah(PondokEconomyEngine.TARGET_PASSIVE_CAP) + "\n"
                + "• Penghasilan Pasif Siap Cair Sekarang: " + PondokEconomyEngine.formatRupiah(pending) + "\n"
                + "• Total Pemasukan Terkumpul: " + PondokEconomyEngine.formatRupiah(economy.getTotalIncomeEarned()) + "\n"
                + "• Stok Asrama: Kebun " + economy.getStokKebun() + " keranjang | Kolam "
                + economy.getStokKolam() + " paket | Dapur Asrama " + economy.getStokDapurAsrama() + " paket.";

        openRoomStage("Ekonomi Kemandirian, Asrama, Kebun & Pasar", nar, "");

        addDynamicBtn(roomActionsContainer,
                "Cairkan Panen Pasif Gedung Usaha (" + PondokEconomyEngine.formatRupiah(pending) + ")",
                "#2A9D8F", () -> {
                    long got = economy.claimPassiveIncome();
                    if (got > 0) {
                        narrator.playCorrectChime();
                        toast("Alhamdulillah! Panen pasif " + PondokEconomyEngine.formatRupiah(got) + " masuk ke Saldo Pondok!");
                    } else {
                        toast("Bangun gedung penghasilan dulu agar panen pasif berjalan.");
                    }
                    openEkonomiAsramaHub();
                });

        addDynamicBtn(roomActionsContainer, "Bangun & Tingkatkan Gedung Penghasilan / Toko (Target 500 Juta)",
                "#1D3557", this::openBangunGedungUsahaStage);
        addDynamicBtn(roomActionsContainer, "Kebun & Kolam Asrama (Panen Pasif Sayur, Jahe & Ikan)",
                "#1B4332", this::openKebunKolamAsramaStage);
        addDynamicBtn(roomActionsContainer, "Dapur Asrama (Masak Hasil Panen & Pulihkan Stamina Santri)",
                "#264653", this::openDapurAsramaStage);
        addDynamicBtn(roomActionsContainer, "Pasar Pondok (Jual Hasil Panen & Belanja Bahan Dapur Asrama)",
                "#F4A261", this::openPasarPondokStage);
    }

    private void openBangunGedungUsahaStage() {
        StringBuilder sb = new StringBuilder();
        sb.append("BANGUN & UPGRADE GEDUNG PENGHASILAN & TOKO PONDOK\n");
        sb.append("Saldo Kas Pondok: ").append(PondokEconomyEngine.formatRupiah(economy.getSaldoPondok())).append("\n");
        sb.append("Kapasitas Penghasilan Pasif: ")
                .append(PondokEconomyEngine.formatRupiah(economy.getTotalCycleIncomeCapacity()))
                .append(" / Rp 500.000.000\n\n");
        for (PondokEconomyEngine.BuildingUnit b : economy.getAllBuildings()) {
            sb.append("• ").append(b.name).append(" [Level ").append(b.level).append("/5] — Penghasilan: ")
                    .append(PondokEconomyEngine.formatRupiah(b.getCurrentCycleIncome())).append("\n");
        }
        openRoomStage("Bangun Gedung Penghasilan & Toko", sb.toString(), "");

        for (PondokEconomyEngine.BuildingUnit b : economy.getAllBuildings()) {
            String btnLabel = b.level == 0
                    ? "Bangun " + b.name + " (" + PondokEconomyEngine.formatRupiah(b.getNextUpgradeCost()) + ")"
                    : (b.level < 5
                    ? "Tingkatkan " + b.name + " ke Lv." + (b.level + 1) + " (" + PondokEconomyEngine.formatRupiah(b.getNextUpgradeCost()) + ")"
                    : b.name + " — Sudah Maksimal (Lv.5)");
            addDynamicBtn(roomActionsContainer, btnLabel, b.level >= 5 ? "#334E68" : "#2A9D8F", () -> {
                String res = economy.buildOrUpgradeUnit(b.id);
                narrator.playCorrectChime();
                toast(res);
                speak(res);
                openBangunGedungUsahaStage();
            });
        }
        addDynamicBtn(roomActionsContainer, "Kembali ke Pusat Ekonomi & Asrama", "#4A5568", this::openEkonomiAsramaHub);
    }

    private void openKebunKolamAsramaStage() {
        String nar = "KEBUN & KOLAM PANEN PASIF ASRAMA\n\n"
                + "Hasil Kebun Sayur & Rempah Jahe saat ini: " + economy.getStokKebun() + " keranjang.\n"
                + "Hasil Kolam Ikan Lele & Nila saat ini: " + economy.getStokKolam() + " paket.\n\n"
                + "Hasil panen bisa langsung dimasak di Dapur Asrama atau dijual ke Pasar Pondok untuk menambah Kas Pondok.";
        openRoomStage("Kebun & Kolam Panen Pasif Asrama", nar, "");
        addDynamicBtn(roomActionsContainer, "Panen Kebun & Kolam Asrama Sekarang", "#2A9D8F", () -> {
            String res = economy.harvestKebunDanKolamAsrama();
            living.recordAdabAction("PANEN_KEBUN", 2, "Memanen Kebun & Kolam Asrama Pondok");
            narrator.playCorrectChime();
            tvRoomNarrative.setText(res);
            speak(res);
        });
        addDynamicBtn(roomActionsContainer, "Bawa ke Dapur Asrama untuk Dimasak", "#264653", this::openDapurAsramaStage);
        addDynamicBtn(roomActionsContainer, "Bawa ke Pasar Pondok untuk Dijual", "#F4A261", this::openPasarPondokStage);
        addDynamicBtn(roomActionsContainer, "Kembali ke Pusat Ekonomi & Asrama", "#4A5568", this::openEkonomiAsramaHub);
    }

    private void openDapurAsramaStage() {
        String nar = "DAPUR ASRAMA PONDOK HAFIDZ NETRA\n\n"
                + "Persediaan Bahan: Kebun " + economy.getStokKebun() + " keranjang | Kolam "
                + economy.getStokKolam() + " paket | Stok Belanja Pasar " + economy.getStokDapurAsrama() + " paket.\n"
                + "Stamina kamu saat ini: " + world.getStamina() + "%.";
        openRoomStage("Dapur Asrama — Masak & Minuman Hangat", nar, "");
        addDynamicBtn(roomActionsContainer, "Masak Hidangan Bergizi & Sup Jahe (+30% Stamina & +2 Adab)", "#2A9D8F", () -> {
            String res = economy.cookAtDapurAsrama();
            if (res.contains("MasyaAllah") || res.contains("Alhamdulillah")) {
                world.changeStamina(30);
                living.recordAdabAction("MASAK_DAPUR_ASRAMA", 2, "Ikut menyiapkan hidangan di Dapur Asrama");
                narrator.playCorrectChime();
            }
            tvRoomNarrative.setText(res + "\nStamina saat ini: " + world.getStamina() + "%.");
            speak(res);
        });
        addDynamicBtn(roomActionsContainer, "Belanja Bahan Dapur di Pasar Pondok", "#1D3557", this::openPasarPondokStage);
        addDynamicBtn(roomActionsContainer, "Kembali ke Pusat Ekonomi & Asrama", "#4A5568", this::openEkonomiAsramaHub);
    }

    private void openPasarPondokStage() {
        narrator.playRawEffect(R.raw.sfx_suasana_pasar, null);
        String nar = "PASAR PONDOK HAFIDZ NETRA\n\n"
                + "Saldo Kas Pondok: " + PondokEconomyEngine.formatRupiah(economy.getSaldoPondok()) + "\n"
                + "Stok Panen Siap Jual: Kebun " + economy.getStokKebun() + " keranjang & Kolam " + economy.getStokKolam() + " paket.\n"
                + "Stok Bahan Dapur Asrama: " + economy.getStokDapurAsrama() + " paket.";
        openRoomStage("Pasar Pondok — Jual Panen & Belanja Dapur", nar, "");
        addDynamicBtn(roomActionsContainer, "Jual Semua Hasil Panen Kebun & Kolam ke Pasar Pondok", "#2A9D8F", () -> {
            String res = economy.sellHarvestAtPasarPondok();
            narrator.playCorrectChime();
            tvRoomNarrative.setText(res + "\nSaldo Kas Pondok: " + PondokEconomyEngine.formatRupiah(economy.getSaldoPondok()));
            speak(res);
        });
        addDynamicBtn(roomActionsContainer, "Belanja Grosir Bahan Dapur Asrama (+10 Paket, Rp 5.000.000)", "#1D3557", () -> {
            String res = economy.buyKitchenSuppliesAtPasarPondok();
            narrator.playCorrectChime();
            tvRoomNarrative.setText(res + "\nSaldo Kas Pondok: " + PondokEconomyEngine.formatRupiah(economy.getSaldoPondok()));
            speak(res);
        });
        addDynamicBtn(roomActionsContainer, "Kembali ke Pusat Ekonomi & Asrama", "#4A5568", this::openEkonomiAsramaHub);
    }

    private void openKoperasiSaranaDigital() {
        StringBuilder sb = new StringBuilder();
        sb.append("Koperasi Pondok Hafidz Netra — Pusat Perawatan 12 Sarana & Perangkat Digital Nyata.\n\n");
        for (FacilityDeviceEngine.DeviceInfo d : devices.getAllDevices()) {
            sb.append("• [").append(d.location).append("] ").append(d.name)
                    .append(": ").append(d.getConditionLabel()).append("\n");
        }
        openRoomStage("Koperasi Pondok & Perawatan Sarana Digital", sb.toString().trim(), "");

        addDynamicBtn(roomActionsContainer, "Rawat & Servis Semua Perangkat Digital (Gratis Berkah)", "#2A9D8F", () -> {
            String res = devices.serviceAllDevicesAtKoperasi();
            living.recordAdabAction("RAWAT_SARANA", 3, "Merawat seluruh sarana digital pondok lewat Koperasi");
            narrator.playCorrectChime();
            tvRoomNarrative.setText(res);
            speak(res);
        });

        for (FacilityDeviceEngine.DeviceInfo d : devices.getAllDevices()) {
            if (d.conditionPct < 100) {
                addDynamicBtn(roomActionsContainer, "Rawat " + d.name + " (" + d.conditionPct + "%)", "#1D3557", () -> {
                    String res = devices.serviceDeviceAtKoperasi(d.id);
                    living.recordAdabAction("RAWAT_" + d.id, 2, "Merawat " + d.name + " di Koperasi Pondok");
                    narrator.playCorrectChime();
                    toast(res);
                    openKoperasiSaranaDigital();
                });
            }
        }
    }

    // ================= 5. PINTU MASUK RUANGAN INTI (DIPERDALAM PENUH DI TAHAP 3 & 4) =================

    private void handleEnterKelasTab() {
        if (!living.isAllTaarufDone()) {
            String msg = "Kamu masih berada di Masa Ta'aruf Hari ke-1 (" + living.getTaarufCompletedCount()
                    + "/4 Pos selesai). Yuk tuntaskan dulu 4 Pos Ta'aruf & Adab sebelum masuk Gedung Kelas Utama.";
            toast(msg);
            speak(msg);
            openTaarufHub();
            return;
        }
        openGedungKelas();
    }

    private void openGedungKelas() {
        List<String> homeReady = living.getHomeReadySurahsForSchool();
        StringBuilder sb = new StringBuilder();
        sb.append("Selamat datang di Kompleks Pendidikan Pondok Hafidz Netra.\n");
        sb.append("Pilih jalur pendidikan hari ini: Pendidikan Non-Formal (Madrasah Tahfidz/I'dad) atau Pendidikan Formal (")
                .append(formalSchool.getFormalLevelLabel()).append(").\n\n");
        if (!homeReady.isEmpty()) {
            sb.append("PEMBERITAHUAN PEMBIMBING (Sinkron dari Rumah >=75%):\n");
            for (String item : homeReady) {
                String[] parts = item.split("\\|");
                if (parts.length >= 3) {
                    sb.append("• Surat ").append(parts[1]).append(" (").append(parts[2])
                            .append("% di Rumah) otomatis masuk pelajaran & setoran kelas!\n");
                }
            }
            sb.append("\n");
        }
        sb.append(devices.buildLocationDevicesSummary("KELAS"));

        openRoomStage("Gedung Kelas & Sekolah Pondok", sb.toString(), "bel_masuk_kelas.mp3");

        addDynamicBtn(roomActionsContainer,
                "Pendidikan Non-Formal: Masuk Alur 4 Babak (" + living.getJenjangLabel() + ")",
                "#2A9D8F", this::startNonFormalClassBabak1);

        if (!homeReady.isEmpty()) {
            String[] first = homeReady.get(0).split("\\|");
            if (first.length >= 3) {
                int sNo = Integer.parseInt(first[0]);
                String sName = first[1];
                addDynamicBtn(roomActionsContainer,
                        "Setoran Surat Matang dari Rumah: " + sName + " (" + first[2] + "%)",
                        "#F4A261", () -> {
                            currentSurahNo = sNo;
                            currentSurahName = sName;
                            currentAyahIdx = 0;
                            living.markHomeSurahSubmittedAtSchool(sNo);
                            startNonFormalClassBabak1();
                        });
            }
        }

        addDynamicBtn(roomActionsContainer,
                "Pendidikan Formal: Gedung Sekolah Formal (" + formalSchool.getFormalLevelLabel() + ")",
                "#1D3557", this::openGedungSekolahFormal);
    }

    // ================= PENDIDIKAN NON-FORMAL: ALUR 4 BABAK NYATA =================

    private void startNonFormalClassBabak1() {
        activeClassStage = 1;
        isInClassSession = true;
        currentStudyMode = "KELAS";
        String devMsg = devices.useDevice(FacilityDeviceEngine.DEV_MESIN_PRESENSI, "Presensi masuk kelas");
        String statusHadir = schedule.isClassActiveNow() ? "HADIR" : "TERLAMBAT";
        schedule.recordAttendanceStatus(statusHadir);
        living.markHadirTodayWithType(statusHadir, "Hadir Babak 1 Kelas " + living.getJenjangLabel());
        living.recordAdabAction("SALAM_KELAS", 2, "Mengucap salam dan presensi di Mesin Presensi Kelas");

        String emotional = smart.buildTeacherEmotionalResponse(
                living.getPengasuhUtama(), living.getSantriName(), world.getStamina(),
                activeBlockRepeatCount, living.getHomeReadySurahsForSchool().size(), false);

        String nar = "BABAK 1 dari 4 — Bel Masuk & Presensi Digital\n\n"
                + devMsg + " (Status: " + statusHadir + ").\n\n"
                + emotional + "\n\n"
                + "Adab Kelas: Mari awali dengan doa belajar dan niat ikhlas.";
        narrator.playRawEffect(R.raw.sfx_bel_masuk_sekolah, null);
        openRoomStage("Babak 1/4 — Bel & Presensi Kelas", nar, "");
        addDynamicBtn(roomActionsContainer, "Lanjut ke Babak 2: Cek PR & Murajaah Kemarin", "#2A9D8F",
                this::startNonFormalClassBabak2);
    }

    private void startNonFormalClassBabak2() {
        activeClassStage = 2;
        String brief = smart.buildDailyContinuationBrief(living);
        List<String> retry = smart.getTomorrowRetryItems();
        String nar = "BABAK 2 dari 4 — Cek PR & Murajaah Kemarin\n\n"
                + brief + "\n\n"
                + (retry.isEmpty()
                ? "Tidak ada tunggakan PR sulit dari kemarin. Siap langsung masuk ke Babak 3 materi inti hari ini!"
                : "Mari kita murajaah sebentar PR kemarin (" + retry.get(0) + ") sebelum masuk materi baru.");
        openRoomStage("Babak 2/4 — Cek PR & Murajaah", nar, "");
        addDynamicBtn(roomActionsContainer, "Lanjut ke Babak 3: Materi & Blok Hafalan Terarah", "#2A9D8F",
                this::startNonFormalClassBabak3);
    }

    private void startNonFormalClassBabak3() {
        activeClassStage = 3;
        narrator.playRawEffect(R.raw.sfx_bel_ganti_pelajaran, null);
        devices.useDevice(FacilityDeviceEngine.DEV_SMARTBOARD_AUDIO, "Buka materi kelas Babak 3");
        if (living.getJenjangIndex() == 0) {
            // Jenjang I'dad: Fokus Iqra' Jilid Aktif (tidak campur aduk)
            openIdadIqraClassStage();
        } else {
            // Jenjang Tahfidz: Fokus 3 Langkah Jelas (Materi Hari Ini -> Blok Hafalan Target -> Setoran Harian)
            openTahfidzThreeStepStage();
        }
    }

    private void openIdadIqraClassStage() {
        String[] jilidTopics = {
                "Iqra' Jilid 1 — Pengenalan Huruf Hijaiyah Fathah (Alif sampai Ya)",
                "Iqra' Jilid 2 — Huruf Sambung & Bacaan Mad Pendek-Panjang",
                "Iqra' Jilid 3 — Kasrah, Dhammah & Panjang 2 Harakat",
                "Iqra' Jilid 4 — Tanwin, Sukun & Qalqalah Dasar",
                "Iqra' Jilid 5 — Tasydid, Alif Lam & Idgham Dasar",
                "Iqra' Jilid 6 — Kelancaran Tajwid, Waqaf & Persiapan Al-Qur'an"
        };
        int idx = Math.max(0, Math.min(5, activeIqraJilid - 1));
        String topic = jilidTopics[idx];
        String nar = "BABAK 3 dari 4 — Kelas I'dad (Fokus Iqra' Jilid " + activeIqraJilid + ")\n\n"
                + "Smartboard Audio menyajikan: " + topic + ".\n"
                + "Simak contoh makhraj dari pembimbing lalu tirukan perlahan.";
        openRoomStage("Babak 3/4 — Kelas I'dad Iqra' Jilid " + activeIqraJilid, nar, "");
        addDynamicBtn(roomActionsContainer, "Dengarkan Contoh Makhraj & Latihan Iqra' Jilid " + activeIqraJilid, "#2A9D8F", () -> {
            String drill = "Bismillah, mari tirukan pelan-pelan materi " + topic
                    + ". Perhatikan panjang pendek harakat dan keluarnya huruf dari makhraj yang benar.";
            speak(drill);
            living.saveLastStudyCheckpoint(currentSurahNo, currentSurahName, currentAyahIdx + 1,
                    activeIqraJilid, "Kelas I'dad", topic);
        });
        addDynamicBtn(roomActionsContainer, "Sudah Lancar Jilid " + activeIqraJilid + " -> Naik / Lanjut Babak 4", "#1B4332", () -> {
            if (activeIqraJilid < 6) activeIqraJilid++;
            living.boostGrade(AppConfig.KEY_GRADE_KELANCARAN, 3);
            smart.appendMutabaah("Kelas I'dad", topic, 90, "Lancar di kelas Babak 3");
            startNonFormalClassBabak4("Iqra' Jilid " + activeIqraJilid);
        });
        addDynamicBtn(roomActionsContainer, "Masih Perlu Latihan -> Catat PR Rumah & Lanjut Babak 4", "#F4A261", () -> {
            smart.addTomorrowRetryItem(0, "Iqra' Jilid " + activeIqraJilid, 1);
            startNonFormalClassBabak4("PR Murajaah Iqra' Jilid " + activeIqraJilid);
        });
    }

    private void openTahfidzThreeStepStage() {
        String nar = "BABAK 3 dari 4 — Kelas Tahfidz (3 Langkah Jelas)\n"
                + "Surat Target: " + currentSurahName + " (Ayat " + (currentAyahIdx + 1) + ").\n\n"
                + "Alur Kelas Tahfidz terarah tanpa tombol campur aduk:\n"
                + "1. Materi Hari Ini (Simak Qari & Makna)\n"
                + "2. Blok Hafalan Target (Auto-Respon Manusiawi & Otomatis Lanjut saat 100% Hijau)\n"
                + "3. Setoran Harian (Uji Kelancaran ke Pembimbing)";
        openRoomStage("Babak 3/4 — Kelas Tahfidz 3 Langkah", nar, "");
        addDynamicBtn(roomActionsContainer, "Langkah 1: Materi Hari Ini (Buka Smartboard Audio)", "#2A9D8F", () -> {
            currentStudyMode = "KELAS";
            openBelajarPanel("Kelas Tahfidz — Langkah 1 & 2 (Auto-Respon)");
        });
        addDynamicBtn(roomActionsContainer, "Langkah 3: Setoran Harian & Lanjut Babak 4 (Bel Pulang)", "#1B4332", () -> {
            living.boostGrade(AppConfig.KEY_GRADE_KELANCARAN, 4);
            smart.appendMutabaah("Setoran Kelas", currentSurahName + " Ayat " + (currentAyahIdx + 1), 92, "Setoran harian tuntas");
            narrator.playCorrectChime();
            startNonFormalClassBabak4("Setoran " + currentSurahName + " selesai lancar");
        });
    }

    private void startNonFormalClassBabak4(String summaryNote) {
        activeClassStage = 4;
        isInClassSession = false;
        narrator.playRawEffect(R.raw.sfx_bel_pulang_sekolah, null);
        living.saveLastStudyCheckpoint(currentSurahNo, currentSurahName, currentAyahIdx + 1,
                activeIqraJilid, "Gedung Kelas", summaryNote);
        String nar = "BABAK 4 dari 4 — Evaluasi, PR Rumah & Bel Pulang\n\n"
                + "Ringkasan hari ini: " + summaryNote + ".\n"
                + "Memori Lanjutan Belajar sudah disimpan untuk pertemuan berikutnya. "
                + "Jika ingin latihan bebas (20 metode, Juz 1-30, atau Iqra' manual), silakan lanjutkan di Kamar Pribadi Rumah atau Perpustakaan.\n\n"
                + "Bel pulang berbunyi. Alhamdulillahi rabbil 'alamin!";
        openRoomStage("Babak 4/4 — Evaluasi & Bel Pulang", nar, "salam_penutup.mp3");
        addDynamicBtn(roomActionsContainer, "Pulang ke Rumah Santri", "#2A9D8F", this::openRumahSantri);
        addDynamicBtn(roomActionsContainer, "Kembali ke Beranda", "#334E68", this::openBeranda);
    }

    // ================= PENDIDIKAN FORMAL: GEDUNG SEKOLAH FORMAL PONDOK =================

    private void openGedungSekolahFormal() {
        StringBuilder sb = new StringBuilder();
        sb.append("Gedung Sekolah Formal Pondok Hafidz Netra — Jenjang Aktif: ")
                .append(formalSchool.getFormalLevelLabel()).append(".\n");
        sb.append("Sesi Formal Tuntas: ").append(formalSchool.getCompletedFormalSessions())
                .append(" | Rata-rata Nilai Formal: ").append(formalSchool.getFormalScoreAverage()).append(".\n\n");
        sb.append("Pilih mata pelajaran formal ramah tunanetra di bawah atau ganti jenjang formal:");

        openRoomStage("Gedung Sekolah Formal — " + formalSchool.getFormalLevelLabel(), sb.toString(), "bel_masuk_kelas.mp3");

        for (FormalSchoolEngine.FormalLesson lesson : formalSchool.getLessonsForCurrentLevel()) {
            addDynamicBtn(roomActionsContainer,
                    lesson.subject + " — " + lesson.topic,
                    "#1D3557", () -> runFormalLessonBabak(lesson));
        }

        addDynamicBtn(roomActionsContainer, "Ganti Jenjang Formal (MI/SD, MTs/SMP, MA/SMA, Ma'had Aly)", "#457B9D", () -> {
            openRoomStage("Pilih Jenjang Pendidikan Formal",
                    "Pilih jenjang sekolah formal yang sedang kamu tempuh:", "");
            for (int i = 0; i < FormalSchoolEngine.FORMAL_LEVELS.length; i++) {
                final int idx = i;
                addDynamicBtn(roomActionsContainer, FormalSchoolEngine.FORMAL_LEVELS[i], "#2A9D8F", () -> {
                    formalSchool.setFormalLevelIndex(idx);
                    toast("Jenjang Sekolah Formal diatur ke " + FormalSchoolEngine.FORMAL_LEVELS[idx]);
                    openGedungSekolahFormal();
                });
            }
        });
    }

    private void runFormalLessonBabak(FormalSchoolEngine.FormalLesson lesson) {
        narrator.playRawEffect(R.raw.sfx_bel_jam_pertama, null);
        devices.useDevice(FacilityDeviceEngine.DEV_SMARTBOARD_AUDIO, "Pelajaran Formal " + lesson.subject);
        String nar = "BABAK 1-2: Presensi & Materi Sekolah Formal\n"
                + "Pengampu: " + lesson.teacher + "\n"
                + "Topik: " + lesson.topic + "\n\n"
                + lesson.explanation + "\n\n"
                + "BABAK 3: Pertanyaan Pemahaman — " + lesson.question;
        openRoomStage(lesson.subject, nar, "");

        for (int i = 0; i < lesson.choices.length; i++) {
            final int choiceIdx = i;
            addDynamicBtn(roomActionsContainer, (i + 1) + ". " + lesson.choices[i], "#264653", () -> {
                if (choiceIdx == lesson.correctIdx) {
                    narrator.playCorrectChime();
                    formalSchool.recordFormalSessionResult(lesson.subject, 95);
                    living.boostGrade(AppConfig.KEY_GRADE_DINIYAH, 3);
                    smart.appendMutabaah("Sekolah Formal", lesson.subject + " — " + lesson.topic, 95, "Paham & lulus evaluasi");
                    String done = "BABAK 4: Evaluasi & Bel Pulang Sekolah Formal\n\n"
                            + lesson.teacher + ": MasyaAllah, jawabanmu tepat sekali! Nilai 95 tercatat.\n"
                            + "PR Rumah: " + lesson.homework;
                    openRoomStage("Selesai Pelajaran — " + lesson.subject, done, "chime_lulus_benar.mp3");
                    addDynamicBtn(roomActionsContainer, "Kembali ke Gedung Sekolah Formal", "#2A9D8F", this::openGedungSekolahFormal);
                } else {
                    narrator.playWrongTone();
                    String retryMsg = lesson.teacher + ": Belum tepat ya. Coba simak kembali inti materinya: "
                            + lesson.explanation + "\nSilakan pilih jawaban yang paling sesuai.";
                    tvRoomNarrative.setText(retryMsg);
                    speak(retryMsg);
                }
            });
        }
    }

    // ================= RUMAH SANTRI HIDUP — 4 RUANGAN NYATA & SINKRON SEKOLAH =================

    private void openRumahSantri() {
        List<String> ready = living.getHomeReadySurahsForSchool();
        String nar = "Assalamu'alaikum di Rumah Santri. Semua latihan mandiri di rumah tercatat otomatis, "
                + "dan begitu surat/blok mencapai >=75% akan langsung muncul di pemberitahuan pembimbing Sekolah!\n"
                + "Surat Rumah Siap Setoran Sekolah: " + ready.size() + " surat.\n\n"
                + devices.buildLocationDevicesSummary("RUMAH");
        openRoomStage("Rumah Santri — 4 Ruangan Nyata", nar, "taaruf_asrama.mp3");

        addDynamicBtn(roomActionsContainer, "1. Kamar Pribadi (Meja Belajar Bebas 24 Jam, Jurnal ke TU & Istirahat)",
                "#2A9D8F", this::openKamarPribadi);
        addDynamicBtn(roomActionsContainer, "2. Ruang Tamu (Ngobrol Orang Tua/Wali, Buku Penghubung & Sambangan Ahad)",
                "#1D3557", this::openRuangTamuRumah);
        addDynamicBtn(roomActionsContainer, "3. Dapur Rumah (Sarapan Sehat & Minuman Hangat Penjaga Suara)",
                "#264653", this::openDapurRumah);
        addDynamicBtn(roomActionsContainer, "4. Keluar Pintu ke Teras / Taman Rumah (Murajaah, Siram Tanaman & Berangkat)",
                "#1B4332", this::openTerasTamanRumah);
    }

    private void openKamarPribadi() {
        String nar = "Kamar Pribadi — Ruang Belajar Bebas 24 Jam.\n"
                + "Di sini kamu bebas memilih surat pendek Juz 30 atau Juz 1-30, 20 metode hafalan, atau Iqra' manual, "
                + "serta menulis Jurnal Refleksi untuk dikirim langsung ke Komputer Server TU Ustadzah Nur.\n\n"
                + "Aktivitas Rumah Terakhir:\n" + living.getHomeActivityLogSummary();
        openRoomStage("Kamar Pribadi Rumah Santri", nar, "");

        addDynamicBtn(roomActionsContainer, "Buka Mushaf Digital & Meja Belajar Bebas (Juz 1-30 / 20 Metode)", "#2A9D8F", () -> {
            devices.useDevice(FacilityDeviceEngine.DEV_MUSHAF_DIGITAL, "Belajar bebas di Kamar Pribadi");
            currentStudyMode = "RUMAH";
            openBelajarPanel("Kamar Pribadi — Meja Belajar Bebas 24 Jam");
        });
        addDynamicBtn(roomActionsContainer, "Putar Speaker Murottal Santai (Surat Aktif: " + currentSurahName + ")", "#21867A", () -> {
            devices.useDevice(FacilityDeviceEngine.DEV_SPEAKER_MUROTTAL, "Putar murottal santai " + currentSurahName);
            currentStudyMode = "RUMAH";
            openBelajarPanel("Speaker Murottal Rumah — " + currentSurahName);
        });
        addDynamicBtn(roomActionsContainer, "Buku Catatan Digital: Tulis Jurnal / PR Rumah & Kirim ke Server TU", "#1D3557",
                this::openBukuCatatanJurnalKeTu);
        addDynamicBtn(roomActionsContainer, "Istirahat & Tidur Siang (Bel Istirahat +20% Stamina)", "#3A506B", () -> {
            narrator.playRawEffect(R.raw.sfx_bel_istirahat, null);
            world.changeStamina(20);
            String msg = "Alhamdulillah, istirahat di Kamar Pribadi memulihkan staminamu menjadi " + world.getStamina() + "%.";
            tvRoomNarrative.setText(msg);
            speak(msg);
        });
        addDynamicBtn(roomActionsContainer, "Kembali ke 4 Ruangan Rumah", "#4A5568", this::openRumahSantri);
    }

    private void openBukuCatatanJurnalKeTu() {
        devices.useDevice(FacilityDeviceEngine.DEV_BUKU_CATATAN, "Buka Buku Catatan Digital");
        openRoomStage("Buku Catatan Digital — Kirim ke Komputer Server TU",
                "Tulis jurnal refleksi belajar, kendala hafalan, atau laporan PR rumahmu. Catatan ini akan langsung masuk ke Komputer Server TU dan ditanggapi Ustadzah Nur.\n\n"
                        + "Tanggapan Terbaru Ustadzah Nur:\n" + formalSchool.getLatestTuRepliesSummary(),
                "");
        EditText etJurnal = addInputField(roomActionsContainer, "Tulis catatan refleksi atau laporan PR rumah di sini...", "");
        addDynamicBtn(roomActionsContainer, "Kirim Catatan ke Komputer Server TU", "#2A9D8F", () -> {
            String txt = etJurnal.getText().toString().trim();
            if (txt.isEmpty()) {
                toast("Tulis dulu isi catatan atau PR rumahmu ya.");
                return;
            }
            formalSchool.sendHomeJournalToTu(living.getSantriName(), "Jurnal & PR Rumah", txt);
            living.recordAdabAction("KIRIM_JURNAL_TU", 2, "Mengirim jurnal refleksi rumah ke Server TU");
            narrator.playCorrectChime();
            toast("Catatan terkirim ke Komputer Server TU! Cek tanggapan Ustadzah Nur di Kantor TU.");
            openKamarPribadi();
        });
        addDynamicBtn(roomActionsContainer, "Kembali ke Kamar Pribadi", "#4A5568", this::openKamarPribadi);
    }

    private void openRuangTamuRumah() {
        boolean isAhad = schedule.isRealSundayToday() && !schedule.isSimClockEnabled();
        living.recordAdabAction("SAPA_ORTU", 2, "Berbakti & menyapa orang tua/wali di Ruang Tamu");
        String greeting = isAhad
                ? "Suasana Sambangan Hari Ahad yang hangat! " + living.getSantriWali()
                + " duduk menemanimu di Ruang Tamu sambil mendengarkan cerita belajar selama sepekan."
                : living.getSantriWali() + ": Assalamu'alaikum nak " + living.getSantriName()
                + ", bagaimana pelajaran kelas dan murajaahmu hari ini? Semoga Allah berkahi ilmumu.";
        String bukuPenghubung = "\n\nBuku Penghubung Keluarga:\n"
                + "• Gelar Kehormatan: " + living.getHonorTitle() + "\n"
                + "• Nilai Adab: " + living.getAdabScore() + " | Kelancaran: " + living.getKelancaranScore() + "\n"
                + "• Sesi Sekolah Formal Tuntas: " + formalSchool.getCompletedFormalSessions()
                + " (Rata-rata: " + formalSchool.getFormalScoreAverage() + ")\n"
                + "• Surat Matang dari Rumah (>=75%): " + living.getHomeReadySurahsForSchool().size() + " surat.";

        openRoomStage("Ruang Tamu Rumah — " + living.getSantriWali(), greeting + bukuPenghubung, "");
        addDynamicBtn(roomActionsContainer, "Ceritakan Progres Hari Ini & Mohon Doa Restu Orang Tua", "#2A9D8F", () -> {
            String doa = living.getSantriWali() + ": MasyaAllah nak " + living.getSantriName()
                    + ", orang tua selalu mendoakanmu di setiap shalat agar menjadi penghafal Al-Qur'an yang berakhlak mulia.";
            tvRoomNarrative.setText(doa);
            speak(doa);
        });
        addDynamicBtn(roomActionsContainer, "Kembali ke 4 Ruangan Rumah", "#4A5568", this::openRumahSantri);
    }

    private void openDapurRumah() {
        openRoomStage("Dapur Rumah — Sarapan & Minuman Hangat",
                "Aroma jahe hangat dan sarapan rumah menenangkan hati. Stamina saat ini: " + world.getStamina() + "%.",
                "");
        addDynamicBtn(roomActionsContainer, "Minum Air Hangat Madu Jahe (Penjaga Suara +15% Stamina)", "#2A9D8F", () -> {
            world.changeStamina(15);
            String msg = "Bismillah, minum sambil duduk dengan 3 tegukan pelan. Tenggorokan terasa lega! Stamina: " + world.getStamina() + "%.";
            tvRoomNarrative.setText(msg);
            speak(msg);
        });
        addDynamicBtn(roomActionsContainer, "Sarapan Sehat Pagi (Pulihkan Stamina +25%)", "#1D3557", () -> {
            world.changeStamina(25);
            String msg = "Alhamdulillah, sarapan bergizi selesai! Tubuh siap untuk menghafal dan bersekolah. Stamina: " + world.getStamina() + "%.";
            tvRoomNarrative.setText(msg);
            speak(msg);
        });
        addDynamicBtn(roomActionsContainer, "Kembali ke 4 Ruangan Rumah", "#4A5568", this::openRumahSantri);
    }

    private void openTerasTamanRumah() {
        openRoomStage("Teras & Taman Rumah — Titik Berangkat ke Pondok",
                "Udara segar menyapa di Teras Rumah. Dari sini kamu bisa murajaah pagi santai, menyiram tanaman, "
                        + "berlatih Usap 2 Jari, atau langsung berangkat menuju gedung-gedung pondok.",
                "");
        addDynamicBtn(roomActionsContainer, "Berangkat ke Pondok (Orientasi Mobilitas Usap 2 Jari)", "#2A9D8F",
                this::openOrientasiMenu);
        addDynamicBtn(roomActionsContainer, "Siram Tanaman Taman (+2 Nilai Adab Peduli Lingkungan)", "#1B4332", () -> {
            living.recordAdabAction("SIRAM_TANAMAN", 2, "Menyiram tanaman di Taman Rumah");
            narrator.playCorrectChime();
            String msg = "Alhamdulillah, tanaman di taman terasa segar kembali. Nilai Adab peduli lingkungan bertambah (+2)!";
            tvRoomNarrative.setText(msg);
            speak(msg);
        });
        addDynamicBtn(roomActionsContainer, "Latihan Usap 2 Jari Mandiri di Teras", "#F4A261",
                this::startCompassPracticeMode);
        addDynamicBtn(roomActionsContainer, "Kembali ke 4 Ruangan Rumah", "#4A5568", this::openRumahSantri);
    }

    // ================= KEGIATAN OTOMATIS HARIAN & NUANSA ONLINE FIREBASE =================

    private void openDailyAutomaticEvent(ExamIntegrityEngine.DailyPondokEvent ev) {
        String nar = "MESIN KEGIATAN OTOMATIS PONDOK HARI INI\n\n"
                + "Kegiatan: " + ev.title + "\n"
                + "Pemateri / Pembimbing: " + ev.host + "\n\n"
                + ev.description + "\n\n"
                + "Manfaat: " + ev.rewardNote;
        openRoomStage(ev.title, nar, "corong_pengumuman.mp3");
        if (!examEngine.isTodayEventCompleted()) {
            addDynamicBtn(roomActionsContainer, "Ikuti & Tuntaskan Kegiatan Hari Ini", "#2A9D8F", () -> {
                examEngine.markTodayEventCompleted();
                living.recordAdabAction("KEGIATAN_HARIAN", 3, "Mengikuti kegiatan harian: " + ev.title);
                living.boostGrade(AppConfig.KEY_GRADE_KELANCARAN, 2);
                smart.appendMutabaah("Kegiatan Pondok", ev.title, 95, "Hadir aktif kegiatan harian otomatis");
                narrator.playCorrectChime();
                toast("Alhamdulillah! Kegiatan harian tercatat di Mutaba'ah (+3 Adab).");
                openBeranda();
            });
        } else {
            addDynamicBtn(roomActionsContainer, "Kegiatan Hari Ini Sudah Dituntaskan (Kembali ke Beranda)", "#334E68", this::openBeranda);
        }
    }

    private void syncPresenceRoom(String roomName) {
        if (living.getSantriNis().isEmpty()) return;
        bgExecutor.execute(() -> {
            try {
                firebase.syncSantriStatusAndGrade(
                        living.getSantriNis(),
                        living.getSantriName(),
                        living.getGenderedRoomName(),
                        living.getFourScoreAverage(),
                        living.getHonorTitle(),
                        "Aktif di " + roomName
                );
            } catch (Exception ignored) {}
        });
    }

    private void openFirebaseOnlineHub() {
        syncPresenceRoom("Halaqah Online Firebase");
        openRoomStage("Nuansa Online Firebase — Kehadiran & Doa Semangat",
                "Memuat kehadiran santri online per ruangan aktif, Corong Pondok, dan Doa Semangat dari server Firebase RTDB...",
                "");

        bgExecutor.execute(() -> {
            FirebaseMadrasahClient.HalaqahSummary summary = firebase.fetchHalaqahSummary();
            String latestCorong = firebase.fetchLatestCorongBroadcast();
            mainHandler.post(() -> {
                StringBuilder sb = new StringBuilder();
                sb.append("CORONG PONDOK TERBARU:\n")
                        .append(latestCorong == null || latestCorong.isEmpty() ? "Belum ada siaran corong terbaru." : latestCorong)
                        .append("\n\nKEHADIRAN SANTRI ONLINE PER RUANGAN:\n");
                if (summary != null && summary.leaderboard != null && !summary.leaderboard.isEmpty()) {
                    for (int i = 0; i < Math.min(8, summary.leaderboard.size()); i++) {
                        FirebaseMadrasahClient.SantriRow row = summary.leaderboard.get(i);
                        sb.append("• ").append(row.nama).append(" — ").append(row.statusHariIni)
                                .append(" (Nilai: ").append(row.nilaiAkhir).append(")\n");
                    }
                } else {
                    sb.append("• ").append(living.getSantriName()).append(" — Aktif di Pondok (Menunggu koneksi santri lain)\n");
                }
                sb.append("\nDOA SEMANGAT SAHABAT SANTRI:\n");
                if (summary != null && summary.doaSemangat != null && !summary.doaSemangat.isEmpty()) {
                    for (int i = 0; i < Math.min(5, summary.doaSemangat.size()); i++) {
                        sb.append("• ").append(summary.doaSemangat.get(i)).append("\n");
                    }
                } else {
                    sb.append("Belum ada doa semangat terbaru. Jadilah yang pertama mengirim doa!");
                }
                tvRoomNarrative.setText(sb.toString());
            });
        });

        EditText etDoa = addInputField(roomActionsContainer, "Tulis Doa Semangat untuk sahabat santri...", "");
        addDynamicBtn(roomActionsContainer, "Kirim Doa Semangat ke Firebase", "#2A9D8F", () -> {
            String msg = etDoa.getText().toString().trim();
            if (msg.isEmpty()) {
                toast("Tulis dulu pesan Doa Semangatnya ya.");
                return;
            }
            bgExecutor.execute(() -> {
                boolean ok = firebase.sendDoaSemangatOnline(living.getSantriNis(), living.getSantriName(), msg);
                mainHandler.post(() -> {
                    if (ok) {
                        living.recordAdabAction("DOA_SEMANGAT", 2, "Mengirim Doa Semangat online ke sahabat santri");
                        narrator.playCorrectChime();
                        toast("Doa Semangat terkirim ke seluruh santri!");
                        openFirebaseOnlineHub();
                    } else {
                        toast("Gagal terhubung ke Firebase. Periksa koneksi internetmu.");
                    }
                });
            });
        });
    }

    // ================= KANTOR TU HIDUP, CATATAN RUMAH, UJIAN & CETAK RESMI =================

    private void openKantorTu() {
        syncPresenceRoom("Kantor TU Ustadzah Nur");
        narrator.playRawEffect(R.raw.sfx_suasana_kantor, null);
        String antrean = devices.useDevice(FacilityDeviceEngine.DEV_MESIN_ANTREAN, "Ambil nomor antrean loket TU");
        List<String> pendingJournals = formalSchool.getPendingHomeJournalsForTu();
        String nar = "Ustadzah Nur: Assalamu'alaikum " + living.getSantriName()
                + ", selamat datang di Kantor Tata Usaha Pondok Hafidz Netra.\n"
                + antrean + "\n"
                + "Catatan / PR Rumah masuk di Komputer Server TU: " + pendingJournals.size() + " berkas.\n\n"
                + devices.buildLocationDevicesSummary("TU");
        openRoomStage("Kantor TU Hidup — Ustadzah Nur", nar, "taaruf_tu.mp3");

        addDynamicBtn(roomActionsContainer, "Loket 1: Komputer Server TU — Tanggapan Ustadzah Nur atas Catatan/PR Rumah (" + pendingJournals.size() + ")",
                "#2A9D8F", this::openTuJournalServerLoket);
        addDynamicBtn(roomActionsContainer, "Loket 2: Komputer Lab — Ujian Anti-Klik-Sembarangan (2 Tahap & Remidi Nyata)",
                "#E76F51", this::openExamAntiClickHub);
        addDynamicBtn(roomActionsContainer, "Loket 3: Printer Resmi — Cetak Rapor Lengkap (Gelar Kehormatan & 4 Nilai, PNG+Teks)",
                "#1D3557", this::printOfficialRaporBundle);
        addDynamicBtn(roomActionsContainer, "Loket 4: Printer Resmi — Cetak Buku Absensi 5 Status (PNG + Teks)",
                "#264653", this::printOfficialAbsensiBundle);
        addDynamicBtn(roomActionsContainer, "Loket 5: Mikrofon Corong Pondok & Verifikasi NIS Firebase",
                "#457B9D", this::openTuCorongAndNisLoket);
        addDynamicBtn(roomActionsContainer, "Loket 6: Wawancara PSB Mendalam & Pembaruan Biodata",
                "#3A506B", this::runTaarufPos2Psb);
    }

    private void openTuJournalServerLoket() {
        narrator.playRawEffect(R.raw.sfx_pc_boot, null);
        devices.useDevice(FacilityDeviceEngine.DEV_SERVER_TU, "Buka kotak masuk catatan rumah");
        List<String> journals = formalSchool.getPendingHomeJournalsForTu();
        StringBuilder sb = new StringBuilder();
        sb.append("KOMPUTER SERVER TU — Catatan & PR Rumah dari Santri\n\n");
        if (journals.isEmpty()) {
            sb.append("Belum ada catatan rumah yang dikirim. Silakan tulis jurnal refleksi di Buku Catatan Digital Kamar Pribadi.\n");
        } else {
            for (int i = 0; i < Math.min(5, journals.size()); i++) {
                sb.append("• ").append(journals.get(i)).append("\n");
            }
        }
        sb.append("\nTANGGAPAN USTADZAH NUR:\n").append(formalSchool.getLatestTuRepliesSummary());
        openRoomStage("Server TU — Catatan Rumah & Tanggapan Ustadzah Nur", sb.toString(), "taaruf_tu.mp3");

        if (!journals.isEmpty()) {
            addDynamicBtn(roomActionsContainer, "Minta Tanggapan Mendalam Ustadzah Nur Sekarang", "#2A9D8F", () -> {
                String latest = journals.get(0);
                String reply = "MasyaAllah " + living.getSantriName() + ", Ustadzah Nur sudah membaca catatan rumahmu ("
                        + latest + "). Terus pertahankan semangat belajarmu dari rumah, jaga stamina suara, dan lanjutkan murajaah sedikit demi sedikit setiap hari ya!";
                formalSchool.saveTuResponseToJournal(reply);
                living.recordAdabAction("TANGGAPAN_TU", 2, "Menyimak tanggapan Ustadzah Nur atas catatan rumah");
                narrator.playCorrectChime();
                tvRoomNarrative.setText("Ustadzah Nur menanggapi langsung:\n\n" + reply);
                speak(reply);
            });
        }
        addDynamicBtn(roomActionsContainer, "Kembali ke Loket Kantor TU", "#4A5568", this::openKantorTu);
    }

    private void openTuCorongAndNisLoket() {
        devices.useDevice(FacilityDeviceEngine.DEV_MIKROFON_CORONG, "Buka Mikrofon Corong & Verifikasi NIS");
        openRoomStage("Mikrofon Corong Pondok & Verifikasi NIS Firebase",
                "NIS Aktif Kamu: " + (living.getSantriNis().isEmpty() ? "Belum terdaftar" : living.getSantriNis())
                        + "\nGunakan Mikrofon Corong untuk menyiarkan pengumuman pondok atau verifikasi NIS secara online.",
                "corong_pengumuman.mp3");

        EditText etCorong = addInputField(roomActionsContainer, "Tulis pengumuman untuk Corong Pondok...", "");
        addDynamicBtn(roomActionsContainer, "Siarkan ke Mikrofon Corong Pondok (Firebase)", "#2A9D8F", () -> {
            String msg = etCorong.getText().toString().trim();
            if (msg.isEmpty()) {
                toast("Tulis dulu isi pengumuman Corong Pondok.");
                return;
            }
            bgExecutor.execute(() -> {
                firebase.publishCorongBroadcast(living.getSantriName() + ": " + msg);
                mainHandler.post(() -> {
                    narrator.playCorongChime(null);
                    toast("Pengumuman berhasil disiarkan lewat Corong Pondok!");
                });
            });
        });

        addDynamicBtn(roomActionsContainer, "Verifikasi NIS Online di Server Firebase", "#1D3557", () -> {
            String nis = living.getSantriNis();
            if (nis.isEmpty()) {
                toast("NIS belum ada. Selesaikan Pos 2 PSB terlebih dahulu.");
                return;
            }
            bgExecutor.execute(() -> {
                String result = firebase.verifyNisOrPiagamOnline(nis);
                mainHandler.post(() -> {
                    tvRoomNarrative.setText("Hasil Verifikasi NIS (" + nis + "):\n\n" + result);
                    speak(result);
                });
            });
        });
        addDynamicBtn(roomActionsContainer, "Kembali ke Kantor TU", "#4A5568", this::openKantorTu);
    }

    private void printOfficialRaporBundle() {
        narrator.playRawEffect(R.raw.sfx_printer_resmi, null);
        devices.useDevice(FacilityDeviceEngine.DEV_PRINTER_RESMI, "Cetak Rapor Lengkap Gelar Kehormatan");
        List<String> lines = new ArrayList<>();
        lines.add("Nama Santri      : " + living.getSantriName());
        lines.add("NIS Resmi        : " + living.getSantriNis());
        lines.add("Jenjang Non-Formal: " + living.getJenjangLabel());
        lines.add("Jenjang Formal   : " + formalSchool.getFormalLevelLabel() + " (Rata-rata: " + formalSchool.getFormalScoreAverage() + ")");
        lines.add("Gelar Kehormatan : " + living.getHonorTitle());
        lines.add("----------------------------------------");
        lines.add("1. Nilai Hafalan / Kelancaran : " + living.getKelancaranScore());
        lines.add("2. Nilai Disiplin Kehadiran   : " + living.getDisiplinScore());
        lines.add("3. Nilai Adab & Akhlak        : " + living.getAdabScore());
        lines.add("4. Nilai Ujian & Tajwid       : " + living.getUjianScore());
        lines.add("Rata-Rata 4 Nilai Resmi       : " + living.getFourScoreAverage());
        lines.add("Pengesahan: Ustadz Yeni Setiawan & Ustadzah Nur");

        String docNo = "RAPOR/MHN/" + new SimpleDateFormat("yyyyMM", Locale.US).format(new Date()) + "/" + living.getSantriNis();
        OfficialDocumentGenerator.GeneratedDocument doc = OfficialDocumentGenerator.generateBundle(
                this, "rapor_lengkap", "RAPOR RESMI PONDOK HAFIDZ NETRA", docNo, lines);
        narrator.playCorrectChime();
        openRoomStage("Printer Resmi — Rapor Lengkap Siap Dibagikan",
                doc.officialText, "");
        addDynamicBtn(roomActionsContainer, "Bagikan Rapor (Foto PNG Ber-Kop + Teks Resmi)", "#2A9D8F", () -> {
            try {
                startActivity(Intent.createChooser(OfficialDocumentGenerator.buildShareIntent(this, doc), "Bagikan Rapor Resmi"));
            } catch (Exception e) {
                toast("Gagal membuka menu bagikan.");
            }
        });
        addDynamicBtn(roomActionsContainer, "Kembali ke Kantor TU", "#4A5568", this::openKantorTu);
    }

    private void printOfficialAbsensiBundle() {
        narrator.playRawEffect(R.raw.sfx_printer_resmi, null);
        devices.useDevice(FacilityDeviceEngine.DEV_PRINTER_RESMI, "Cetak Buku Absensi 5 Status");
        int[] counts = schedule.getFiveStatusAttendanceCounts();
        List<String> lines = new ArrayList<>();
        lines.add("Nama Santri : " + living.getSantriName() + " (" + living.getSantriNis() + ")");
        lines.add("Periode     : " + new SimpleDateFormat("MMMM yyyy", new Locale("id", "ID")).format(new Date()));
        lines.add("----------------------------------------");
        lines.add("1. Hadir     : " + counts[0] + " hari");
        lines.add("2. Terlambat : " + counts[1] + " hari");
        lines.add("3. Izin      : " + counts[2] + " hari");
        lines.add("4. Sakit     : " + counts[3] + " hari");
        lines.add("5. Alpa      : " + counts[4] + " hari");
        lines.add("Persentase Kehadiran Bulanan: " + schedule.getMonthlyAttendancePercent() + "%");
        lines.add("Disahkan oleh: Ustadzah Nur (Tata Usaha)");

        String docNo = "ABSEN-5S/MHN/" + new SimpleDateFormat("yyyyMM", Locale.US).format(new Date());
        OfficialDocumentGenerator.GeneratedDocument doc = OfficialDocumentGenerator.generateBundle(
                this, "buku_absensi_5status", "BUKU ABSENSI 5 STATUS RESMI", docNo, lines);
        narrator.playCorrectChime();
        openRoomStage("Printer Resmi — Buku Absensi 5 Status", doc.officialText, "");
        addDynamicBtn(roomActionsContainer, "Bagikan Buku Absensi 5 Status (Foto PNG + Teks)", "#2A9D8F", () -> {
            try {
                startActivity(Intent.createChooser(OfficialDocumentGenerator.buildShareIntent(this, doc), "Bagikan Buku Absensi"));
            } catch (Exception e) {
                toast("Gagal membuka menu bagikan.");
            }
        });
        addDynamicBtn(roomActionsContainer, "Kembali ke Kantor TU", "#4A5568", this::openKantorTu);
    }

    // ================= SISTEM UJIAN ANTI-KLIK-SEMBARANGAN (2 TAHAP + REMIDI NYATA) =================

    private void openExamAntiClickHub() {
        narrator.playRawEffect(R.raw.sfx_pc_boot, null);
        devices.useDevice(FacilityDeviceEngine.DEV_KOMPUTER_LAB, "Buka Sistem Ujian Anti-Klik-Sembarangan");
        if (examEngine.isRemidiRequired()) {
            String remNar = "AKSES UJIAN TERKUNCI — WAJIB REMIDI NYATA\n\n"
                    + "Pada ujian sebelumnya nilaimu belum mencapai 75%. Sesuai aturan kejujuran pondok, "
                    + "kamu wajib menyelesaikan Sesi Remidi Nyata terlebih dahulu sebelum boleh mengulang ujian.\n\n"
                    + "Materi yang wajib diperbaiki:\n" + examEngine.getRemidiTopics();
            openRoomStage("Sesi Remidi Nyata Sebelum Ulang Ujian", remNar, "chime_coba_lagi.mp3");
            addDynamicBtn(roomActionsContainer, "Simak Penjelasan Perbaikan & Selesaikan Remidi Nyata", "#F4A261", () -> {
                examEngine.setRemidiRequired(false, "");
                narrator.playCorrectChime();
                toast("Alhamdulillah, Sesi Remidi Nyata tuntas! Sekarang kamu boleh mengulang ujian.");
                openExamAntiClickHub();
            });
            addDynamicBtn(roomActionsContainer, "Kembali ke Kantor TU", "#4A5568", this::openKantorTu);
            return;
        }

        String intro = "SISTEM UJIAN ANTI-KLIK-SEMBARANGAN (2 TAHAP WAJIB)\n\n"
                + "• 4 opsi jawaban selalu diacak netral.\n"
                + "• Kunci Anti-Klik-Kilat: wajib menyimak soal minimal 3 detik sebelum memilih jawaban.\n"
                + "• Tahap 1: 4 Soal Pemahaman (Sambung Ayat, Tajwid, Adab).\n"
                + "• Tahap 2: Praktik Susun Potongan Ayat berurutan.\n"
                + "• Nilai <75% otomatis mewajibkan Sesi Remidi Nyata sebelum boleh mengulang.";
        openRoomStage("Ujian Resmi Pondok Hafidz Netra", intro, "");
        addDynamicBtn(roomActionsContainer, "Mulai Ujian Tahap 1 Sekarang", "#2A9D8F", () -> {
            activeExamQuestions = examEngine.generateStage1Questions();
            activeExamIdx = 0;
            activeExamCorrect = 0;
            examDetailReport.setLength(0);
            examWrongTopics.clear();
            showExamStage1Question();
        });
        addDynamicBtn(roomActionsContainer, "Kembali ke Kantor TU", "#4A5568", this::openKantorTu);
    }

    private void showExamStage1Question() {
        if (activeExamQuestions == null || activeExamIdx >= activeExamQuestions.size()) {
            startExamStage2Arrange();
            return;
        }
        ExamIntegrityEngine.ExamQuestion q = activeExamQuestions.get(activeExamIdx);
        examQuestionShownAtMs = System.currentTimeMillis();
        String nar = "TAHAP 1 — Soal " + (activeExamIdx + 1) + " dari " + activeExamQuestions.size()
                + " (" + q.topic + ")\n\n" + q.prompt
                + "\n\n(Simak minimal 3 detik agar kunci anti-klik-kilat terbuka.)";
        openRoomStage("Ujian Tahap 1 (" + (activeExamIdx + 1) + "/" + activeExamQuestions.size() + ")", nar, "");
        speak(q.prompt);

        String[] labels = {"A. ", "B. ", "C. ", "D. "};
        for (int i = 0; i < q.shuffledOptions.size(); i++) {
            final int optIdx = i;
            addDynamicBtn(roomActionsContainer, labels[i] + q.shuffledOptions.get(i), "#1D3557", () -> {
                long elapsed = System.currentTimeMillis() - examQuestionShownAtMs;
                if (elapsed < ExamIntegrityEngine.MIN_READ_MILLIS) {
                    narrator.playWrongTone();
                    String warn = "Kunci Anti-Klik-Kilat aktif! Simak soal dengan tenang minimal 3 detik sebelum menjawab.";
                    toast(warn);
                    speak(warn);
                    return;
                }
                boolean correct = (optIdx == q.correctIndex);
                if (correct) {
                    activeExamCorrect++;
                    narrator.playCorrectChime();
                    examDetailReport.append("• Soal ").append(activeExamIdx + 1).append(" (").append(q.topic)
                            .append("): BENAR. ").append(q.explanation).append("\n");
                } else {
                    narrator.playWrongTone();
                    examWrongTopics.add(q.topic + ": " + q.explanation);
                    examDetailReport.append("• Soal ").append(activeExamIdx + 1).append(" (").append(q.topic)
                            .append("): BELUM TEPAT. Kunci: ").append(q.shuffledOptions.get(q.correctIndex))
                            .append(". ").append(q.explanation).append("\n");
                }
                activeExamIdx++;
                showExamStage1Question();
            });
        }
    }

    private void startExamStage2Arrange() {
        activeArrangeTask = examEngine.generateStage2ArrangeTask();
        arrangeStepIdx = 0;
        renderExamStage2Arrange();
    }

    private void renderExamStage2Arrange() {
        String nar = activeArrangeTask.title + "\n\n" + activeArrangeTask.instruction
                + "\n\nPotongan yang harus dipilih sekarang: Ayat ke-" + (arrangeStepIdx + 1)
                + " dari " + activeArrangeTask.correctOrder.length;
        openRoomStage("Ujian Tahap 2 — Susun Potongan Ayat", nar, "");
        for (String piece : activeArrangeTask.shuffledPieces) {
            addDynamicBtn(roomActionsContainer, piece, "#264653", () -> {
                if (piece.equals(activeArrangeTask.correctOrder[arrangeStepIdx])) {
                    narrator.playCorrectChime();
                    arrangeStepIdx++;
                    if (arrangeStepIdx >= activeArrangeTask.correctOrder.length) {
                        examDetailReport.append("• Tahap 2 (Susun Potongan Ayat Al-Kautsar): BENAR BERURUTAN.\n");
                        finishTwoStageExam(true);
                    } else {
                        renderExamStage2Arrange();
                    }
                } else {
                    narrator.playWrongTone();
                    examWrongTopics.add("Urutan Ayat Al-Kautsar (Tahap 2)");
                    examDetailReport.append("• Tahap 2 (Susun Potongan Ayat): BELUM TEPAT urutan ayat ke-")
                            .append(arrangeStepIdx + 1).append(".\n");
                    finishTwoStageExam(false);
                }
            });
        }
    }

    private void finishTwoStageExam(boolean stage2Passed) {
        int totalPoints = activeExamCorrect + (stage2Passed ? 1 : 0);
        int maxPoints = (activeExamQuestions == null ? 4 : activeExamQuestions.size()) + 1;
        int scorePct = Math.round((totalPoints * 100f) / Math.max(1, maxPoints));
        boolean passed = scorePct >= 75 && stage2Passed;

        if (passed) {
            examEngine.setRemidiRequired(false, "");
            living.boostGrade(AppConfig.KEY_GRADE_UJIAN, 6);
            smart.appendMutabaah("Ujian Resmi 2 Tahap", "Lulus Anti-Klik-Sembarangan", scorePct, "Lulus jujur 2 tahap");
            narrator.playCorrectChime();
        } else {
            StringBuilder wrongSb = new StringBuilder();
            for (String w : examWrongTopics) wrongSb.append("• ").append(w).append("\n");
            examEngine.setRemidiRequired(true, wrongSb.toString());
            narrator.playWrongTone();
        }

        String summary = (passed ? "ALHAMDULILLAH LULUS UJIAN RESMI!" : "BELUM LULUS — WAJIB REMIDI NYATA")
                + "\nSkor Akhir: " + scorePct + "% (" + totalPoints + "/" + maxPoints + ")\n\n"
                + "EVALUASI GURU RINCI PER SOAL:\n" + examDetailReport.toString();
        openRoomStage("Hasil & Evaluasi Rinci Ujian", summary, passed ? "chime_lulus_benar.mp3" : "chime_coba_lagi.mp3");
        addDynamicBtn(roomActionsContainer, passed ? "Kembali ke Kantor TU (Cetak Rapor)" : "Masuk Sesi Remidi Nyata",
                passed ? "#2A9D8F" : "#F4A261", passed ? this::openKantorTu : this::openExamAntiClickHub);
    }

    // ================= MASJID AGUNG & ALUR MAJELIS MALAM JUMAT NYATA =================

    private void openMasjidAgung(String mode) {
        syncPresenceRoom("Masjid Agung Pondok");
        String jamInfo = devices.useDevice(FacilityDeviceEngine.DEV_JAM_DIGITAL, "Cek Jam Digital Masjid Agung");
        String nar = "Assalamu'alaikum di Masjid Agung Pondok Hafidz Netra. Mari jaga adab tenang di dalam masjid.\n"
                + jamInfo + "\n"
                + "Waktu Nyata: " + schedule.getRealCalendarSummary() + "\n\n"
                + devices.buildLocationDevicesSummary("MASJID");
        openRoomStage("Masjid Agung Pondok Hafidz Netra", nar, "corong_pengumuman.mp3");

        addDynamicBtn(roomActionsContainer, "Ikuti Majelis Malam Jumat Nyata (Daftar Arwah Firebase -> Yasin -> Doa Penutup)",
                "#1B4332", this::startMajelisMalamJumatBabak1);
        addDynamicBtn(roomActionsContainer, "Putar Bel Menjelang Sholat Berjamaah (Sound System Masjid)", "#264653", () -> {
            devices.useDevice(FacilityDeviceEngine.DEV_SOUND_SYSTEM, "Bel Menjelang Sholat Berjamaah");
            narrator.playRawEffect(R.raw.sfx_bel_sholat_berjamaah, null);
        });
        addDynamicBtn(roomActionsContainer, "Putar Wirid Sore & 6 Surat Pendek (Sound System Masjid)", "#2A9D8F", () -> {
            devices.useDevice(FacilityDeviceEngine.DEV_SOUND_SYSTEM, "Putar Wirid Sore 6 Surat");
            PondokBackgroundService.startForActivePlayback(this, "Wirid Sore — Masjid Agung");
            sequencer.startQueue(sequencer.buildWiridSore6SuratSteps(0));
        });
        addDynamicBtn(roomActionsContainer, "Tambah Nama Arwah ke Daftar Firebase RTDB", "#1D3557", this::openAddArwahStage);

        if ("MALAM_JUMAT".equals(mode)) {
            startMajelisMalamJumatBabak1();
        }
    }

    private void openAddArwahStage() {
        openRoomStage("Tambah Nama Almarhum / Almarhumah (Firebase RTDB)",
                "Nama yang kamu tambahkan akan otomatis masuk ke Daftar Arwah Majelis Malam Jumat di Masjid Agung dan Web Formulir Doa Malam Jumat.",
                "");
        EditText etArwah = addInputField(roomActionsContainer, "Tulis nama almarhum/almarhumah (contoh: Alm. Bapak H. Ahmad)", "");
        addDynamicBtn(roomActionsContainer, "Simpan Nama Arwah ke Firebase", "#2A9D8F", () -> {
            String nm = etArwah.getText().toString().trim();
            if (nm.isEmpty()) {
                toast("Tulis dulu nama almarhum atau almarhumah.");
                return;
            }
            bgExecutor.execute(() -> {
                boolean ok = firebase.pushArwahNameOnline(nm, living.getSantriName());
                mainHandler.post(() -> {
                    if (ok) {
                        narrator.playCorrectChime();
                        toast("Nama arwah tersimpan ke Firebase RTDB!");
                        openMasjidAgung("NORMAL");
                    } else {
                        toast("Gagal menyimpan ke Firebase. Cek koneksi internet.");
                    }
                });
            });
        });
    }

    private void startMajelisMalamJumatBabak1() {
        devices.useDevice(FacilityDeviceEngine.DEV_SOUND_SYSTEM, "Buka Majelis Malam Jumat");
        String nar = "MAJELIS MALAM JUMAT — BABAK 1: Pembukaan & Niat\n\n"
                + "Ustadz Yeni Setiawan: Assalamu'alaikum warahmatullahi wabarakatuh. "
                + "Alhamdulillah kita dapat berkumpul di Masjid Agung untuk mendoakan orang tua, guru, dan keluarga yang telah mendahului kita.\n\n"
                + "Memuat Daftar Nama Arwah langsung dari server Firebase RTDB...";
        openRoomStage("Majelis Malam Jumat (1/4) — Pembukaan", nar, "majelis_malam_jumat_panggilan.mp3");

        bgExecutor.execute(() -> {
            List<FirebaseMadrasahClient.ArwahEntry> entries = firebase.fetchArwahEntriesOnline();
            mainHandler.post(() -> {
                activeArwahList = new ArrayList<>();
                if (entries != null && !entries.isEmpty()) {
                    activeArwahList.addAll(entries);
                } else {
                    activeArwahList.add(new FirebaseMadrasahClient.ArwahEntry("local1", "Seluruh Orang Tua & Guru Pondok Hafidz Netra", "Pondok"));
                }
                activeArwahIdx = 0;
                addDynamicBtn(roomActionsContainer,
                        "Lanjut Babak 2: Baca Daftar Nama Arwah (" + activeArwahList.size() + " Nama) Satu Per Satu",
                        "#2A9D8F", this::showMajelisArwahBabak2);
            });
        });
    }

    private void showMajelisArwahBabak2() {
        if (activeArwahList == null || activeArwahIdx >= activeArwahList.size()) {
            startMajelisYasinBabak3();
            return;
        }
        FirebaseMadrasahClient.ArwahEntry entry = activeArwahList.get(activeArwahIdx);
        String doa = "MAJELIS MALAM JUMAT — BABAK 2: Doa Khusus Arwah (" + (activeArwahIdx + 1) + "/" + activeArwahList.size() + ")\n\n"
                + "Nama: " + entry.nama + " (Kiriman: " + entry.pengirim + ")\n\n"
                + "Allahummaghfir lahu warhamhu wa 'afihi wa'fu 'anhu. Semoga Allah melapangkan kuburnya dan menempatkannya di surga terbaik.";
        openRoomStage("Daftar Arwah (" + (activeArwahIdx + 1) + "/" + activeArwahList.size() + ")", doa, "");
        speak("Khususan ila ruhi " + entry.nama + ". Allahummaghfir lahu warhamhu wa afihi wa'fu anhu.");

        addDynamicBtn(roomActionsContainer,
                (activeArwahIdx + 1 < activeArwahList.size())
                        ? "Aamiin — Lanjut Baca Nama Arwah Berikutnya"
                        : "Aamiin — Lanjut Babak 3 (Lantunan Yasin / Tahlil Qari Asli)",
                "#2A9D8F", () -> {
                    narrator.playCorrectChime();
                    activeArwahIdx++;
                    showMajelisArwahBabak2();
                });
    }

    private void startMajelisYasinBabak3() {
        String nar = "MAJELIS MALAM JUMAT — BABAK 3: Lantunan Yasin / Tahlil Qari Asli\n\n"
                + "Sound System Masjid Agung siap mengalirkan lantunan Surat Yasin dan 6 Surat Pendek Wirid oleh Qari asli.";
        openRoomStage("Majelis Malam Jumat (3/4) — Lantunan Qari", nar, "");
        addDynamicBtn(roomActionsContainer, "Putar Lantunan Yasin / Wirid Qari Asli Sekarang", "#2A9D8F", () -> {
            PondokBackgroundService.startForActivePlayback(this, "Majelis Malam Jumat — Lantunan Yasin Qari");
            sequencer.startQueue(sequencer.buildWiridSore6SuratSteps(0));
        });
        addDynamicBtn(roomActionsContainer, "Lanjut Babak 4: Doa Penutup & Catat di Mutaba'ah", "#1B4332",
                this::finishMajelisMalamJumatBabak4);
    }

    private void finishMajelisMalamJumatBabak4() {
        stopAllAudioNow();
        living.recordAdabAction("MAJELIS_MALAM_JUMAT", 4, "Mengikuti penuh Majelis Malam Jumat di Masjid Agung");
        smart.appendMutabaah("Majelis Malam Jumat", "Doa Arwah (" + activeArwahList.size() + " nama) & Yasin/Tahlil", 100,
                "Hadir penuh sampai Doa Penutup");
        narrator.playCorrectChime();
        String nar = "MAJELIS MALAM JUMAT — BABAK 4: Doa Penutup\n\n"
                + "Rabbana atina fid-dunya hasanah wa fil-akhirati hasanah wa qina 'adzaban-nar. Alhamdulillahi rabbil 'alamin.\n\n"
                + "Kehadiranmu di Majelis Malam Jumat telah tercatat di Buku Mutaba'ah dan menambah Nilai Adab (+4)!";
        openRoomStage("Majelis Malam Jumat Tuntas", nar, "salam_penutup.mp3");
        addDynamicBtn(roomActionsContainer, "Kembali ke Beranda", "#2A9D8F", this::openBeranda);
    }

    private void openPerpustakaan() {
        currentStudyMode = "PERPUS";
        openBelajarPanel("Perpustakaan Audio Pondok (Latihan Bebas)");
    }

    private void openBelajarPanel(String title) {
        showPanel("BELAJAR");
        tvStudyTitle.setText(title);
        tvStudyStatus.setText("Memuat surat " + currentSurahName + " ayat " + (currentAyahIdx + 1) + "...");
        tvAyahArab.setText("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ");
        tvAyahMeaning.setText("Menyiapkan materi bacaan...");
        rebuildStudyButtons();
        loadSurahAsync(currentSurahNo);
    }

    private void rebuildStudyButtons() {
        studyActionsContainer.removeAllViews();
        boolean isFreeMode = !"KELAS".equals(currentStudyMode);

        addDynamicBtn(studyActionsContainer,
                "Putar Murottal & Aktifkan Auto-Respon (" + currentSurahName + " Ayat " + (currentAyahIdx + 1) + ")",
                "#2A9D8F", this::playCurrentAyahWithMethod);

        addDynamicBtn(studyActionsContainer, "Sudah Lancar (100% Hijau -> Otomatis Lanjut Ayat)", "#1B4332",
                this::markCurrentAyahGreenAndAutoAdvance);

        addDynamicBtn(studyActionsContainer, "Ulangi Lebih Pelan / Masih Sulit (Catat PR Rumah)", "#F4A261", () -> {
            activeBlockRepeatCount++;
            if (currentAyahs != null && !currentAyahs.isEmpty()) {
                QuranRepository.AyahItem it = currentAyahs.get(currentAyahIdx);
                smart.addTomorrowRetryItem(currentSurahNo, currentSurahName, it.nomorAyat);
                String emp = smart.buildTeacherEmotionalResponse(
                        living.getPengasuhUtama(), living.getSantriName(), world.getStamina(),
                        activeBlockRepeatCount, 0, false);
                tvStudyStatus.setText(emp);
                sequencer.setPlaybackSpeed(0.85f);
                playCurrentAyahWithMethod();
            }
        });

        if (isFreeMode) {
            // Latihan bebas rapi khusus di Kamar Rumah & Perpustakaan (tidak mengotori Gedung Kelas)
            addDynamicBtn(studyActionsContainer, "Pilih Surat Bebas (Juz 30 & Juz 1-30)", "#1D3557",
                    this::openFreeSurahPicker);
            String mName = (selectedFreeMethodIdx >= 0 && selectedFreeMethodIdx < AppConfig.STUDY_METHODS.length)
                    ? AppConfig.STUDY_METHODS[selectedFreeMethodIdx] : "Talaqqi Per Ayat";
            addDynamicBtn(studyActionsContainer, "Ganti Metode Hafalan (20 Metode) — Aktif: " + mName, "#264653",
                    this::openFreeMethodPicker);
            addDynamicBtn(studyActionsContainer, "Latihan Iqra' Manual Jilid 1-6 (Bebas)", "#457B9D",
                    this::openIdadIqraClassStage);
        } else {
            addDynamicBtn(studyActionsContainer, "Selesai Babak 3 -> Lanjut Babak 4 (Evaluasi & Bel Pulang)", "#1D3557",
                    () -> startNonFormalClassBabak4("Sesi kelas " + currentSurahName + " ayat " + (currentAyahIdx + 1)));
        }
    }

    private void openFreeSurahPicker() {
        openRoomStage("Pilih Surat Bebas (Kamar Rumah / Perpustakaan)",
                "Pilih surat pilihan sesuka hati. Begitu penguasaan surat mencapai >=75% di Rumah, "
                        + "otomatis muncul pemberitahuan pembimbing di Sekolah untuk setoran kelas!",
                "");
        for (int i = 0; i < Math.min(12, AppConfig.JUZ30_REVERSED_NUMS.length); i++) {
            int sNo = AppConfig.JUZ30_REVERSED_NUMS[i];
            String sName = AppConfig.JUZ30_REVERSED_NAMES[i];
            int pct = living.getHomeSurahMastery(sNo);
            addDynamicBtn(roomActionsContainer,
                    "Surat " + sName + " (No. " + sNo + ") — Progres Rumah: " + pct + "%",
                    pct >= 75 ? "#1B4332" : "#1D3557", () -> {
                        currentSurahNo = sNo;
                        currentSurahName = sName;
                        currentAyahIdx = 0;
                        openBelajarPanel("Latihan Bebas — Surat " + sName);
                    });
        }
        EditText etCustom = addInputField(roomActionsContainer, "Atau ketik nomor surat 1 sampai 114 (Juz 1-30)", "");
        addDynamicBtn(roomActionsContainer, "Buka Nomor Surat Pilihan (1-114)", "#2A9D8F", () -> {
            try {
                int no = Integer.parseInt(etCustom.getText().toString().trim());
                if (no >= 1 && no <= 114) {
                    currentSurahNo = no;
                    currentSurahName = "Surat #" + no;
                    currentAyahIdx = 0;
                    openBelajarPanel("Latihan Bebas — Surat #" + no);
                } else {
                    toast("Masukkan nomor surat antara 1 sampai 114.");
                }
            } catch (Exception e) {
                toast("Masukkan angka nomor surat 1 sampai 114.");
            }
        });
    }

    private void openFreeMethodPicker() {
        openRoomStage("Pilih Metode Hafalan (20 Metode Tersedia)",
                "Pilih metode yang paling nyaman untukmu di Kamar Rumah atau Perpustakaan:", "");
        for (int i = 0; i < AppConfig.STUDY_METHODS.length; i++) {
            final int idx = i;
            addDynamicBtn(roomActionsContainer, AppConfig.STUDY_METHODS[i],
                    idx == selectedFreeMethodIdx ? "#2A9D8F" : "#264653", () -> {
                        selectedFreeMethodIdx = idx;
                        toast("Metode diatur: " + AppConfig.STUDY_METHODS[idx]);
                        openBelajarPanel("Latihan Bebas — " + currentSurahName);
                    });
        }
    }

    private void loadSurahAsync(int surahNo) {
        bgExecutor.execute(() -> {
            List<QuranRepository.AyahItem> list = quranRepo.getSurahAyahs(surahNo);
            mainHandler.post(() -> {
                if (list != null && !list.isEmpty()) {
                    currentAyahs = list;
                    currentSurahNo = surahNo;
                    currentSurahName = list.get(0).surahName;
                    if (currentAyahIdx >= currentAyahs.size()) currentAyahIdx = 0;
                    renderCurrentAyah();
                    rebuildStudyButtons();
                }
            });
        });
    }

    private void renderCurrentAyah() {
        if (currentAyahs == null || currentAyahs.isEmpty()) return;
        QuranRepository.AyahItem item = currentAyahs.get(currentAyahIdx);
        int pct = classroom.getAyahMastery(currentSurahNo, item.nomorAyat);
        tvStudyStatus.setText(currentSurahName + " — Ayat " + item.nomorAyat + " dari " + currentAyahs.size()
                + " | Kekuatan Ayat: " + pct + "%");
        tvAyahArab.setText(item.teksArab);
        tvAyahMeaning.setText(item.teksIndonesia);
        living.saveLastStudyCheckpoint(currentSurahNo, currentSurahName, item.nomorAyat,
                activeIqraJilid, currentStudyMode, "Kekuatan " + pct + "%");
    }

    private void playCurrentAyahWithMethod() {
        if (currentAyahs == null || currentAyahs.isEmpty()) return;
        QuranRepository.AyahItem item = currentAyahs.get(currentAyahIdx);
        PondokBackgroundService.startForActivePlayback(this, currentSurahName + " Ayat " + item.nomorAyat);
        if (selectedFreeMethodIdx == 5 && currentAyahs.size() >= 2) {
            sequencer.startQueue(sequencer.buildTikrarBerantaiSteps(currentAyahs, currentAyahIdx, 3, 0, 4));
        } else if (selectedFreeMethodIdx == 19) {
            sequencer.startQueue(sequencer.buildTadabburMaknaSteps(item, 0));
        } else {
            sequencer.startQueue(sequencer.buildTalaqqiPerAyahSteps(item, 0, 2, 4));
        }
    }

    private void markCurrentAyahGreenAndAutoAdvance() {
        if (currentAyahs == null || currentAyahs.isEmpty()) return;
        QuranRepository.AyahItem item = currentAyahs.get(currentAyahIdx);
        classroom.setAyahMastery(currentSurahNo, item.nomorAyat, 100);
        activeBlockRepeatCount = 0;
        narrator.playCorrectChime();

        // Hitung persentase penguasaan surat saat ini
        int mastered = classroom.countMasteredInSurah(currentSurahNo, currentAyahs.size());
        int surahPct = Math.min(100, (mastered * 100) / Math.max(1, currentAyahs.size()));

        if ("RUMAH".equals(currentStudyMode)) {
            boolean crossed75 = living.recordHomeSurahProgress(currentSurahNo, currentSurahName, surahPct,
                    "Ayat " + item.nomorAyat + " tuntas 100% Hijau");
            if (crossed75) {
                toast("MasyaAllah! " + currentSurahName + " mencapai " + surahPct + "% di Rumah -> Otomatis masuk pemberitahuan pembimbing di Sekolah!");
            }
        }

        if (currentAyahIdx + 1 < currentAyahs.size()) {
            currentAyahIdx++;
            renderCurrentAyah();
            rebuildStudyButtons();
            speak("Alhamdulillah 100 persen hijau! Otomatis lanjut ke ayat " + currentAyahs.get(currentAyahIdx).nomorAyat + ".");
            mainHandler.postDelayed(this::playCurrentAyahWithMethod, 1800);
        } else {
            // Tuntas 1 surat penuh!
            living.boostGrade(AppConfig.KEY_GRADE_KELANCARAN, 5);
            smart.appendMutabaah("Tuntas Surat", currentSurahName + " (" + currentAyahs.size() + " ayat)", 100,
                    "100% Hijau tuntas otomatis");
            String doneMsg = "MasyaAllah, Barakallahu fiik! Seluruh ayat Surat " + currentSurahName
                    + " telah mencapai 100% Hijau dan tuntas tercatat di Buku Mutaba'ah!";
            openRoomStage("Tuntas Surat — " + currentSurahName, doneMsg, "chime_lulus_benar.mp3");
            addDynamicBtn(roomActionsContainer, "Lanjut Evaluasi & Bel Pulang", "#2A9D8F",
                    () -> startNonFormalClassBabak4("Tuntas penuh Surat " + currentSurahName));
        }
    }

    /**
     * Auto-Respon manusiawi setelah Qari selesai memutar ayat/blok tanpa perlu cari tombol putar lagi.
     */
    private void onStudyAudioFinished() {
        if (!"BELAJAR".equals(currentView) || currentAyahs == null || currentAyahs.isEmpty()) return;
        QuranRepository.AyahItem item = currentAyahs.get(currentAyahIdx);
        String prompt = living.getPengasuhUtama() + ": Bagaimana bacaan " + currentSurahName
                + " ayat " + item.nomorAyat + " barusan? Pilih respon di bawah — tidak perlu cari tombol putar lagi.";
        openRoomStage("Auto-Respon Pembimbing — " + currentSurahName + " Ayat " + item.nomorAyat, prompt, "");
        addDynamicBtn(roomActionsContainer, "1. Sudah Lancar (100% Hijau -> Otomatis Lanjut & Putar Berikutnya)",
                "#1B4332", () -> {
                    showPanel("BELAJAR");
                    markCurrentAyahGreenAndAutoAdvance();
                });
        addDynamicBtn(roomActionsContainer, "2. Lumayan Paham (Naik Progres & Putar Sekali Lagi)",
                "#2A9D8F", () -> {
                    classroom.bumpAyahMastery(currentSurahNo, item.nomorAyat, 30);
                    showPanel("BELAJAR");
                    renderCurrentAyah();
                    playCurrentAyahWithMethod();
                });
        addDynamicBtn(roomActionsContainer, "3. Masih Sulit -> Ulangi Lebih Pelan & Catat PR Rumah",
                "#F4A261", () -> {
                    activeBlockRepeatCount++;
                    smart.addTomorrowRetryItem(currentSurahNo, currentSurahName, item.nomorAyat);
                    showPanel("BELAJAR");
                    sequencer.setPlaybackSpeed(0.85f);
                    playCurrentAyahWithMethod();
                });
    }

    private void handleLeaveStudyRoom() {
        if (isInClassSession && "KELAS".equals(currentStudyMode) && schedule.isClassActiveNow()) {
            openRoomStage("Konfirmasi Izin Keluar di Tengah Jam Kelas",
                    living.getPengasuhUtama() + ": Jam kelas masih tersisa " + schedule.getRemainingClassMinutes()
                            + " menit lagi. Apakah kamu benar-benar perlu izin keluar kelas sekarang?",
                    "");
            addDynamicBtn(roomActionsContainer, "Mohon izin keluar sebentar (Tetap jaga adab)", "#F4A261", () -> {
                isInClassSession = false;
                stopAllAudioNow();
                living.recordAdabAction("IZIN_KELUAR_KELAS", 2, "Meminta izin guru sebelum keluar di tengah jam kelas");
                toast("Guru mengizinkan. Adab izinmu tercatat (+2).");
                openBeranda();
            });
            addDynamicBtn(roomActionsContainer, "Kembali Lanjutkan Belajar di Kelas", "#2A9D8F", () -> showPanel("BELAJAR"));
            return;
        }
        isInClassSession = false;
        stopAllAudioNow();
        openBeranda();
    }

    // ================= 6. BICARA KE GURU (HYBRID GEMINI BYOK + OFFLINE) =================

    private void openTalkToTeacherScreen() {
        openRoomStage("Bicara ke Guru — " + living.getPengasuhUtama(),
                "Kamu bisa berbicara lewat mikrofon atau mengetik pertanyaan apa saja seputar hafalan, tajwid, jadwal, atau curhat belajar.",
                "");
        addDynamicBtn(roomActionsContainer, "Mulai Bicara Lewat Mikrofon", "#2A9D8F", () -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 201);
                return;
            }
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Silakan bicara kepada guru...");
            try {
                speechLauncher.launch(i);
            } catch (Exception e) {
                toast("Pengenalan suara tidak tersedia di perangkat ini, silakan ketik di kolom bawah.");
            }
        });

        EditText etTanya = addInputField(roomActionsContainer, "Atau ketik pertanyaan / curhatmu di sini...", "");
        addDynamicBtn(roomActionsContainer, "Kirim Pertanyaan ke Guru", "#1D3557", () -> {
            String q = etTanya.getText().toString().trim();
            if (!q.isEmpty()) processTeacherVoiceQuery(q);
        });
    }

    private void processTeacherVoiceQuery(String query) {
        tvRoomNarrative.setText("Guru sedang menyimak pertanyaanmu: \"" + query + "\"...");
        String ctx = "Surat aktif: " + currentSurahName + " ayat " + (currentAyahIdx + 1)
                + ", Jenjang: " + living.getJenjangLabel()
                + ", Jam: " + schedule.getRealCalendarSummary();
        bgExecutor.execute(() -> {
            String reply = gemini.hasApiKey()
                    ? gemini.askHybridContextual(query, ctx, living.getSantriName())
                    : gemini.buildSmartOfflineReply(query, ctx, living.getSantriName());
            mainHandler.post(() -> {
                tvRoomNarrative.setText(living.getPengasuhUtama() + ":\n\n" + reply);
                speak(reply);
            });
        });
    }

    // ================= 7. SETELAN PENJAGA WAKTU, SIMULASI, BYOK & CADANGAN =================

    private void openSetelan() {
        showPanel("SETELAN");
        boolean sim = schedule.isSimClockEnabled();
        boolean bgOn = prefs.getBoolean(AppConfig.KEY_BG_ALERTS_ENABLED, true);
        tvSetelanSummary.setText("Status Penjaga Waktu Otomatis: " + (bgOn ? "AKTIF (AlarmClock Presisi)" : "NONAKTIF")
                + "\nKalender & Jam: " + schedule.getRealCalendarSummary()
                + "\nBYOK Gemini API: " + (gemini.hasApiKey() ? "Tersimpan Lokal" : "Belum Diisi (Mode Offline Aktif)")
                + "\nVersi Aplikasi: v7.0.0-PondokHidup");

        setelanActionsContainer.removeAllViews();
        addDynamicBtn(setelanActionsContainer, bgOn ? "Nonaktifkan Penjaga Waktu Otomatis" : "Aktifkan Penjaga Waktu Otomatis",
                bgOn ? "#C1121F" : "#2A9D8F", () -> {
                    boolean next = !bgOn;
                    prefs.edit().putBoolean(AppConfig.KEY_BG_ALERTS_ENABLED, next)
                            .putBoolean(AppConfig.KEY_REMINDER_ENABLED, next).apply();
                    if (next) {
                        ReminderScheduler.scheduleAll(this);
                        PondokBackgroundService.startTimekeeper(this);
                        toast("Penjaga Waktu & Alarm Presisi diaktifkan.");
                    } else {
                        ReminderScheduler.cancelAll(this);
                        PondokBackgroundService.stopCompletely(this);
                        toast("Penjaga Waktu otomatis dinonaktifkan.");
                    }
                    openSetelan();
                });

        addDynamicBtn(setelanActionsContainer, sim ? "Matikan Mode Simulasi (Kembali 100% Waktu Nyata)" : "Nyalakan Mode Simulasi Waktu (Opsional)",
                "#1D3557", () -> {
                    schedule.setSimClockEnabled(!sim);
                    toast(!sim ? "Mode Simulasi dinyalakan." : "Kembali mengikuti 100% waktu & kalender dunia nyata.");
                    openSetelan();
                });

        if (sim) {
            addDynamicBtn(setelanActionsContainer, "Majukan Fase Jam Simulasi", "#457B9D", () -> {
                String label = schedule.advanceSimClockPhase();
                toast("Jam Simulasi: " + label);
                openSetelan();
            });
        }

        addDynamicBtn(setelanActionsContainer, "Buka Izin Baterai & Alarm Presisi Android", "#264653", () -> {
            try {
                Intent i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                startActivity(i);
            } catch (Exception e) {
                toast("Buka Pengaturan HP > Aplikasi > Pondok Hafidz Netra > Baterai Tanpa Batas.");
            }
        });

        addDynamicBtn(setelanActionsContainer, "Atur Kunci API Gemini (BYOK Lokal)", "#3A506B", this::openGeminiKeyStage);
        addDynamicBtn(setelanActionsContainer, "Buka Formulir Web Doa Malam Jumat", "#1B4332", () -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://r81616256-source.github.io/madrasa-haviz-netra/")));
            } catch (Exception e) {
                toast("Tidak dapat membuka peramban.");
            }
        });
        addDynamicBtn(setelanActionsContainer, "Cadangkan Data Santri (JSON)", "#4A5568", this::exportBackupJson);
    }

    private void openGeminiKeyStage() {
        openRoomStage("Pengaturan Kunci Gemini API (BYOK Lokal)",
                "Kunci API hanya disimpan aman di HP kamu sendiri untuk menjawab pertanyaan bebas kepada guru. Jika kosong, aplikasi tetap berjalan normal dengan mesin lokal.",
                "");
        EditText etKey = addInputField(roomActionsContainer, "Tempelkan Gemini API Key (AIza...)", gemini.getSavedApiKey());
        addDynamicBtn(roomActionsContainer, "Simpan Kunci Gemini", "#2A9D8F", () -> {
            gemini.saveApiKey(etKey.getText().toString().trim());
            toast("Kunci Gemini API tersimpan lokal.");
            openSetelan();
        });
        addDynamicBtn(roomActionsContainer, "Hapus Kunci Gemini", "#C1121F", () -> {
            gemini.clearApiKey();
            toast("Kunci Gemini dihapus.");
            openSetelan();
        });
    }

    private void exportBackupJson() {
        try {
            JSONObject obj = new JSONObject();
            obj.put("nama", living.getSantriName());
            obj.put("nis", living.getSantriNis());
            obj.put("adab", living.getAdabScore());
            obj.put("kelancaran", living.getKelancaranScore());
            obj.put("taaruf_done", living.getTaarufCompletedCount());
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, obj.toString(2));
            startActivity(Intent.createChooser(share, "Bagikan Cadangan JSON Santri"));
        } catch (Exception e) {
            toast("Gagal membuat cadangan JSON.");
        }
    }

    // ================= HELPER UI & AUDIO RAMAH PEMBACA LAYAR =================

    private void openRoomStage(String title, String narrative, String optionalMp3) {
        showPanel("RUANG");
        tvRoomTitle.setText(title);
        tvRoomNarrative.setText(narrative);
        roomActionsContainer.removeAllViews();
        announceForAccessibility(tvRoomTitle);
        if (optionalMp3 != null && !optionalMp3.isEmpty()) {
            narrator.speakHybrid(optionalMp3, narrative, null);
        }
    }

    private Button addDynamicBtn(LinearLayout container, String label, String hexColor, Runnable action) {
        Button btn = new Button(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        btn.setLayoutParams(lp);
        btn.setMinHeight(dp(50));
        btn.setText(label);
        btn.setContentDescription(label);
        btn.setTextColor(Color.WHITE);
        btn.setAllCaps(false);
        btn.setTextSize(14f);
        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor(hexColor)));
        btn.setOnClickListener(v -> action.run());
        container.addView(btn);
        return btn;
    }

    private EditText addInputField(LinearLayout container, String hint, String initialText) {
        EditText et = new EditText(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        et.setLayoutParams(lp);
        et.setMinHeight(dp(48));
        et.setHint(hint);
        et.setContentDescription(hint);
        et.setText(initialText == null ? "" : initialText);
        et.setTextColor(Color.WHITE);
        et.setHintTextColor(Color.LTGRAY);
        et.setBackgroundColor(Color.parseColor("#1D3557"));
        et.setPadding(dp(12), dp(10), dp(12), dp(10));
        container.addView(et);
        return et;
    }

    private void speak(String text) {
        if (narrator != null && text != null && !text.trim().isEmpty()) {
            narrator.speakOfflineTts(text, null);
        }
    }

    private void stopAllAudioNow() {
        if (sequencer != null) sequencer.stop();
        if (narrator != null) narrator.stopSpeaking();
        PondokBackgroundService.stopServiceNow(this);
        toast("Seluruh audio dihentikan.");
    }

    private void announceForAccessibility(View view) {
        if (view != null) {
            view.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED);
        }
    }

    private void vibrateShort(long ms) {
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(ms);
                }
            }
        } catch (Exception ignored) {}
    }

    private int dp(int val) {
        return Math.round(val * getResources().getDisplayMetrics().density);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(serviceStopReceiver);
        } catch (Exception ignored) {}
        if (sequencer != null) sequencer.stop();
        if (narrator != null) narrator.shutdown();
        bgExecutor.shutdownNow();
        super.onDestroy();
    }
}
