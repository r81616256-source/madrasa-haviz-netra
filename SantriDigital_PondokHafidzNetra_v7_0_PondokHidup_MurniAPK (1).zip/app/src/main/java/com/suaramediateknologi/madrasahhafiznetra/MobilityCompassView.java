package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * Komponen Orientasi Mobilitas Usap 2 Jari (v7.0 — Ramah Jieshuo & TalkBack).
 * Mendeteksi usapan 2 jari ke 4 arah kompas (UTARA / SELATAN / TIMUR / BARAT)
 * dengan ambang jarak yang nyaman agar tidak mudah salah baca.
 */
public class MobilityCompassView extends View {

    public static final String DIR_UTARA = "UTARA";
    public static final String DIR_SELATAN = "SELATAN";
    public static final String DIR_TIMUR = "TIMUR";
    public static final String DIR_BARAT = "BARAT";

    public interface OnCompassSwipeListener {
        void onTwoFingerSwipe(String direction);
    }

    private OnCompassSwipeListener listener;
    private boolean trackingTwoFingers = false;
    private float startX = 0f;
    private float startY = 0f;
    private String lastLabel = "Usap 2 jari ke Utara, Selatan, Timur, atau Barat";

    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint subPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF boxRect = new RectF();

    public MobilityCompassView(Context context) {
        super(context);
        init();
    }

    public MobilityCompassView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MobilityCompassView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setFocusable(true);
        setClickable(true);
        setContentDescription("Area Kompas Usap 2 Jari. Letakkan dua jari lalu usap ke atas untuk Utara, ke bawah untuk Selatan, ke kanan untuk Timur, atau ke kiri untuk Barat.");

        bgPaint.setColor(Color.parseColor("#132A3E"));
        bgPaint.setStyle(Paint.Style.FILL);

        borderPaint.setColor(Color.parseColor("#2A9D8F"));
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(5f);

        textPaint.setColor(Color.WHITE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(38f);
        textPaint.setFakeBoldText(true);

        subPaint.setColor(Color.parseColor("#CDE7E0"));
        subPaint.setTextAlign(Paint.Align.CENTER);
        subPaint.setTextSize(28f);
    }

    public void setOnCompassSwipeListener(OnCompassSwipeListener l) {
        this.listener = l;
    }

    public void setStatusHint(String hint) {
        this.lastLabel = (hint == null || hint.trim().isEmpty())
                ? "Usap 2 jari: Atas=Utara, Bawah=Selatan, Kanan=Timur, Kiri=Barat"
                : hint;
        setContentDescription("Area Kompas Usap 2 Jari. " + this.lastLabel);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float pad = 10f;
        boxRect.set(pad, pad, getWidth() - pad, getHeight() - pad);
        canvas.drawRoundRect(boxRect, 24f, 24f, bgPaint);
        canvas.drawRoundRect(boxRect, 24f, 24f, borderPaint);

        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        canvas.drawText("UTARA (Atas)", cx, 52f, subPaint);
        canvas.drawText("SELATAN (Bawah)", cx, getHeight() - 26f, subPaint);
        canvas.drawText("AREA USAP 2 JARI", cx, cy - 10f, textPaint);
        canvas.drawText("BARAT (Kiri)  •  TIMUR (Kanan)", cx, cy + 36f, subPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        switch (action) {
            case MotionEvent.ACTION_POINTER_DOWN:
                if (event.getPointerCount() >= 2) {
                    trackingTwoFingers = true;
                    startX = (event.getX(0) + event.getX(1)) / 2f;
                    startY = (event.getY(0) + event.getY(1)) / 2f;
                    if (getParent() != null) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                    }
                }
                return true;

            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_UP:
                if (trackingTwoFingers) {
                    trackingTwoFingers = false;
                    if (getParent() != null) {
                        getParent().requestDisallowInterceptTouchEvent(false);
                    }
                    float endX;
                    float endY;
                    if (event.getPointerCount() >= 2) {
                        endX = (event.getX(0) + event.getX(1)) / 2f;
                        endY = (event.getY(0) + event.getY(1)) / 2f;
                    } else {
                        endX = event.getX();
                        endY = event.getY();
                    }
                    float dx = endX - startX;
                    float dy = endY - startY;
                    float minDist = 75f;
                    if (Math.abs(dx) >= minDist || Math.abs(dy) >= minDist) {
                        String dir;
                        if (Math.abs(dx) > Math.abs(dy)) {
                            dir = dx > 0 ? DIR_TIMUR : DIR_BARAT;
                        } else {
                            dir = dy < 0 ? DIR_UTARA : DIR_SELATAN;
                        }
                        if (listener != null) {
                            listener.onTwoFingerSwipe(dir);
                        }
                        performClick();
                    }
                }
                return true;

            case MotionEvent.ACTION_CANCEL:
                trackingTwoFingers = false;
                if (getParent() != null) {
                    getParent().requestDisallowInterceptTouchEvent(false);
                }
                return true;

            default:
                return super.onTouchEvent(event);
        }
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    /**
     * Definisi rute berbelok multi-tahap nyata di kompleks Pondok Hafidz Netra.
     */
    public static class RouteStep {
        public final String expectedDir;
        public final String instruction;
        public final String arrivalNote;

        public RouteStep(String expectedDir, String instruction, String arrivalNote) {
            this.expectedDir = expectedDir;
            this.instruction = instruction;
            this.arrivalNote = arrivalNote;
        }
    }

    public static RouteStep[] buildRouteForDestination(String destCode) {
        if ("KELAS".equals(destCode)) {
            return new RouteStep[]{
                    new RouteStep(DIR_TIMUR, "Langkah 1: Dari Teras, usap 2 jari ke TIMUR (kanan) menuju Gerbang Utama.", "Kamu melewati Gerbang Utama Pondok."),
                    new RouteStep(DIR_UTARA, "Langkah 2: Belok ke UTARA (atas) menyusuri koridor taman menuju Gedung Kelas.", "Kamu berjalan di koridor utama yang teduh."),
                    new RouteStep(DIR_TIMUR, "Langkah 3: Belok kanan ke TIMUR (kanan) sampai tepat di depan pintu Gedung Kelas.", "Kamu tiba tepat di depan pintu Gedung Kelas Utama!")
            };
        }
        if ("SEKOLAH_FORMAL".equals(destCode)) {
            return new RouteStep[]{
                    new RouteStep(DIR_TIMUR, "Langkah 1: Usap 2 jari ke TIMUR (kanan) melewati Gerbang Utama menuju halaman pendidikan.", "Kamu melewati Gerbang Utama menuju sayap Sekolah Formal."),
                    new RouteStep(DIR_UTARA, "Langkah 2: Belok ke UTARA (atas) menyusuri selasar Gedung Madrasah.", "Suara bel sekolah formal terdengar dari sebelah utara."),
                    new RouteStep(DIR_BARAT, "Langkah 3: Belok kiri ke BARAT (kiri) sampai tepat di depan pintu Gedung Sekolah Formal (MI/MTs/MA/Ma'had Aly).", "Kamu tiba tepat di depan pintu Gedung Sekolah Formal Pondok!")
            };
        }
        if ("TU".equals(destCode)) {
            return new RouteStep[]{
                    new RouteStep(DIR_TIMUR, "Langkah 1: Usap 2 jari ke TIMUR (kanan) melewati pos jaga Kang Ridho.", "Kang Ridho menyapa ramah dari pos gerbang."),
                    new RouteStep(DIR_SELATAN, "Langkah 2: Belok ke SELATAN (bawah) menuju lorong administrasi Kantor TU.", "Kamu tiba tepat di depan pintu Kantor TU Ustadzah Nur!")
            };
        }
        if ("MASJID".equals(destCode)) {
            return new RouteStep[]{
                    new RouteStep(DIR_UTARA, "Langkah 1: Usap 2 jari ke UTARA (atas) menuju serambi tempat wudhu.", "Suara gemericik air wudhu terdengar menenangkan."),
                    new RouteStep(DIR_BARAT, "Langkah 2: Belok ke BARAT (kiri) menghadap kiblat menuju pintu utama Masjid Agung.", "Kamu tiba tepat di depan pintu Masjid Agung!")
            };
        }
        if ("PERPUS".equals(destCode)) {
            return new RouteStep[]{
                    new RouteStep(DIR_UTARA, "Langkah 1: Usap 2 jari ke UTARA (atas) menyusuri halaman tengah.", "Kamu melewati pohon rindang di tengah halaman."),
                    new RouteStep(DIR_TIMUR, "Langkah 2: Belok ke TIMUR (kanan) menuju Gedung Perpustakaan Audio.", "Kamu tiba tepat di depan pintu Perpustakaan Pondok!")
            };
        }
        if ("EKONOMI_ASRAMA".equals(destCode)) {
            return new RouteStep[]{
                    new RouteStep(DIR_SELATAN, "Langkah 1: Usap 2 jari ke SELATAN (bawah) menuju halaman Asrama & Dapur Bersama.", "Aroma masakan Dapur Asrama dan segarnya kebun terasa dekat."),
                    new RouteStep(DIR_TIMUR, "Langkah 2: Belok ke TIMUR (kanan) melewati Kebun & Kolam menuju Pasar dan Gedung Usaha Pondok.", "Kamu tiba tepat di depan pintu Kompleks Asrama, Dapur, Kebun & Pasar Pondok!")
            };
        }
        if ("KOPERASI".equals(destCode)) {
            return new RouteStep[]{
                    new RouteStep(DIR_SELATAN, "Langkah 1: Usap 2 jari ke SELATAN (bawah) menuju halaman selatan.", "Aroma kopi jahe dan buku baru tercium dari dekat."),
                    new RouteStep(DIR_BARAT, "Langkah 2: Belok ke BARAT (kiri) menuju loket Koperasi Pondok.", "Kamu tiba tepat di depan pintu Koperasi Pondok!")
            };
        }
        // Default: RUMAH / ASRAMA
        return new RouteStep[]{
                new RouteStep(DIR_BARAT, "Langkah 1: Usap 2 jari ke BARAT (kiri) keluar dari halaman pondok menuju jalan pulang.", "Kamu berjalan tenang melewati jalan kecil yang teduh."),
                new RouteStep(DIR_SELATAN, "Langkah 2: Belok ke SELATAN (bawah) menuju pagar Teras Rumah Santri.", "Kamu tiba tepat di depan pintu Rumah Santri!")
        };
    }

    public static String getDirectionGuideLabel(String dir) {
        if (DIR_UTARA.equals(dir)) return "UTARA (usap 2 jari ke atas)";
        if (DIR_SELATAN.equals(dir)) return "SELATAN (usap 2 jari ke bawah)";
        if (DIR_TIMUR.equals(dir)) return "TIMUR (usap 2 jari ke kanan)";
        return "BARAT (usap 2 jari ke kiri)";
    }
}
