package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/**
 * Mesin Jadwal & Waktu Terpadu Pesantren (v6.0).
 * Seluruh fase pondok, status jam kelas, langit, bel pulang, wirid sore,
 * dan jam layanan TU menggunakan satu sumber jam terpadu (getEffectiveHour/Minutes)
 * sehingga tidak lagi terbelah antara jam HP nyata dan jam simulasi.
 */
public class SchoolScheduleEngine {
    public static final String PHASE_SUBUH = "SUBUH";
    public static final String PHASE_PAGI = "PAGI";
    public static final String PHASE_SIANG = "SIANG";
    public static final String PHASE_SORE = "SORE";
    public static final String PHASE_MALAM = "MALAM";
    public static final String PHASE_TENGAH_MALAM = "TENGAH_MALAM";

    public static class AgendaItem {
        public String id;
        public String title;
        public boolean done;
        public AgendaItem(String id, String title, boolean done) {
            this.id = id;
            this.title = title;
            this.done = done;
        }
    }

    private final SharedPreferences prefs;

    public SchoolScheduleEngine(Context context) {
        this.prefs = context.getApplicationContext()
                .getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
    }

    public String getTodayKey() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    public String getCurrentMmDd() {
        return new SimpleDateFormat("MM-dd", Locale.US).format(new Date());
    }

    public int getDayOfWeek() {
        return Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
    }

    public boolean isSunday() { return getDayOfWeek() == Calendar.SUNDAY; }
    public boolean isFriday() { return getDayOfWeek() == Calendar.FRIDAY; }

    public boolean isThursdayNight() {
        return getDayOfWeek() == Calendar.THURSDAY && getEffectiveHour() >= 18;
    }

    public String getTodayHolidayName() {
        String mmdd = getCurrentMmDd();
        for (String[] h : AppConfig.HOLIDAYS_MMDD) {
            if (h[0].equals(mmdd)) return h[1];
        }
        return "";
    }

    public boolean isHolidayToday() {
        return isSunday() || !getTodayHolidayName().isEmpty();
    }

    public boolean isOnCuti() {
        String until = prefs.getString(AppConfig.KEY_CUTI_UNTIL_DAY, "");
        return !until.isEmpty() && getTodayKey().compareTo(until) <= 0;
    }

    // ================= SATU SUMBER JAM TERPADU =================
    public boolean isSimClockEnabled() {
        return prefs.getBoolean(AppConfig.KEY_SIM_CLOCK_ENABLED, false);
    }

    public void setSimClockEnabled(boolean enabled) {
        prefs.edit()
                .putBoolean(AppConfig.KEY_SIM_CLOCK_ENABLED, enabled)
                .putLong(AppConfig.KEY_SIM_CLOCK_ANCHOR_MS, System.currentTimeMillis())
                .apply();
    }

    public int getEffectiveMinutesOfDay() {
        if (!isSimClockEnabled()) {
            Calendar cal = Calendar.getInstance();
            return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
        }
        long anchor = prefs.getLong(AppConfig.KEY_SIM_CLOCK_ANCHOR_MS, 0L);
        int baseOffset = prefs.getInt(AppConfig.KEY_SIM_CLOCK_OFFSET_MIN, 5 * 60);
        if (anchor <= 0L) {
            prefs.edit().putLong(AppConfig.KEY_SIM_CLOCK_ANCHOR_MS, System.currentTimeMillis()).apply();
            return baseOffset % 1440;
        }
        long elapsedRealMin = Math.max(0L, (System.currentTimeMillis() - anchor) / 60000L);
        return (int) ((baseOffset + elapsedRealMin * 15L) % 1440L);
    }

    public int getCurrentMinutesOfDay() {
        return getEffectiveMinutesOfDay();
    }

    public int getEffectiveHour() { return getEffectiveMinutesOfDay() / 60; }
    public int getEffectiveMinute() { return getEffectiveMinutesOfDay() % 60; }

    public String getEffectiveClockLabel() {
        String hm = String.format(Locale.US, "%02d:%02d", getEffectiveHour(), getEffectiveMinute());
        return isSimClockEnabled() ? (hm + " [Simulasi Pondok]") : (hm + " WIB");
    }

    public String advanceSimClockPhase() {
        int h = getEffectiveHour();
        int nextMin;
        String label;
        if (h < 6) { nextMin = 8 * 60; label = "Pagi (08:00 — Kelas & TU Buka)"; }
        else if (h < 11) { nextMin = 12 * 60 + 30; label = "Siang (12:30 — Dzuhur & Istirahat)"; }
        else if (h < 16) { nextMin = 17 * 60; label = "Sore (17:00 — Wirid Sore & 6 Surat Pendek)"; }
        else if (h < 20) { nextMin = 21 * 60 + 15; label = "Malam (21:15 — Kelas Tutup, Belajar 24J di Rumah/Asrama)"; }
        else { nextMin = 5 * 60; label = "Subuh (05:00 — Doa Pagi & Kelas Subuh)"; }
        prefs.edit()
                .putBoolean(AppConfig.KEY_SIM_CLOCK_ENABLED, true)
                .putInt(AppConfig.KEY_SIM_CLOCK_OFFSET_MIN, nextMin)
                .putLong(AppConfig.KEY_SIM_CLOCK_ANCHOR_MS, System.currentTimeMillis())
                .apply();
        return label;
    }

    public String getBoardingPhase() {
        int h = getEffectiveHour();
        if (h >= 0 && h < 4) return PHASE_TENGAH_MALAM;
        if (h >= 4 && h < 7) return PHASE_SUBUH;
        if (h >= 7 && h < 12) return PHASE_PAGI;
        if (h >= 12 && h < 15) return PHASE_SIANG;
        if (h >= 15 && h < 18) return PHASE_SORE;
        return PHASE_MALAM;
    }

    public String getBoardingPhaseLabel() {
        String p = getBoardingPhase();
        if (PHASE_TENGAH_MALAM.equals(p)) return "Mode Malam Tenang (00.00 - 03.59)";
        if (PHASE_SUBUH.equals(p)) return "Fase Subuh — Setoran Sabak & Bina Pagi";
        if (PHASE_PAGI.equals(p)) return "Fase Pagi / Dhuha — Kelas Tahfidz & Diniyah";
        if (PHASE_SIANG.equals(p)) return "Fase Siang — Istirahat & Murajaah Kilat";
        if (PHASE_SORE.equals(p)) return "Fase Sore — Kegiatan Asrama & Wirid 17.00";
        return isThursdayNight() ? "Malam Jumat — Majelis Doa Arwah & Yasin" : "Fase Malam — Halaqah & Persiapan Tidur";
    }

    public boolean isSchoolLockedNightNow() {
        int h = getEffectiveHour();
        int m = getEffectiveMinute();
        return h >= 21 || h < 4 || (h == 4 && m < 30);
    }

    public String getDayPhaseForSky() {
        int h = getEffectiveHour();
        if (h >= 4 && h < 6) return "SUBUH";
        if (h >= 6 && h < 11) return "PAGI";
        if (h >= 11 && h < 15) return "SIANG";
        if (h >= 15 && h < 18) return "SORE";
        return "MALAM";
    }

    public boolean isAutoMorningPrayerWindow() {
        int h = getEffectiveHour();
        return h >= 5 && h <= 9;
    }

    public boolean isTuOfficeOpenNow() {
        int h = getEffectiveHour();
        return h >= 7 && h < 17;
    }

    public boolean isSleepLockActiveNow() {
        if (!prefs.getBoolean(AppConfig.KEY_SLEEP_LOCK_ENABLED, false)) return false;
        int totalMin = getEffectiveMinutesOfDay();
        return totalMin >= 0 && totalMin < (3 * 60 + 30);
    }

    // ================= JADWAL SLOT KELAS =================
    public int getSelectedSlotIndex() {
        int idx = prefs.getInt(AppConfig.KEY_CLASS_SLOT, 2);
        return Math.max(0, Math.min(idx, AppConfig.CLASS_SLOTS.length - 1));
    }

    public int getSlotStartMinutes() {
        int[] t = AppConfig.CLASS_SLOT_TIMES[getSelectedSlotIndex()];
        return t[0] * 60 + t[1];
    }

    public int getSlotEndMinutes() {
        int[] t = AppConfig.CLASS_SLOT_TIMES[getSelectedSlotIndex()];
        return t[2] * 60 + t[3];
    }

    public boolean isFlexibleSlot() {
        return getSelectedSlotIndex() == AppConfig.CLASS_SLOTS.length - 1;
    }

    public String getClassWindowState() {
        if (isHolidayToday()) return "HOLIDAY";
        if (isFlexibleSlot()) return "FLEXIBLE";
        int now = getEffectiveMinutesOfDay();
        int start = getSlotStartMinutes();
        int end = getSlotEndMinutes();
        if (now < start) return "BEFORE";
        if (now <= start + 15) return "ACTIVE_ONTIME";
        if (now < end) return "ACTIVE_LATE";
        return "AFTER";
    }

    public boolean shouldTriggerBelPulangNow(String todayAttendanceStatus) {
        if (isHolidayToday() || isFlexibleSlot()) return false;
        if (getTodayKey().equals(prefs.getString(AppConfig.KEY_BEL_PULANG_SHOWN_DAY, ""))) return false;
        int now = getEffectiveMinutesOfDay();
        int end = getSlotEndMinutes();
        if (now >= end && now <= end + 15 && ("HADIR".equals(todayAttendanceStatus) || "TERLAMBAT".equals(todayAttendanceStatus))) {
            prefs.edit().putString(AppConfig.KEY_BEL_PULANG_SHOWN_DAY, getTodayKey()).apply();
            return true;
        }
        return false;
    }

    public boolean shouldTriggerWiridSoreNow() {
        if (!prefs.getBoolean(AppConfig.KEY_WIRID_SORE_ENABLED, true)) return false;
        if (getTodayKey().equals(prefs.getString(AppConfig.KEY_WIRID_SHOWN_DAY, ""))) return false;
        int now = getEffectiveMinutesOfDay();
        if (now >= (17 * 60) && now <= (17 * 60 + 25)) {
            prefs.edit().putString(AppConfig.KEY_WIRID_SHOWN_DAY, getTodayKey()).apply();
            return true;
        }
        return false;
    }

    public String getTodaySubjectName() {
        int dow = getDayOfWeek();
        if (dow == Calendar.MONDAY) return "Tahfidz & Tajwid Qalqalah";
        if (dow == Calendar.TUESDAY) return "Tahfidz & Fikih Wudhu (Safinatun Najah)";
        if (dow == Calendar.WEDNESDAY) return "Tahfidz & Tauhid (Aqidatul Awam)";
        if (dow == Calendar.THURSDAY) return "Murajaah & Majelis Malam Jumat";
        if (dow == Calendar.FRIDAY) return "Jumat Berkah: Sunnah Al-Kahfi & Adab";
        if (dow == Calendar.SATURDAY) return "Fikih Shalat, Ujian Pekan & Rapat Kamar";
        return "Ahad Ceria: Sambangan Keluarga & Kelas Sore Santai";
    }

    public int getTodayInteractiveLessonIndex() {
        int dow = getDayOfWeek();
        if (dow == Calendar.MONDAY) return 2;
        if (dow == Calendar.TUESDAY) return 0;
        if (dow == Calendar.WEDNESDAY) return 3;
        if (dow == Calendar.THURSDAY) return 4;
        if (dow == Calendar.FRIDAY) return 5;
        if (dow == Calendar.SATURDAY) return 1;
        return 5;
    }

    public String buildDynamicHeroActionLabel(String attendanceToday) {
        String holiday = getTodayHolidayName();
        if (!holiday.isEmpty()) return "Hari Besar (" + holiday + ") — Bebas SP! Ikut Agenda Spesial";
        if (isSunday()) {
            return getEffectiveHour() < 15
                    ? "Ahad Ceria (Libur Pagi) — Radio Pondok & Rihlah"
                    : "Kelas Sore Ahad — Latihan Kultum & Rapat Kamar";
        }
        if (isOnCuti()) return "Status Cuti Resmi — Murajaah Santai (Bebas SP)";
        String state = getClassWindowState();
        boolean doneToday = !"NONE".equals(attendanceToday);
        if ("ACTIVE_ONTIME".equals(state)) {
            return doneToday ? "Kelas Aktif — Lanjut Belajar Blok Hari Ini" : "Masuk Kelas Sekarang (Tepat Waktu)";
        }
        if ("ACTIVE_LATE".equals(state)) {
            return doneToday ? "Kelas Aktif — Lanjut Sesi Kilat Hari Ini" : "Masuk Kelas Sekarang (Terlambat)";
        }
        if ("AFTER".equals(state) && !doneToday) {
            return "Kelas Hari Ini Terlewat — Masuk Kelas Susulan / Izin TU";
        }
        String phase = getBoardingPhase();
        if (isThursdayNight()) return "Malam Jumat — Buka Majelis Doa Arwah & Yasin";
        if (PHASE_SORE.equals(phase)) return "Sore Pondok — Wirid Sore 17.00 & 6 Surat Pendek";
        if (PHASE_MALAM.equals(phase)) return "Aktivitas Malam — Kunci 1 Ayat Besok & Tilawah Tidur";
        return "Masuk Kelas Hari Ini (" + AppConfig.CLASS_SLOTS[getSelectedSlotIndex()] + ")";
    }

    // ================= BUKU ABSENSI 5 STATUS (TERINTEGRASI NYATA) =================
    public void recordAttendanceStatus(String status) {
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_ATTENDANCE_MONTH_JSON, "{}"));
            obj.put(getTodayKey(), status);
            prefs.edit().putString(AppConfig.KEY_ATTENDANCE_MONTH_JSON, obj.toString()).apply();
        } catch (Exception ignored) {}
    }

    public int getMonthlyAttendancePercent() {
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_ATTENDANCE_MONTH_JSON, "{}"));
            int total = obj.length();
            if (total == 0) return 100;
            double points = 0.0;
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String v = obj.optString(keys.next(), "");
                if ("HADIR".equals(v)) points += 1.0;
                else if ("TERLAMBAT".equals(v)) points += 0.85;
                else if ("SUSULAN".equals(v)) points += 0.75;
                else if ("IZIN".equals(v) || "SAKIT".equals(v) || "CUTI".equals(v)) points += 0.90;
            }
            return (int) Math.round((points * 100.0) / total);
        } catch (Exception ignored) {
            return 100;
        }
    }

    public String buildMonthlyAttendanceReport() {
        int tepat = 0, telat = 0, susulan = 0, izin = 0, alfa = 0;
        try {
            JSONObject obj = new JSONObject(prefs.getString(AppConfig.KEY_ATTENDANCE_MONTH_JSON, "{}"));
            Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String v = obj.optString(keys.next(), "");
                if ("HADIR".equals(v)) tepat++;
                else if ("TERLAMBAT".equals(v)) telat++;
                else if ("SUSULAN".equals(v)) susulan++;
                else if ("IZIN".equals(v) || "SAKIT".equals(v) || "CUTI".equals(v)) izin++;
                else if ("ALFA".equals(v)) alfa++;
            }
        } catch (Exception ignored) {}
        int pct = getMonthlyAttendancePercent();
        return "BUKU ABSENSI 5 STATUS (REKAP NYATA)\n"
                + "• Hadir Tepat Waktu (100%): " + tepat + " hari\n"
                + "• Hadir Terlambat (85%): " + telat + " hari\n"
                + "• Hadir Kelas Susulan (75%): " + susulan + " hari\n"
                + "• Izin / Sakit / Cuti Resmi: " + izin + " hari\n"
                + "• Alfa Tanpa Keterangan: " + alfa + " hari\n\n"
                + "Persentase Kehadiran: " + pct + "% ("
                + (pct >= 75 ? "Memenuhi Syarat Naik Jenjang" : "Perlu Kelas Susulan agar >= 75%") + ")";
    }

    // ================= AGENDA PRIBADI (TAMBAH, CENTANG, HAPUS) =================
    public List<AgendaItem> getPersonalAgendaList() {
        List<AgendaItem> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString(AppConfig.KEY_PERSONAL_AGENDA_JSON, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new AgendaItem(o.optString("id"), o.optString("title"), o.optBoolean("done", false)));
            }
        } catch (Exception ignored) {}
        return out;
    }

    private void savePersonalAgendaList(List<AgendaItem> list) {
        try {
            JSONArray arr = new JSONArray();
            for (AgendaItem a : list) {
                JSONObject o = new JSONObject();
                o.put("id", a.id);
                o.put("title", a.title);
                o.put("done", a.done);
                arr.put(o);
            }
            prefs.edit().putString(AppConfig.KEY_PERSONAL_AGENDA_JSON, arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public void addPersonalAgenda(String title) {
        if (title == null || title.trim().isEmpty()) return;
        List<AgendaItem> list = getPersonalAgendaList();
        list.add(new AgendaItem("AG_" + System.currentTimeMillis(), title.trim(), false));
        savePersonalAgendaList(list);
    }

    public void toggleAgendaDone(int idx) {
        List<AgendaItem> list = getPersonalAgendaList();
        if (idx >= 0 && idx < list.size()) {
            list.get(idx).done = !list.get(idx).done;
            savePersonalAgendaList(list);
        }
    }

    public void deletePersonalAgenda(int idx) {
        List<AgendaItem> list = getPersonalAgendaList();
        if (idx >= 0 && idx < list.size()) {
            list.remove(idx);
            savePersonalAgendaList(list);
        }
    }

    public String getHijriDateLabel() {
        Calendar cal = Calendar.getInstance();
        int d = cal.get(Calendar.DAY_OF_MONTH);
        int m = cal.get(Calendar.MONTH) + 1;
        int y = cal.get(Calendar.YEAR);
        int jd = (1461 * (y + 4800 + (m - 14) / 12)) / 4
                + (367 * (m - 2 - 12 * ((m - 14) / 12))) / 12
                - (3 * ((y + 4900 + (m - 14) / 12) / 100)) / 4 + d - 32075;
        int l = jd - 1948440 + 10632;
        int n = (l - 1) / 10631;
        l = l - 10631 * n + 354;
        int j = ((10985 - l) / 5316) * ((50 * l) / 17719) + (l / 5670) * ((43 * l) / 15238);
        l = l - ((30 - j) / 15) * ((17719 * j) / 50) - (j / 16) * ((15238 * j) / 43) + 29;
        int hm = (24 * l) / 709;
        int hd = l - (709 * hm) / 24;
        int hy = 30 * n + j - 30;
        String[] months = {"Muharram", "Safar", "Rabi'ul Awal", "Rabi'ul Akhir", "Jumadil Awal", "Jumadil Akhir",
                "Rajab", "Sya'ban", "Ramadhan", "Syawal", "Dzulqa'dah", "Dzulhijjah"};
        String mName = months[Math.max(0, Math.min(hm - 1, 11))];
        return hd + " " + mName + " " + hy + " H";
    }

    // ================= v7.0 KALENDER NYATA, MALAM JUMAT & 5 STATUS ABSENSI =================

    public boolean isRealSundayToday() {
        return Calendar.getInstance().get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY;
    }

    public boolean isMalamJumatNow() {
        Calendar cal = Calendar.getInstance();
        int dow = cal.get(Calendar.DAY_OF_WEEK);
        int hour = getEffectiveHour();
        return (dow == Calendar.THURSDAY && hour >= 18) || (dow == Calendar.FRIDAY && hour < 5);
    }

    public boolean isClassActiveNow() {
        if (isRealSundayToday() && !isSimClockEnabled()) return false;
        if (isHolidayToday() || isOnCuti() || isSchoolLockedNightNow()) return false;
        if (isFlexibleSlot()) return true;
        int now = getEffectiveMinutesOfDay();
        return now >= getSlotStartMinutes() - 5 && now <= getSlotEndMinutes();
    }

    public int getRemainingClassMinutes() {
        if (isFlexibleSlot()) return 30;
        int diff = getSlotEndMinutes() - getEffectiveMinutesOfDay();
        return Math.max(0, diff);
    }

    /**
     * Menghitung 5 status absensi bulan ini secara nyata:
     * [0]=Hadir, [1]=Terlambat, [2]=Izin, [3]=Sakit, [4]=Alpa.
     */
    public int[] getFiveStatusAttendanceCounts() {
        int[] counts = new int[5];
        String monthPrefix = new SimpleDateFormat("yyyy-MM-", Locale.US).format(new Date());
        for (int day = 1; day <= 31; day++) {
            String key = "att_day_" + monthPrefix + String.format(Locale.US, "%02d", day);
            String st = prefs.getString(key, "");
            if ("HADIR".equalsIgnoreCase(st)) counts[0]++;
            else if ("TERLAMBAT".equalsIgnoreCase(st)) counts[1]++;
            else if ("IZIN".equalsIgnoreCase(st)) counts[2]++;
            else if ("SAKIT".equalsIgnoreCase(st)) counts[3]++;
            else if ("ALPA".equalsIgnoreCase(st)) counts[4]++;
        }
        return counts;
    }

    public String getRealCalendarSummary() {
        String[] days = {"", "Ahad (Libur Resmi & Sambangan)", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"};
        int dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
        String dayName = (dow >= 1 && dow <= 7) ? days[dow] : "Hari Ini";
        String realDate = new SimpleDateFormat("dd MMM yyyy", new Locale("id", "ID")).format(new Date());
        String simNote = isSimClockEnabled() ? " [Simulasi]" : " [Jam Nyata]";
        return dayName + ", " + realDate + " • " + getEffectiveClockLabel() + simNote;
    }

}
