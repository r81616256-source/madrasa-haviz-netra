package com.suaramediateknologi.madrasahhafiznetra;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;
import java.util.Locale;

/**
 * Penjadwal Alarm Presisi Pondok Hafidz Netra (v7.0 — ala Nurul Masjid Pro).
 * Menggunakan AlarmManager.setAlarmClock agar tahan Doze Mode dan benar-benar
 * membangunkan suara bel kelas, Doa Pagi, Wirid Sore, PR Rumah, dan Majelis Malam Jumat
 * secara otomatis mengikuti 100% waktu & kalender dunia nyata.
 *
 * Kode Alarm Resmi:
 * 401: 5 menit sebelum jam kelas (Bel Panggilan Kelas)
 * 402: +30 menit setelah jam kelas (Cek Susulan / Izin jika belum absen)
 * 403: 13.00 WIB (Pengingat 1 Ayat Anti-Lupa & Tugas Rumah)
 * 404: 17.00 WIB (Corong Masjid: Wirid Sore Otomatis)
 * 405: 06.00 WIB (Doa Pagi Otomatis, PR Ayat Sulit, Milad & Ahad Sambangan)
 * 406: 18.30 WIB (Khusus Kamis / Malam Jumat: Majelis Yasin, Tahlil & Doa Arwah)
 */
public class ReminderScheduler {

    public static final int REQ_BEL_KELAS = 401;
    public static final int REQ_SUSULAN = 402;
    public static final int REQ_ANTILUPA = 403;
    public static final int REQ_WIRID_SORE = 404;
    public static final int REQ_DOA_PAGI = 405;
    public static final int REQ_MALAM_JUMAT = 406;

    public static void scheduleAll(Context context) {
        if (context == null) return;
        Context appCtx = context.getApplicationContext();
        SharedPreferences prefs = appCtx.getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(AppConfig.KEY_REMINDER_ENABLED, true)
                || !prefs.getBoolean(AppConfig.KEY_BG_ALERTS_ENABLED, true)) {
            cancelAll(appCtx);
            return;
        }

        int slotIdx = Math.max(0, Math.min(prefs.getInt(AppConfig.KEY_CLASS_SLOT, 2),
                AppConfig.CLASS_SLOT_TIMES.length - 1));
        int[] t = AppConfig.CLASS_SLOT_TIMES[slotIdx];

        if (slotIdx < AppConfig.CLASS_SLOT_TIMES.length - 1) {
            int preMin = Math.max(0, t[0] * 60 + t[1] - 5);
            scheduleDailyAlarmClock(appCtx, REQ_BEL_KELAS, preMin / 60, preMin % 60, false,
                    "Bel Panggilan Kelas (5 Menit Lagi)",
                    "Kang Ridho: 5 menit lagi jam kelasmu dimulai. Yuk menuju Gedung Kelas untuk presensi!",
                    "BEL_KELAS");

            int lateMin = (t[0] * 60 + t[1] + 30) % (24 * 60);
            scheduleDailyAlarmClock(appCtx, REQ_SUSULAN, lateMin / 60, lateMin % 60, false,
                    "Panggilan Ustadzah Nur — Cek Kehadiran",
                    "Ustadzah Nur: Hari ini kamu belum presensi di kelas. Yuk ikut kelas susulan atau ajukan izin resmi di TU.",
                    "SUSULAN");
        } else {
            cancelCode(appCtx, REQ_BEL_KELAS);
            cancelCode(appCtx, REQ_SUSULAN);
        }

        scheduleDailyAlarmClock(appCtx, REQ_ANTILUPA, 13, 0, false,
                "Pengingat Siang — Anti-Lupa & Tugas Rumah",
                "Ustadz Yeni: Yuk sempatkan murajaah 1 ayat dan cek tugas rumahmu di Kamar Pribadi.",
                "ANTI_LUPA");

        scheduleDailyAlarmClock(appCtx, REQ_WIRID_SORE, 17, 0, false,
                "Corong Masjid — Wirid Sore 17.00",
                "Corong Masjid Agung: Waktunya Wirid Sore dan 6 surat pendek penenang hati.",
                "WIRID_SORE");

        scheduleDailyAlarmClock(appCtx, REQ_DOA_PAGI, 6, 0, false,
                "Doa Pagi & Agenda Harian Pondok",
                "Assalamu'alaikum! Waktunya Doa Pagi otomatis dan menyimak pesan hari ini dari Pondok.",
                "DOA_PAGI");

        scheduleDailyAlarmClock(appCtx, REQ_MALAM_JUMAT, 18, 30, false,
                "Panggilan Masjid — Majelis Malam Jumat",
                "Corong Masjid Agung: Malam Jumat telah tiba. Mari berkumpul di Masjid Agung untuk Doa Arwah, Yasin, dan Tahlil.",
                "MALAM_JUMAT");
    }

    public static void rescheduleForTomorrow(Context context, String type) {
        if (context == null || type == null) return;
        Context appCtx = context.getApplicationContext();
        SharedPreferences prefs = appCtx.getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(AppConfig.KEY_REMINDER_ENABLED, true)
                || !prefs.getBoolean(AppConfig.KEY_BG_ALERTS_ENABLED, true)) {
            return;
        }
        int slotIdx = Math.max(0, Math.min(prefs.getInt(AppConfig.KEY_CLASS_SLOT, 2),
                AppConfig.CLASS_SLOT_TIMES.length - 1));
        int[] t = AppConfig.CLASS_SLOT_TIMES[slotIdx];

        switch (type) {
            case "BEL_KELAS": {
                int preMin = Math.max(0, t[0] * 60 + t[1] - 5);
                scheduleDailyAlarmClock(appCtx, REQ_BEL_KELAS, preMin / 60, preMin % 60, true,
                        "Bel Panggilan Kelas (5 Menit Lagi)",
                        "Kang Ridho: 5 menit lagi jam kelasmu dimulai. Yuk menuju Gedung Kelas untuk presensi!",
                        "BEL_KELAS");
                break;
            }
            case "SUSULAN": {
                int lateMin = (t[0] * 60 + t[1] + 30) % (24 * 60);
                scheduleDailyAlarmClock(appCtx, REQ_SUSULAN, lateMin / 60, lateMin % 60, true,
                        "Panggilan Ustadzah Nur — Cek Kehadiran",
                        "Ustadzah Nur: Hari ini kamu belum presensi di kelas. Yuk ikut kelas susulan atau ajukan izin resmi di TU.",
                        "SUSULAN");
                break;
            }
            case "ANTI_LUPA":
                scheduleDailyAlarmClock(appCtx, REQ_ANTILUPA, 13, 0, true,
                        "Pengingat Siang — Anti-Lupa & Tugas Rumah",
                        "Ustadz Yeni: Yuk sempatkan murajaah 1 ayat dan cek tugas rumahmu di Kamar Pribadi.",
                        "ANTI_LUPA");
                break;
            case "WIRID_SORE":
                scheduleDailyAlarmClock(appCtx, REQ_WIRID_SORE, 17, 0, true,
                        "Corong Masjid — Wirid Sore 17.00",
                        "Corong Masjid Agung: Waktunya Wirid Sore dan 6 surat pendek penenang hati.",
                        "WIRID_SORE");
                break;
            case "DOA_PAGI":
                scheduleDailyAlarmClock(appCtx, REQ_DOA_PAGI, 6, 0, true,
                        "Doa Pagi & Agenda Harian Pondok",
                        "Assalamu'alaikum! Waktunya Doa Pagi otomatis dan menyimak pesan hari ini dari Pondok.",
                        "DOA_PAGI");
                break;
            case "MALAM_JUMAT":
                scheduleDailyAlarmClock(appCtx, REQ_MALAM_JUMAT, 18, 30, true,
                        "Panggilan Masjid — Majelis Malam Jumat",
                        "Corong Masjid Agung: Malam Jumat telah tiba. Mari berkumpul di Masjid Agung untuk Doa Arwah, Yasin, dan Tahlil.",
                        "MALAM_JUMAT");
                break;
        }
    }

    public static String getNextScheduleHint(Context context) {
        if (context == null) return "Doa Pagi 06.00 & Wirid Sore 17.00";
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
        int slotIdx = Math.max(0, Math.min(prefs.getInt(AppConfig.KEY_CLASS_SLOT, 2),
                AppConfig.CLASS_SLOT_TIMES.length - 1));
        if (slotIdx >= AppConfig.CLASS_SLOT_TIMES.length - 1) {
            return "Doa Pagi 06.00 • PR 13.00 • Wirid 17.00";
        }
        int[] t = AppConfig.CLASS_SLOT_TIMES[slotIdx];
        return String.format(Locale.US, "Kelas %02d:%02d • Wirid 17:00", t[0], t[1]);
    }

    public static void cancelAll(Context context) {
        if (context == null) return;
        Context appCtx = context.getApplicationContext();
        cancelCode(appCtx, REQ_BEL_KELAS);
        cancelCode(appCtx, REQ_SUSULAN);
        cancelCode(appCtx, REQ_ANTILUPA);
        cancelCode(appCtx, REQ_WIRID_SORE);
        cancelCode(appCtx, REQ_DOA_PAGI);
        cancelCode(appCtx, REQ_MALAM_JUMAT);
    }

    private static void cancelCode(Context context, int reqCode) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            Intent intent = new Intent(context, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(context, reqCode, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);
        } catch (Exception ignored) {}
    }

    private static void scheduleDailyAlarmClock(Context context, int reqCode, int hour, int minute,
                                                boolean forceTomorrow, String title, String body, String type) {
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;

            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, hour);
            cal.set(Calendar.MINUTE, minute);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            if (forceTomorrow || cal.getTimeInMillis() <= System.currentTimeMillis() + 5000L) {
                cal.add(Calendar.DAY_OF_YEAR, 1);
            }

            Intent intent = new Intent(context, ReminderReceiver.class);
            intent.putExtra("req_code", reqCode);
            intent.putExtra("title", title);
            intent.putExtra("body", body);
            intent.putExtra("type", type);

            PendingIntent pi = PendingIntent.getBroadcast(context, reqCode, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Intent showIntent = new Intent(context, MainActivity.class);
            showIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent showPi = PendingIntent.getActivity(context, reqCode + 1000, showIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            boolean canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms();
            if (canExact) {
                AlarmManager.AlarmClockInfo clockInfo = new AlarmManager.AlarmClockInfo(cal.getTimeInMillis(), showPi);
                am.setAlarmClock(clockInfo, pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            }
        } catch (Exception ignored) {
            try {
                AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
                if (am == null) return;
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.HOUR_OF_DAY, hour);
                cal.set(Calendar.MINUTE, minute);
                cal.set(Calendar.SECOND, 0);
                if (forceTomorrow || cal.getTimeInMillis() <= System.currentTimeMillis() + 5000L) {
                    cal.add(Calendar.DAY_OF_YEAR, 1);
                }
                Intent intent = new Intent(context, ReminderReceiver.class);
                intent.putExtra("req_code", reqCode);
                intent.putExtra("title", title);
                intent.putExtra("body", body);
                intent.putExtra("type", type);
                PendingIntent pi = PendingIntent.getBroadcast(context, reqCode, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            } catch (Exception ignored2) {}
        }
    }

    public static void scheduleCustomAgendaAlarm(Context context, int reqCode, int hour, int minute, String agendaTitle) {
        if (context == null) return;
        scheduleDailyAlarmClock(context.getApplicationContext(), reqCode, hour, minute, false,
                "Agenda Pribadi Pondok",
                agendaTitle == null ? "Waktunya melaksanakan agenda belajarmu!" : agendaTitle,
                "CUSTOM_AGENDA");
    }

    public static void cancelCustomAgendaAlarm(Context context, int reqCode) {
        if (context == null) return;
        cancelCode(context.getApplicationContext(), reqCode);
    }

}
