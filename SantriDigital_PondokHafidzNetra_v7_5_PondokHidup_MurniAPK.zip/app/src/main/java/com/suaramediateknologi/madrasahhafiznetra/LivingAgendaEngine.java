package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Mesin Buku Agenda Hidup, Ritme 5 Fase Kehidupan Pondok & Kotak Pesan Harian (v7.5).
 * Mengubah tulisan agenda bebas santri (mis. "sore menghafal surat Yasin ayat 1 sampai 5")
 * menjadi kegiatan nyata lengkap dengan jam alarm otomatis, nomor surat, dan rentang ayat.
 */
public class LivingAgendaEngine {

    private static final String KEY_LIVING_AGENDAS = "v75_living_agendas_json";
    private static final String KEY_DAILY_MSG_REPLIED_DATE = "v75_daily_msg_replied_date";

    public static class LivingAgendaItem {
        public String id;
        public String rawText;
        public int hour;
        public int minute;
        public String category; // HAFALAN, FORMAL, KEBUN_PASAR, MASJID, UMUM
        public int surahNo;     // >0 jika terdeteksi nama surat
        public String surahName;
        public int startAyah;
        public int endAyah;
        public boolean done;
        public int alarmReqCode;

        public String getTimeLabel() {
            return String.format(Locale.US, "%02d:%02d", hour, minute);
        }
    }

    public static class DailyFamilyMessage {
        public final String sender;
        public final String message;
        public final String quickReply;

        public DailyFamilyMessage(String sender, String message, String quickReply) {
            this.sender = sender;
            this.message = message;
            this.quickReply = quickReply;
        }
    }

    private final SharedPreferences prefs;

    public LivingAgendaEngine(Context context) {
        this.prefs = context.getApplicationContext().getSharedPreferences(AppConfig.PREF_NAME, Context.MODE_PRIVATE);
    }

    /**
     * Membaca teks agenda bebas bahasa Indonesia dan otomatis mengekstrak:
     * jam, nama surat (mis. Yasin, Al-Mulk, An-Naba), rentang ayat (1 sampai 5), dan kategori.
     */
    public LivingAgendaItem addAndParseAgenda(Context context, String rawInput) {
        String clean = rawInput == null ? "" : rawInput.trim();
        if (clean.isEmpty()) return null;
        String lower = clean.toLowerCase(Locale.ROOT);

        LivingAgendaItem item = new LivingAgendaItem();
        item.id = "ag_" + System.currentTimeMillis();
        item.rawText = clean;
        item.done = false;
        item.alarmReqCode = 600 + (int) (Math.abs(System.currentTimeMillis() / 1000L) % 300);

        // 1. Deteksi jam eksplisit (contoh: 16:00, 19.30, jam 7 malam, jam 4 sore)
        int[] hm = parseTimeFromText(lower);
        item.hour = hm[0];
        item.minute = hm[1];

        // 2. Deteksi surat & rentang ayat (contoh: "surat yasin ayat 1 sampai 5" atau "yasin 1-5")
        int[] surahMatch = detectSurahFromText(lower);
        item.surahNo = surahMatch[0];
        item.surahName = getSurahNameByNo(item.surahNo);

        int[] ayahRange = parseAyahRange(lower);
        item.startAyah = ayahRange[0];
        item.endAyah = ayahRange[1];

        // 3. Deteksi kategori kegiatan otomatis
        if (item.surahNo > 0 || lower.contains("hafal") || lower.contains("murajaah")
                || lower.contains("ayat") || lower.contains("surat") || lower.contains("iqra")) {
            item.category = "HAFALAN";
        } else if (lower.contains("matematika") || lower.contains("ipa") || lower.contains("bahasa")
                || lower.contains("formal") || lower.contains("sekolah")) {
            item.category = "FORMAL";
        } else if (lower.contains("kebun") || lower.contains("kolam") || lower.contains("pasar")
                || lower.contains("masak") || lower.contains("dapur")) {
            item.category = "KEBUN_PASAR";
        } else if (lower.contains("masjid") || lower.contains("wirid") || lower.contains("dzikir")
                || lower.contains("yasin") || lower.contains("tahlil") || lower.contains("doa")) {
            item.category = "MASJID";
        } else {
            item.category = "UMUM";
        }

        List<LivingAgendaItem> all = getAllAgendas();
        all.add(0, item);
        saveAllAgendas(all);

        // Pasang alarm presisi setAlarmClock otomatis untuk agenda ini!
        ReminderScheduler.scheduleCustomAgendaAlarm(
                context, item.alarmReqCode, item.hour, item.minute,
                "Agenda Pribadi (" + item.getTimeLabel() + "): " + item.rawText
        );
        return item;
    }

    public List<LivingAgendaItem> getAllAgendas() {
        List<LivingAgendaItem> list = new ArrayList<>();
        String raw = prefs.getString(KEY_LIVING_AGENDAS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                LivingAgendaItem it = new LivingAgendaItem();
                it.id = o.optString("id", "ag_" + i);
                it.rawText = o.optString("rawText", "");
                it.hour = o.optInt("hour", 16);
                it.minute = o.optInt("minute", 0);
                it.category = o.optString("category", "UMUM");
                it.surahNo = o.optInt("surahNo", 0);
                it.surahName = o.optString("surahName", "");
                it.startAyah = o.optInt("startAyah", 1);
                it.endAyah = o.optInt("endAyah", 1);
                it.done = o.optBoolean("done", false);
                it.alarmReqCode = o.optInt("alarmReqCode", 600 + i);
                list.add(it);
            }
        } catch (Exception ignored) {}
        return list;
    }

    public void markAgendaDone(String id) {
        List<LivingAgendaItem> all = getAllAgendas();
        for (LivingAgendaItem it : all) {
            if (it.id.equals(id)) it.done = true;
        }
        saveAllAgendas(all);
    }

    public void deleteAgenda(Context context, String id) {
        List<LivingAgendaItem> all = getAllAgendas();
        List<LivingAgendaItem> kept = new ArrayList<>();
        for (LivingAgendaItem it : all) {
            if (it.id.equals(id)) {
                ReminderScheduler.cancelCustomAgendaAlarm(context, it.alarmReqCode);
            } else {
                kept.add(it);
            }
        }
        saveAllAgendas(kept);
    }

    private void saveAllAgendas(List<LivingAgendaItem> list) {
        try {
            JSONArray arr = new JSONArray();
            for (int i = 0; i < Math.min(list.size(), 25); i++) {
                LivingAgendaItem it = list.get(i);
                JSONObject o = new JSONObject();
                o.put("id", it.id);
                o.put("rawText", it.rawText);
                o.put("hour", it.hour);
                o.put("minute", it.minute);
                o.put("category", it.category);
                o.put("surahNo", it.surahNo);
                o.put("surahName", it.surahName == null ? "" : it.surahName);
                o.put("startAyah", it.startAyah);
                o.put("endAyah", it.endAyah);
                o.put("done", it.done);
                o.put("alarmReqCode", it.alarmReqCode);
                arr.put(o);
            }
            prefs.edit().putString(KEY_LIVING_AGENDAS, arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private int[] parseTimeFromText(String lower) {
        // Pola 1: HH:MM atau HH.MM (mis. 16:00, 07.30)
        Matcher m1 = Pattern.compile("\\b([01]?\\d|2[0-3])[:.]([0-5]\\d)\\b").matcher(lower);
        if (m1.find()) {
            int h = Integer.parseInt(m1.group(1));
            int min = Integer.parseInt(m1.group(2));
            if ((lower.contains("sore") || lower.contains("malam")) && h >= 1 && h <= 11) h += 12;
            return new int[]{h % 24, min};
        }
        // Pola 2: "jam 4 sore", "pukul 8 malam", "jam 7 pagi"
        Matcher m2 = Pattern.compile("(?:jam|pukul)\\s+(\\d{1,2})").matcher(lower);
        if (m2.find()) {
            int h = Integer.parseInt(m2.group(1));
            if ((lower.contains("sore") || lower.contains("malam")) && h >= 1 && h <= 11) h += 12;
            return new int[]{Math.min(23, Math.max(0, h)), 0};
        }
        // Pola 3: Kata waktu alami
        if (lower.contains("subuh")) return new int[]{4, 45};
        if (lower.contains("pagi") || lower.contains("dhuha")) return new int[]{7, 30};
        if (lower.contains("siang") || lower.contains("dzuhur")) return new int[]{13, 0};
        if (lower.contains("sore") || lower.contains("ashar")) return new int[]{16, 0};
        if (lower.contains("maghrib")) return new int[]{18, 15};
        if (lower.contains("malam") || lower.contains("isya")) return new int[]{19, 30};

        // Default: 1 jam dari sekarang
        Calendar c = Calendar.getInstance();
        c.add(Calendar.HOUR_OF_DAY, 1);
        return new int[]{c.get(Calendar.HOUR_OF_DAY), 0};
    }

    private int[] parseAyahRange(String lower) {
        Matcher m = Pattern.compile("ayat\\s*(\\d{1,3})\\s*(?:sampai|s/d|hingga|-|ke)\\s*(\\d{1,3})").matcher(lower);
        if (m.find()) {
            int a = Math.max(1, Integer.parseInt(m.group(1)));
            int b = Math.max(a, Integer.parseInt(m.group(2)));
            return new int[]{a, b};
        }
        Matcher mSingle = Pattern.compile("ayat\\s*(\\d{1,3})").matcher(lower);
        if (mSingle.find()) {
            int a = Math.max(1, Integer.parseInt(mSingle.group(1)));
            return new int[]{a, a};
        }
        return new int[]{1, 1};
    }

    private int[] detectSurahFromText(String lower) {
        if (lower.contains("yasin") || lower.contains("yaasin")) return new int[]{36};
        if (lower.contains("al-mulk") || lower.contains("al mulk") || lower.contains("mulk")) return new int[]{67};
        if (lower.contains("waqiah") || lower.contains("waqi'ah")) return new int[]{56};
        if (lower.contains("rahman")) return new int[]{55};
        if (lower.contains("kahfi")) return new int[]{18};
        if (lower.contains("fatihah")) return new int[]{1};
        if (lower.contains("baqarah")) return new int[]{2};
        if (lower.contains("naba")) return new int[]{78};
        if (lower.contains("naziat") || lower.contains("nazi'at")) return new int[]{79};
        if (lower.contains("abasa")) return new int[]{80};
        if (lower.contains("a'la") || lower.contains("ala ")) return new int[]{87};
        if (lower.contains("duha") || lower.contains("dhuha")) return new int[]{93};
        if (lower.contains("insyirah") || lower.contains("syarh")) return new int[]{94};
        if (lower.contains("tin")) return new int[]{95};
        if (lower.contains("alaq")) return new int[]{96};
        if (lower.contains("qadr")) return new int[]{97};
        if (lower.contains("zalzalah")) return new int[]{99};
        if (lower.contains("kautsar")) return new int[]{108};
        if (lower.contains("kafirun")) return new int[]{109};
        if (lower.contains("nasr")) return new int[]{110};
        if (lower.contains("ikhlas")) return new int[]{112};
        if (lower.contains("falaq")) return new int[]{113};
        if (lower.contains("an-nas") || lower.contains("annas") || lower.contains("an nas")) return new int[]{114};
        return new int[]{0};
    }

    private String getSurahNameByNo(int no) {
        switch (no) {
            case 1: return "Al-Fatihah";
            case 2: return "Al-Baqarah";
            case 18: return "Al-Kahfi";
            case 36: return "Yasin";
            case 55: return "Ar-Rahman";
            case 56: return "Al-Waqi'ah";
            case 67: return "Al-Mulk";
            case 78: return "An-Naba";
            case 79: return "An-Nazi'at";
            case 80: return "'Abasa";
            case 87: return "Al-A'la";
            case 93: return "Ad-Duha";
            case 94: return "Al-Insyirah";
            case 95: return "At-Tin";
            case 96: return "Al-'Alaq";
            case 97: return "Al-Qadr";
            case 99: return "Az-Zalzalah";
            case 108: return "Al-Kautsar";
            case 109: return "Al-Kafirun";
            case 110: return "An-Nasr";
            case 112: return "Al-Ikhlas";
            case 113: return "Al-Falaq";
            case 114: return "An-Nas";
            default: return "";
        }
    }

    // ================= RITME 5 FASE KEHIDUPAN PONDOK & RUMAH =================

    public String getFivePhaseLifeRhythmBanner(int hour) {
        if (hour < 6) {
            return "Ritme Subuh Pondok: Waktu tenang qiyamul lail, persiapan Doa & Dzikir Pagi Hisnul Muslim jam 06.00.";
        } else if (hour < 11) {
            return "Ritme Pagi Pondok: Suasana aktif Gedung Kelas Tahfidz, Sekolah Formal, dan Kantor TU Ustadzah Nur.";
        } else if (hour < 15) {
            return "Ritme Siang Pondok: Waktunya istirahat Dapur Asrama, makan siang bergizi, dan murajaah 1 ayat anti-lupa.";
        } else if (hour < 18) {
            return "Ritme Sore Pondok: Waktunya panen Kebun/Kolam Asrama, cek Pasar Pondok, dan persiapan Wirid Sore 17.00.";
        } else {
            return "Ritme Malam Rumah & Asrama: Suasana tenang untuk Mode 1-2 Ayat di Kamar Pribadi, jurnal ke TU, atau Majelis Malam Jumat.";
        }
    }

    // ================= KOTAK PESAN HARIAN PENGURUS & KELUARGA =================

    public DailyFamilyMessage getTodayInboxMessage(String santriName, String waliName) {
        int day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
        String nama = (santriName == null || santriName.trim().isEmpty()) ? "Santri" : santriName;
        String wali = (waliName == null || waliName.trim().isEmpty()) ? "Orang Tua" : waliName;
        DailyFamilyMessage[] msgs = {
                new DailyFamilyMessage("Ustadzah Nur (Kantor TU)",
                        "Assalamu'alaikum " + nama + ", jangan lupa tulis agenda belajarmu hari ini di Buku Agenda Hidup supaya makin disiplin ya!",
                        "Wa'alaikumussalam Ustadzah Nur, insyaAllah siap disiplin hari ini!"),
                new DailyFamilyMessage("Ustadz Yeni Setiawan",
                        "Assalamu'alaikum " + nama + ", hafalan sedikit tapi rutin setiap hari jauh lebih berkah daripada tergesa-gesa. Semangat!",
                        "Wa'alaikumussalam Ustadz Yeni, terima kasih nasihatnya!"),
                new DailyFamilyMessage(wali + " (Rumah)",
                        "Assalamu'alaikum nak " + nama + ", jangan lupa minum air hangat di Dapur dan jaga kesehatan suaramu ya. Kami selalu mendoakanmu.",
                        "Wa'alaikumussalam, terima kasih doanya. Saya sehat dan semangat belajar!"),
                new DailyFamilyMessage("Kang Ridho (Gerbang & Kebun)",
                        "Assalamu'alaikum " + nama + ", sayur dan jahe di Kebun Asrama sudah segar siap dipanen sore ini. Mampir ya kalau senggang!",
                        "Wa'alaikumussalam Kang Ridho, siap nanti sore saya cek kebun!")
        };
        return msgs[day % msgs.length];
    }

    public boolean isTodayMessageReplied() {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        return today.equals(prefs.getString(KEY_DAILY_MSG_REPLIED_DATE, ""));
    }

    public void markTodayMessageReplied() {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        prefs.edit().putString(KEY_DAILY_MSG_REPLIED_DATE, today).apply();
    }
}
