package com.suaramediateknologi.madrasahhafiznetra;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class QuranRepository {
    public static class SurahSummary {
        public int nomor;
        public String namaLatin;
        public String namaArab;
        public String arti;
        public int jumlahAyat;
    }

    public static class AyahItem {
        public int surahNo;
        public String surahName;
        public int nomorAyat;
        public String teksArab;
        public String teksLatin;
        public String teksIndonesia;
        public String audioDefaultUrl;
    }

    public static class WordItem {
        public int position;
        public String textUthmani;
        public String transliteration;
        public String audioUrl;
    }

    public static class WaqafSegment {
        public int index;
        public String textArabic;
        public List<WordItem> words = new ArrayList<>();
    }

    public static class RemoteLesson {
        public String id;
        public String kategori;
        public String judul;
        public String ringkasan;
        public String audioNaratorUrl;
        public int contohSurah;
        public int contohAyat;
        public String naskahTeks;
    }

    private final Context context;
    private final File quranCacheDir;
    private final File audioCacheDir;
    private final File lessonCacheDir;

    public QuranRepository(Context context) {
        this.context = context.getApplicationContext();
        this.quranCacheDir = new File(this.context.getFilesDir(), "cache_quran");
        this.audioCacheDir = new File(this.context.getFilesDir(), "cache_audio");
        this.lessonCacheDir = new File(this.context.getFilesDir(), "cache_lessons");
        if (!quranCacheDir.exists()) quranCacheDir.mkdirs();
        if (!audioCacheDir.exists()) audioCacheDir.mkdirs();
        if (!lessonCacheDir.exists()) lessonCacheDir.mkdirs();
    }

    public boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            NetworkInfo ni = cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Exception e) {
            return false;
        }
    }

    public List<SurahSummary> getSurahList() {
        File cache = new File(quranCacheDir, "surah_list.json");
        String json = fetchJsonOnlineFirst(AppConfig.EQURAN_LIST_URL, cache);
        List<SurahSummary> list = new ArrayList<>();
        if (json != null) {
            try {
                JSONObject root = new JSONObject(json);
                JSONArray data = root.optJSONArray("data");
                if (data != null) {
                    for (int i = 0; i < data.length(); i++) {
                        JSONObject o = data.getJSONObject(i);
                        SurahSummary s = new SurahSummary();
                        s.nomor = o.optInt("nomor", i + 1);
                        s.namaLatin = o.optString("namaLatin", "Surat " + s.nomor);
                        s.namaArab = o.optString("nama", "");
                        s.arti = o.optString("arti", "");
                        s.jumlahAyat = o.optInt("jumlahAyat", 0);
                        list.add(s);
                    }
                }
            } catch (Exception ignored) {
            }
        }
        if (list.isEmpty()) {
            list.addAll(buildBuiltInFallbackSurahs());
        }
        return list;
    }

    public List<AyahItem> getSurahAyahs(int surahNo) {
        File cache = new File(quranCacheDir, "surah_" + surahNo + ".json");
        String json = fetchJsonOnlineFirst(AppConfig.EQURAN_SURAH_URL + surahNo, cache);
        List<AyahItem> list = new ArrayList<>();
        if (json != null) {
            try {
                JSONObject root = new JSONObject(json);
                JSONObject data = root.optJSONObject("data");
                if (data != null) {
                    String surahName = data.optString("namaLatin", "Surat " + surahNo);
                    JSONArray ayatArr = data.optJSONArray("ayat");
                    if (ayatArr != null) {
                        for (int i = 0; i < ayatArr.length(); i++) {
                            JSONObject o = ayatArr.getJSONObject(i);
                            AyahItem a = new AyahItem();
                            a.surahNo = surahNo;
                            a.surahName = surahName;
                            a.nomorAyat = o.optInt("nomorAyat", i + 1);
                            a.teksArab = o.optString("teksArab", "");
                            a.teksLatin = o.optString("teksLatin", "");
                            a.teksIndonesia = o.optString("teksIndonesia", "");
                            JSONObject audioObj = o.optJSONObject("audio");
                            if (audioObj != null) {
                                a.audioDefaultUrl = audioObj.optString("05", audioObj.optString("01", ""));
                            }
                            list.add(a);
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }
        if (list.isEmpty() && surahNo == 1) {
            list.addAll(buildBuiltInFatihah());
        }
        return list;
    }

    // 2-Server Fast Word-by-Word: Lapis 1 (Quran.com API v4 by_key) + Lapis 2 (Direct CDN fallback)
    public List<WordItem> getWordByWord(int surahNo, int ayahNo) {
        return getWordByWord(surahNo, ayahNo, "");
    }

    public List<WordItem> getWordByWord(int surahNo, int ayahNo, String fallbackArabicText) {
        File cache = new File(quranCacheDir, "wbw_key_" + surahNo + "_" + ayahNo + ".json");
        String url = AppConfig.QURANCOM_BY_KEY_URL + surahNo + ":" + ayahNo
                + "?words=true&word_fields=text_uthmani,audio_url";
        String json = fetchJsonOnlineFirst(url, cache);
        List<WordItem> words = new ArrayList<>();
        if (json != null) {
            try {
                JSONObject root = new JSONObject(json);
                JSONObject v = root.optJSONObject("verse");
                if (v != null) {
                    JSONArray wArr = v.optJSONArray("words");
                    if (wArr != null) {
                        for (int j = 0; j < wArr.length(); j++) {
                            JSONObject w = wArr.getJSONObject(j);
                            if ("end".equals(w.optString("char_type_name"))) continue;
                            WordItem item = new WordItem();
                            item.position = w.optInt("position", j + 1);
                            item.textUthmani = w.optString("text_uthmani", w.optString("text", ""));
                            JSONObject tr = w.optJSONObject("transliteration");
                            item.transliteration = tr != null ? tr.optString("text", "") : "";
                            String relAudio = w.optString("audio_url", "");
                            if (!relAudio.isEmpty()) {
                                item.audioUrl = relAudio.startsWith("http")
                                        ? relAudio
                                        : AppConfig.QURANCOM_AUDIO_BASE + relAudio;
                            } else {
                                item.audioUrl = AppConfig.buildWordDirectFallbackUrl(surahNo, ayahNo, item.position);
                            }
                            words.add(item);
                        }
                    }
                }
            } catch (Exception ignored) {
            }
        }
        // Lapis 2: Direct CDN Fallback dari pemecahan teks Arab jika API JSON sibuk
        if (words.isEmpty() && fallbackArabicText != null && !fallbackArabicText.trim().isEmpty()) {
            String[] tokens = fallbackArabicText.trim().split("\\s+");
            for (int i = 0; i < tokens.length; i++) {
                WordItem item = new WordItem();
                item.position = i + 1;
                item.textUthmani = tokens[i];
                item.transliteration = "Kata " + (i + 1);
                item.audioUrl = AppConfig.buildWordDirectFallbackUrl(surahNo, ayahNo, i + 1);
                words.add(item);
            }
        }
        return words;
    }

    public List<WaqafSegment> splitIntoWaqafSegments(List<WordItem> words) {
        List<WaqafSegment> segments = new ArrayList<>();
        if (words == null || words.isEmpty()) return segments;

        WaqafSegment current = new WaqafSegment();
        current.index = 1;
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < words.size(); i++) {
            WordItem w = words.get(i);
            current.words.add(w);
            if (sb.length() > 0) sb.append(" ");
            sb.append(w.textUthmani);

            boolean hasWaqafMark = containsWaqafMark(w.textUthmani);
            boolean reachedChunkLimit = current.words.size() >= 4;
            boolean isLast = (i == words.size() - 1);

            if (hasWaqafMark || reachedChunkLimit || isLast) {
                current.textArabic = sb.toString().trim();
                segments.add(current);
                if (!isLast) {
                    current = new WaqafSegment();
                    current.index = segments.size() + 1;
                    sb = new StringBuilder();
                }
            }
        }
        return segments;
    }

    private boolean containsWaqafMark(String text) {
        if (text == null) return false;
        return text.indexOf('\u06D6') >= 0
                || text.indexOf('\u06D7') >= 0
                || text.indexOf('\u06D8') >= 0
                || text.indexOf('\u06D9') >= 0
                || text.indexOf('\u06DA') >= 0
                || text.indexOf('\u06DB') >= 0
                || text.indexOf('\u06DC') >= 0;
    }

    public List<RemoteLesson> getRemoteLessons() {
        File cache = new File(lessonCacheDir, "katalog_materi.json");
        String json = fetchJsonOnlineFirst(AppConfig.KATALOG_URL, cache);
        List<RemoteLesson> list = new ArrayList<>();
        if (json != null) {
            try {
                JSONObject root = new JSONObject(json);
                JSONArray arr = root.optJSONArray("materi");
                if (arr != null) {
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        RemoteLesson l = new RemoteLesson();
                        l.id = o.optString("id", "m_" + i);
                        l.kategori = o.optString("kategori", "Pengayaan");
                        l.judul = o.optString("judul", "Materi Madrasah");
                        l.ringkasan = o.optString("ringkasan", "");
                        String audioFile = o.optString("audio_file", "");
                        l.audioNaratorUrl = audioFile.isEmpty() ? "" : AppConfig.RELEASE_BASE_URL + audioFile;
                        l.contohSurah = o.optInt("contoh_surah", 1);
                        l.contohAyat = o.optInt("contoh_ayat", 1);
                        l.naskahTeks = o.optString("naskah_teks", l.ringkasan);
                        list.add(l);
                    }
                }
            } catch (Exception ignored) {
            }
        }
        if (list.isEmpty()) {
            list.addAll(buildBuiltInLessons());
        }
        return list;
    }

    public synchronized File getOrDownloadAudio(String remoteUrl, String cacheFileName) {
        if (remoteUrl == null || remoteUrl.isEmpty()) return null;
        File target = new File(audioCacheDir, cacheFileName);
        if (target.exists() && target.length() > 512) {
            return target;
        }
        if (!isOnline()) return null;

        for (int attempt = 1; attempt <= 2; attempt++) {
            HttpURLConnection conn = null;
            try {
                String currentUrl = remoteUrl;
                int code = -1;
                for (int hop = 0; hop < 5; hop++) {
                    if (conn != null) conn.disconnect();
                    URL url = new URL(currentUrl);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(12000);
                    conn.setReadTimeout(20000);
                    conn.setInstanceFollowRedirects(false);
                    conn.setRequestProperty("User-Agent", "SantriDigitalPondokHafidzNetra/7.4");
                    conn.setRequestProperty("Accept", "*/*");
                    code = conn.getResponseCode();
                    if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                        String loc = conn.getHeaderField("Location");
                        if (loc == null || loc.trim().isEmpty()) break;
                        currentUrl = new URL(url, loc.trim()).toString();
                        continue;
                    }
                    break;
                }
                if (code >= 200 && code < 300 && conn != null) {
                    File tmp = new File(audioCacheDir, cacheFileName + "." + System.nanoTime() + ".tmp");
                    try (InputStream in = new BufferedInputStream(conn.getInputStream());
                         FileOutputStream out = new FileOutputStream(tmp)) {
                        byte[] buf = new byte[8192];
                        int read;
                        while ((read = in.read(buf)) != -1) {
                            out.write(buf, 0, read);
                        }
                        out.flush();
                    }
                    if (tmp.length() > 512) {
                        if (target.exists()) target.delete();
                        if (tmp.renameTo(target)) return target;
                    } else {
                        tmp.delete();
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (conn != null) conn.disconnect();
            }
            try { Thread.sleep(350L); } catch (InterruptedException ignored) {}
        }
        return null;
    }

    public int downloadSurahOfflinePack(int surahNo, int qariIndex) {
        List<AyahItem> ayahs = getSurahAyahs(surahNo);
        int downloaded = 0;
        for (AyahItem a : ayahs) {
            String url = AppConfig.buildEveryAyahUrl(qariIndex, surahNo, a.nomorAyat);
            String fname = "q" + qariIndex + "_" + surahNo + "_" + a.nomorAyat + ".mp3";
            File f = getOrDownloadAudio(url, fname);
            if (f != null && f.exists()) downloaded++;
        }
        return downloaded;
    }

    public static String cleanLatinForTts(String latin) {
        if (latin == null) return "";
        return latin
                .replace("ā", "a").replace("ī", "i").replace("ū", "u")
                .replace("Ā", "A").replace("Ī", "I").replace("Ū", "U")
                .replace("ṣ", "s").replace("ḍ", "d").replace("ṭ", "t").replace("ẓ", "z")
                .replace("ḥ", "h").replace("ḫ", "kh").replace("ṡ", "ts").replace("ż", "dz")
                .replace("‘", "'").replace("’", "'").replace("`", "'")
                .replaceAll("\\s+", " ").trim();
    }

    private String fetchJsonOnlineFirst(String urlStr, File cacheFile) {
        if (isOnline()) {
            String online = httpGetString(urlStr);
            if (online != null && online.trim().startsWith("{")) {
                writeStringToFile(cacheFile, online);
                return online;
            }
        }
        if (cacheFile.exists()) {
            return readStringFromFile(cacheFile);
        }
        return null;
    }

    private String httpGetString(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(12000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "MadrasahHafizNetra/1.2");
            int code = conn.getResponseCode();
            if (code >= 200 && code < 300) {
                try (InputStream in = new BufferedInputStream(conn.getInputStream());
                     ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                    byte[] buf = new byte[4096];
                    int r;
                    while ((r = in.read(buf)) != -1) baos.write(buf, 0, r);
                    return baos.toString(StandardCharsets.UTF_8.name());
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (conn != null) conn.disconnect();
        }
        return null;
    }

    private void writeStringToFile(File f, String content) {
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write(content.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) {
        }
    }

    private String readStringFromFile(File f) {
        try (FileInputStream fis = new FileInputStream(f);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int r;
            while ((r = fis.read(buf)) != -1) baos.write(buf, 0, r);
            return baos.toString(StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            return null;
        }
    }

    private List<SurahSummary> buildBuiltInFallbackSurahs() {
        List<SurahSummary> list = new ArrayList<>();
        String[][] data = {
                {"114", "An-Nas", "Manusia", "6"},
                {"113", "Al-Falaq", "Waktu Subuh", "5"},
                {"112", "Al-Ikhlas", "Ikhlas", "4"},
                {"1", "Al-Fatihah", "Pembukaan", "7"},
                {"78", "An-Naba'", "Berita Besar", "40"},
                {"67", "Al-Mulk", "Kerajaan", "30"},
                {"36", "Yasin", "Yasin", "83"}
        };
        for (String[] row : data) {
            SurahSummary s = new SurahSummary();
            s.nomor = Integer.parseInt(row[0]);
            s.namaLatin = row[1];
            s.arti = row[2];
            s.jumlahAyat = Integer.parseInt(row[3]);
            list.add(s);
        }
        return list;
    }

    private List<AyahItem> buildBuiltInFatihah() {
        List<AyahItem> list = new ArrayList<>();
        String[][] rows = {
                {"1", "بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ", "Bismillahir rahmanir rahim", "Dengan nama Allah Yang Maha Pengasih, Maha Penyayang."},
                {"2", "اَلْحَمْدُ لِلّٰهِ رَبِّ الْعٰلَمِيْنَۙ", "Alhamdu lillahi rabbil alamin", "Segala puji bagi Allah, Tuhan seluruh alam."},
                {"3", "الرَّحْمٰنِ الرَّحِيْمِۙ", "Ar-rahmanir rahim", "Yang Maha Pengasih, Maha Penyayang."},
                {"4", "مٰلِكِ يَوْمِ الدِّيْنِۗ", "Maliki yaumid din", "Pemilik hari pembalasan."},
                {"5", "اِيَّاكَ نَعْبُدُ وَاِيَّاكَ نَسْتَعِيْنُۗ", "Iyyaka na'budu wa iyyaka nasta'in", "Hanya kepada Engkaulah kami menyembah dan hanya kepada Engkaulah kami mohon pertolongan."},
                {"6", "اِهْدِنَا الصِّرَاطَ الْمُسْتَقِيْمَۙ", "Ihdinash shiratal mustaqim", "Tunjukilah kami jalan yang lurus."},
                {"7", "صِرَاطَ الَّذِيْنَ اَنْعَمْتَ عَلَيْهِمْ ەۙ غَيْرِ الْمَغْضُوْبِ عَلَيْهِمْ وَلَا الضَّاۤلِّيْنَ", "Shiratal ladzina an'amta alaihim ghairil maghdubi alaihim wa ladh dhallin", "Yaitu jalan orang-orang yang telah Engkau beri nikmat kepadanya; bukan jalan mereka yang dimurkai, dan bukan pula jalan mereka yang sesat."}
        };
        for (String[] r : rows) {
            AyahItem a = new AyahItem();
            a.surahNo = 1;
            a.surahName = "Al-Fatihah";
            a.nomorAyat = Integer.parseInt(r[0]);
            a.teksArab = r[1];
            a.teksLatin = r[2];
            a.teksIndonesia = r[3];
            a.audioDefaultUrl = AppConfig.buildEveryAyahUrl(0, 1, a.nomorAyat);
            list.add(a);
        }
        return list;
    }

    private List<RemoteLesson> buildBuiltInLessons() {
        List<RemoteLesson> list = new ArrayList<>();
        RemoteLesson l1 = new RemoteLesson();
        l1.id = "makhraj_01";
        l1.kategori = "Klinik Makhraj";
        l1.judul = "Membedakan Huruf Tsa, Sin, dan Syin";
        l1.ringkasan = "Panduan lisan posisi lidah untuk huruf mirip.";
        l1.contohSurah = 114;
        l1.contohAyat = 1;
        l1.naskahTeks = "Untuk huruf Tsa, tempelkan sedikit ujung lidah pada ujung gigi seri atas. Untuk huruf Sin, ujung lidah berada di balik gigi seri bawah dengan desis tipis. Untuk huruf Syin, tengah lidah diangkat ke langit-langit.";
        list.add(l1);

        RemoteLesson l2 = new RemoteLesson();
        l2.id = "tajwid_01";
        l2.kategori = "Bedah Tajwid Lisan";
        l2.judul = "Pantulan Qalqalah Kubra di Surat Al-Falaq";
        l2.ringkasan = "Cara memantulkan huruf Qaf saat berhenti.";
        l2.contohSurah = 113;
        l2.contohAyat = 1;
        l2.naskahTeks = "Pada akhir Surat Al-Falaq ayat pertama, huruf Qaf dimatikan karena berhenti sehingga dibaca memantul kuat (Qalqalah Kubra).";
        list.add(l2);

        RemoteLesson l3 = new RemoteLesson();
        l3.id = "gharib_01";
        l3.kategori = "Kelas Gharib";
        l3.judul = "Bacaan Saktah (Berhenti Tanpa Napas)";
        l3.ringkasan = "Empat tempat Saktah masyhur riwayat Hafs.";
        l3.contohSurah = 18;
        l3.contohAyat = 1;
        l3.naskahTeks = "Saktah adalah berhenti sejenak sekitar dua harakat tanpa mengambil napas baru, seperti di akhir Surat Al-Kahfi ayat 1 dan Surat Yasin ayat 52.";
        list.add(l3);

        RemoteLesson l4 = new RemoteLesson();
        l4.id = "asbabun_01";
        l4.kategori = "Asbabun Nuzul & Kisah";
        l4.judul = "Kisah Pasukan Gajah di Balik Surat Al-Fil";
        l4.ringkasan = "Memahami alur cerita agar hafalan cepat menempel.";
        l4.contohSurah = 105;
        l4.contohAyat = 1;
        l4.naskahTeks = "Surat Al-Fil mengisahkan pasukan bergajah pimpinan Abrahah yang hendak menghancurkan Ka'bah, lalu dihancurkan oleh burung Ababil.";
        list.add(l4);

        return list;
    }

    public long getTotalAudioCacheBytes() {
        long total = 0L;
        total += dirSize(context.getCacheDir());
        File audioDir = new File(context.getFilesDir(), "audio_cache");
        total += dirSize(audioDir);
        File recDir = new File(context.getFilesDir(), "recordings");
        total += dirSize(recDir);
        return total;
    }

    public long clearAllAudioAndCache() {
        long before = getTotalAudioCacheBytes();
        deleteDirContents(context.getCacheDir());
        deleteDirContents(new File(context.getFilesDir(), "audio_cache"));
        deleteDirContents(new File(context.getFilesDir(), "recordings"));
        return before;
    }

    private long dirSize(File dir) {
        if (dir == null || !dir.exists()) return 0L;
        if (dir.isFile()) return dir.length();
        long sum = 0L;
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) sum += dirSize(f);
        }
        return sum;
    }

    private void deleteDirContents(File dir) {
        if (dir == null || !dir.exists()) return;
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) deleteDirContents(f);
                try { f.delete(); } catch (Exception ignored) {}
            }
        }
    }

}
